/**
 * @license
 * Copyright 2025 Qwen
 * SPDX-License-Identifier: Apache-2.0
 */

// English translations for Qwen Code CLI
// The key serves as both the translation key and the default English text

export default {
  'Cannot disable an extension-provided MCP server here.':
    'Cannot disable an extension-provided MCP server here.',
  'Cleared authentication for "{{name}}".':
    'Cleared authentication for "{{name}}".',
  'MCP "{{name}}" disabled for all projects.':
    'MCP "{{name}}" disabled for all projects.',
  'Enable extension "{{name}}" to manage this MCP server.':
    'Enable extension "{{name}}" to manage this MCP server.',
  'Extension-provided MCP servers cannot be favorited.':
    'Extension-provided MCP servers cannot be favorited.',

  'User level': 'User level',
  'Project level': 'Project level',
  'Clipboard image paste is unavailable because the native clipboard module could not be loaded. Reinstall Qwen Code or use the npm installation method.':
    'Clipboard image paste is unavailable because the native clipboard module could not be loaded. Reinstall Qwen Code or use the npm installation method.',
  'Clipboard image paste is unavailable: no supported clipboard tool was reached. On Linux, install `wl-clipboard` (Wayland) or `xclip` (X11), or set DISPLAY/WAYLAND_DISPLAY if running headless.':
    'Clipboard image paste is unavailable: no supported clipboard tool was reached. On Linux, install `wl-clipboard` (Wayland) or `xclip` (X11), or set DISPLAY/WAYLAND_DISPLAY if running headless.',

  // ==========================================================================
  // Extensions manager dialog (Installed / Discover / Sources tabs)
  // ==========================================================================
  ' · {{marketplace}} (Tab to clear)': ' · {{marketplace}} (Tab to clear)',
  '"{{name}}" {{state}}.': '"{{name}}" {{state}}.',
  '(Tab / ←→ to switch)': '(Tab / ←→ to switch)',
  '+ Add new marketplace': '+ Add new marketplace',
  '+ Install a new extension': '+ Install a new extension',
  Actions: 'Actions',
  'Add Marketplace': 'Add Marketplace',
  'Add a marketplace in the Sources tab to discover extensions.':
    'Add a marketplace in the Sources tab to discover extensions.',
  'Add new': 'Add new',
  'Add to Favorites': 'Add to Favorites',
  'Added "{{name}}" to favorites.': 'Added "{{name}}" to favorites.',
  'Added marketplace "{{name}}".': 'Added marketplace "{{name}}".',
  'Adding...': 'Adding...',
  'Back to extension list': 'Back to extension list',
  'Browse extensions ({{count}})': 'Browse extensions ({{count}})',
  'By: {{a}}': 'By: {{a}}',
  'Change scope': 'Change scope',
  'Change scope for "{{name}}":': 'Change scope for "{{name}}":',
  'Changing scope...': 'Changing scope...',
  'Uninstalling "{{name}}"...': 'Uninstalling "{{name}}"...',
  'Update available for "{{name}}".': 'Update available for "{{name}}".',
  '"{{name}}" is already up to date.': '"{{name}}" is already up to date.',
  'Checking "{{name}}" for updates...': 'Checking "{{name}}" for updates...',
  '"{{name}}" does not support update checks.':
    '"{{name}}" does not support update checks.',
  '"{{name}}" cannot be update-checked (Claude marketplace plugins update by reinstalling).':
    '"{{name}}" cannot be update-checked (Claude marketplace plugins update by reinstalling).',
  'Failed to check "{{name}}" for updates.':
    'Failed to check "{{name}}" for updates.',
  'Claude plugin marketplace': 'Claude plugin marketplace',
  Commands: 'Commands',
  'Components:': 'Components:',
  'Could not load this marketplace.': 'Could not load this marketplace.',
  'Current: {{scope}}': 'Current: {{scope}}',
  Disabled: 'Disabled',
  Discover: 'Discover',
  'Disabling "{{name}}"...': 'Disabling "{{name}}"...',
  'Disabling MCP "{{name}}"...': 'Disabling MCP "{{name}}"...',
  'Discover extensions': 'Discover extensions',
  'Discovering extensions...': 'Discovering extensions...',
  'Enabling "{{name}}"...': 'Enabling "{{name}}"...',
  'Enabling MCP "{{name}}"...': 'Enabling MCP "{{name}}"...',
  'Enter extension source:': 'Enter extension source:',
  'Enter marketplace source (Claude format):':
    'Enter marketplace source (Claude format):',
  'Examples:': 'Examples:',
  'Extension details': 'Extension details',
  'Extension v{{version}}': 'Extension v{{version}}',
  'Extensions are not available in this environment.':
    'Extensions are not available in this environment.',
  'Failed to open {{url}}': 'Failed to open {{url}}',
  Favorites: 'Favorites',
  'Global (User Scope)': 'Global (User Scope)',
  'Install Extension': 'Install Extension',
  'Install for the current workspace (project scope)':
    'Install for the current workspace (project scope)',
  'Install for you (user scope)': 'Install for you (user scope)',
  'Install {{count}} extension(s) to which scope?':
    'Install {{count}} extension(s) to which scope?',
  Installed: 'Installed',
  'Installed extension "{{name}}".': 'Installed extension "{{name}}".',
  'Installed extensions ({{count}}):': 'Installed extensions ({{count}}):',
  'Installed {{count}} extension(s).': 'Installed {{count}} extension(s).',
  '{{name}}: installed, but the scope rollback failed — it may be disabled at all scopes; re-enable it from the Installed tab.':
    '{{name}}: installed, but the scope rollback failed — it may be disabled at all scopes; re-enable it from the Installed tab.',
  'Could not change scope, and the rollback also failed — "{{name}}" may be disabled at all scopes. Re-enable it from the Installed tab. ({{error}})':
    'Could not change scope, and the rollback also failed — "{{name}}" may be disabled at all scopes. Re-enable it from the Installed tab. ({{error}})',
  'Installed {{ok}}, failed {{fail}}: {{detail}}':
    'Installed {{ok}}, failed {{fail}}: {{detail}}',
  'Installing...': 'Installing...',
  'Last updated: {{date}}': 'Last updated: {{date}}',
  MCP: 'MCP',
  'MCP "{{name}}" {{state}}.': 'MCP "{{name}}" {{state}}.',
  'MCP servers': 'MCP servers',
  'Mark for Update': 'Mark for Update',
  Marketplaces: 'Marketplaces',
  'No extensions discovered.': 'No extensions discovered.',
  'No extensions match your search.': 'No extensions match your search.',
  'No extensions or marketplaces added yet.':
    'No extensions or marketplaces added yet.',
  'No homepage available.': 'No homepage available.',
  'No installable extensions selected.': 'No installable extensions selected.',
  'No plugins or MCP servers installed.':
    'No plugins or MCP servers installed.',
  None: 'None',
  'Note: Uninstall permanently removes this extension.':
    'Note: Uninstall permanently removes this extension.',
  'Open homepage': 'Open homepage',
  'Project (Workspace)': 'Project (Workspace)',
  'Refreshed {{count}} extension(s).': 'Refreshed {{count}} extension(s).',
  'Remove from Favorites': 'Remove from Favorites',
  'Remove marketplace': 'Remove marketplace',
  'Remove marketplace "{{name}}"?': 'Remove marketplace "{{name}}"?',
  'Removed "{{name}}" from favorites.': 'Removed "{{name}}" from favorites.',
  'Removed marketplace "{{name}}".': 'Removed marketplace "{{name}}".',
  'Scope:': 'Scope:',
  'Set "{{name}}" scope to {{scope}}.': 'Set "{{name}}" scope to {{scope}}.',
  Sources: 'Sources',
  'Type to search · Space to toggle · Enter to view · Ctrl+R refresh · Esc to go back':
    'Type to search · Space to toggle · Enter to view · Ctrl+R refresh · Esc to go back',
  Uninstall: 'Uninstall',
  'Uninstalled "{{name}}".': 'Uninstalled "{{name}}".',
  'Update Now': 'Update Now',
  'Update marketplace': 'Update marketplace',
  'Update marketplace (last updated {{date}})':
    'Update marketplace (last updated {{date}})',
  'Could not update marketplace "{{name}}".':
    'Could not update marketplace "{{name}}".',
  'Updated "{{name}}".': 'Updated "{{name}}".',
  'Updated marketplace "{{name}}".': 'Updated marketplace "{{name}}".',
  'Use the Discover tab to find and install plugins.':
    'Use the Discover tab to find and install plugins.',
  'Version: {{v}}': 'Version: {{v}}',
  'Will install:': 'Will install:',
  'Would open: {{url}}': 'Would open: {{url}}',
  'Y/Enter to confirm · N/Esc to cancel':
    'Y/Enter to confirm · N/Esc to cancel',
  'Press R to retry · Esc to go back': 'Press R to retry · Esc to go back',
  'Enter to select · R refresh · Esc to go back':
    'Enter to select · R refresh · Esc to go back',
  'from {{marketplace}}': 'from {{marketplace}}',
  installed: 'installed',
  '{{count}} Agents': '{{count}} Agents',
  '{{count}} Workflows': '{{count}} Workflows',
  '{{count}} Commands': '{{count}} Commands',
  '{{count}} MCP': '{{count}} MCP',
  '{{count}} Skills': '{{count}} Skills',
  '{{count}} available extensions': '{{count}} available extensions',
  '↑ more above': '↑ more above',
  '↑↓ navigate · Enter open · d remove marketplace · Esc close':
    '↑↓ navigate · Enter open · d remove marketplace · Esc close',
  '↑↓ navigate · Enter select · Esc close':
    '↑↓ navigate · Enter select · Esc close',
  '↑↓ navigate · Enter select · d remove marketplace · Esc close':
    '↑↓ navigate · Enter select · d remove marketplace · Esc close',
  '↑↓ navigate · Space enable/disable · f favorite · Enter details · Esc close':
    '↑↓ navigate · Space enable/disable · f favorite · Enter details · Esc close',
  '↓ more below': '↓ more below',
  '⚠ Make sure you trust an extension before installing, updating, or using it. We cannot verify what MCP servers, files, or other software an extension includes, or that it works as intended. See the extension homepage for more information.':
    '⚠ Make sure you trust an extension before installing, updating, or using it. We cannot verify what MCP servers, files, or other software an extension includes, or that it works as intended. See the extension homepage for more information.',

  // ============================================================================
  // Tool display names (chat-stream badge labels)
  // ----------------------------------------------------------------------------
  // Namespaced `toolDisplayName.<English display name>` keys (from core
  // `ToolDisplayNames`). Per this file's key-is-default-text convention each
  // English entry maps to itself; `localizeToolDisplayName` detects that
  // self-mapping and returns the bare display name. Localized values live in
  // zh.js / zh-TW.js; other locales fall back to the English display name.
  // ============================================================================
  'toolDisplayName.Exec': 'toolDisplayName.Exec',
  'toolDisplayName.Edit': 'toolDisplayName.Edit',
  'toolDisplayName.WriteFile': 'toolDisplayName.WriteFile',
  'toolDisplayName.ReadFile': 'toolDisplayName.ReadFile',
  'toolDisplayName.ZoomImage': 'toolDisplayName.ZoomImage',
  'toolDisplayName.Grep': 'toolDisplayName.Grep',
  'toolDisplayName.Glob': 'toolDisplayName.Glob',
  'toolDisplayName.Shell': 'toolDisplayName.Shell',
  'toolDisplayName.Shell Command': 'toolDisplayName.Shell Command',
  'toolDisplayName.TodoList': 'toolDisplayName.TodoList',
  'toolDisplayName.Goal': 'toolDisplayName.Goal',
  'toolDisplayName.UpdateGoal': 'toolDisplayName.UpdateGoal',
  'toolDisplayName.ProposeGoal': 'toolDisplayName.ProposeGoal',
  'toolDisplayName.SaveMemory': 'toolDisplayName.SaveMemory',
  'toolDisplayName.ManageMemory': 'toolDisplayName.ManageMemory',
  'toolDisplayName.SearchMemory': 'toolDisplayName.SearchMemory',
  'toolDisplayName.Agent': 'toolDisplayName.Agent',
  'toolDisplayName.Advisor': 'toolDisplayName.Advisor',
  'toolDisplayName.Artifact': 'toolDisplayName.Artifact',
  'toolDisplayName.RecordArtifact': 'toolDisplayName.RecordArtifact',
  'toolDisplayName.RecordSource': 'toolDisplayName.RecordSource',
  'toolDisplayName.ReportFindings': 'toolDisplayName.ReportFindings',
  'toolDisplayName.DisplayImage': 'toolDisplayName.DisplayImage',
  'toolDisplayName.Skill': 'toolDisplayName.Skill',
  'toolDisplayName.EnterPlanMode': 'toolDisplayName.EnterPlanMode',
  'toolDisplayName.ExitPlanMode': 'toolDisplayName.ExitPlanMode',
  'toolDisplayName.WebFetch': 'toolDisplayName.WebFetch',
  'toolDisplayName.WebSearch': 'toolDisplayName.WebSearch',
  'toolDisplayName.ListFiles': 'toolDisplayName.ListFiles',
  'toolDisplayName.Lsp': 'toolDisplayName.Lsp',
  'toolDisplayName.AskUserQuestion': 'toolDisplayName.AskUserQuestion',
  'toolDisplayName.CronCreate': 'toolDisplayName.CronCreate',
  'toolDisplayName.CronList': 'toolDisplayName.CronList',
  'toolDisplayName.CronDelete': 'toolDisplayName.CronDelete',
  'toolDisplayName.LoopWakeup': 'toolDisplayName.LoopWakeup',
  'toolDisplayName.CreateSubSession': 'toolDisplayName.CreateSubSession',
  'toolDisplayName.ListAgents': 'toolDisplayName.ListAgents',
  'toolDisplayName.TaskCreate': 'toolDisplayName.TaskCreate',
  'toolDisplayName.TaskUpdate': 'toolDisplayName.TaskUpdate',
  'toolDisplayName.TaskList': 'toolDisplayName.TaskList',
  'toolDisplayName.TaskStop': 'toolDisplayName.TaskStop',
  'toolDisplayName.TeamCreate': 'toolDisplayName.TeamCreate',
  'toolDisplayName.TeamDelete': 'toolDisplayName.TeamDelete',
  'toolDisplayName.TeamPlanApproval': 'toolDisplayName.TeamPlanApproval',
  'toolDisplayName.SendMessage': 'toolDisplayName.SendMessage',
  'toolDisplayName.RequestShutdown': 'toolDisplayName.RequestShutdown',
  'toolDisplayName.StructuredOutput': 'toolDisplayName.StructuredOutput',
  'toolDisplayName.Monitor': 'toolDisplayName.Monitor',
  'toolDisplayName.NotebookEdit': 'toolDisplayName.NotebookEdit',
  'toolDisplayName.ToolSearch': 'toolDisplayName.ToolSearch',
  'toolDisplayName.ToolCall': 'toolDisplayName.ToolCall',
  'toolDisplayName.EnterWorktree': 'toolDisplayName.EnterWorktree',
  'toolDisplayName.ExitWorktree': 'toolDisplayName.ExitWorktree',
  'toolDisplayName.Workflow': 'toolDisplayName.Workflow',
  'toolDisplayName.ReadMcpResource': 'toolDisplayName.ReadMcpResource',
  'toolDisplayName.ImageGen': 'toolDisplayName.ImageGen',
  'toolDisplayName.DownsampleImage': 'toolDisplayName.DownsampleImage',
  'toolDisplayName.DownscaleVideo': 'toolDisplayName.DownscaleVideo',
  'toolDisplayName.DownsampleAudio': 'toolDisplayName.DownsampleAudio',
  'toolDisplayName.ExtractKeyframes': 'toolDisplayName.ExtractKeyframes',
  'toolDisplayName.ExtractAudio': 'toolDisplayName.ExtractAudio',
  'toolDisplayName.ClipVideo': 'toolDisplayName.ClipVideo',
  'toolDisplayName.ClipImage': 'toolDisplayName.ClipImage',
  'toolDisplayName.ClipAudio': 'toolDisplayName.ClipAudio',
  'toolDisplayName.CaptionImage': 'toolDisplayName.CaptionImage',
  'toolDisplayName.CaptionAudio': 'toolDisplayName.CaptionAudio',
  'toolDisplayName.OcrImage': 'toolDisplayName.OcrImage',
  'toolDisplayName.UnderstandVideoSegments':
    'toolDisplayName.UnderstandVideoSegments',
  'toolDisplayName.ConvertImage': 'toolDisplayName.ConvertImage',
  'toolDisplayName.TranscribeAudio': 'toolDisplayName.TranscribeAudio',
  'toolDisplayName.RecallMediaMemory': 'toolDisplayName.RecallMediaMemory',
  '[fixed-only: runs via media policies, not the model]':
    '[fixed-only: runs via media policies, not the model]',
  // ============================================================================
  // Help / UI Components
  // ============================================================================
  // Attachment hints
  '↑ to manage attachments': '↑ to manage attachments',
  '← → select, Delete to remove, ↓ to exit':
    '← → select, Delete to remove, ↓ to exit',
  'Attachments: ': 'Attachments: ',
  'Basics:': 'Basics:',
  'Add context': 'Add context',
  'Use {{symbol}} to specify files for context (e.g., {{example}}) to target specific files or folders.':
    'Use {{symbol}} to specify files for context (e.g., {{example}}) to target specific files or folders.',
  '@': '@',
  '@src/myFile.ts': '@src/myFile.ts',
  'Shell mode': 'Shell mode',
  'YOLO mode': 'YOLO mode',
  'Auto mode': 'Auto mode',
  'auto_mode.entry_notice':
    'Auto mode enabled.\n   An LLM classifier evaluates each tool call — safe actions auto-approve,\n   risky ones are blocked. Exit: Shift+Tab or /approval-mode default.',
  'plan mode': 'plan mode',
  'auto-accept edits': 'auto-accept edits',
  'Accepting edits': 'Accepting edits',
  '(shift + tab to cycle)': '(shift + tab to cycle)',
  '(tab to cycle)': '(tab to cycle)',
  'Execute shell commands via {{symbol}} (e.g., {{example1}}) or use natural language (e.g., {{example2}}).':
    'Execute shell commands via {{symbol}} (e.g., {{example1}}) or use natural language (e.g., {{example2}}).',
  '!': '!',
  '!npm run start': '!npm run start',
  'start server': 'start server',
  'Commands:': 'Commands:',
  'shell command': 'shell command',
  'Model Context Protocol command (from external servers)':
    'Model Context Protocol command (from external servers)',
  'Keyboard Shortcuts:': 'Keyboard Shortcuts:',
  'Toggle this help display': 'Toggle this help display',
  'Toggle shell mode': 'Toggle shell mode',
  'Open command menu': 'Open command menu',
  'Add file context': 'Add file context',
  'Accept suggestion / Autocomplete': 'Accept suggestion / Autocomplete',
  'Reverse search history': 'Reverse search history',
  'Press ? again to close': 'Press ? again to close',
  // Keyboard shortcuts panel descriptions
  'for shell mode': 'for shell mode',
  'for commands': 'for commands',
  'for file paths': 'for file paths',
  'to clear input': 'to clear input',
  'to cycle approvals': 'to cycle approvals',
  'to quit': 'to quit',
  'for newline': 'for newline',
  'to clear screen': 'to clear screen',
  'to search history': 'to search history',
  'to paste images': 'to paste images',
  'for external editor': 'for external editor',
  'to expand details': 'to expand details',
  'Jump through words in the input': 'Jump through words in the input',
  'Close dialogs, cancel requests, or quit application':
    'Close dialogs, cancel requests, or quit application',
  'New line': 'New line',
  'New line (Alt+Enter works for certain linux distros)':
    'New line (Alt+Enter works for certain linux distros)',
  'Clear the screen': 'Clear the screen',
  'Open input in external editor': 'Open input in external editor',
  'Send message': 'Send message',
  'Initializing...': 'Initializing...',
  'Connecting to MCP servers... ({{connected}}/{{total}})':
    'Connecting to MCP servers... ({{connected}}/{{total}})',
  'Type your message or @path/to/file': 'Type your message or @path/to/file',
  '? for shortcuts': '? for shortcuts',
  'Pasting…': 'Pasting…',
  "Press 'i' for INSERT mode and 'Esc' for NORMAL mode.":
    "Press 'i' for INSERT mode and 'Esc' for NORMAL mode.",
  'Cancel operation / Clear input (double press)':
    'Cancel operation / Clear input (double press)',
  'Cycle approval modes': 'Cycle approval modes',
  'Cycle through your prompt history': 'Cycle through your prompt history',
  'For a full list of shortcuts, see {{docPath}}':
    'For a full list of shortcuts, see {{docPath}}',
  'docs/keyboard-shortcuts.md': 'docs/keyboard-shortcuts.md',
  'for help on Qwen Code': 'for help on Qwen Code',
  'show version info': 'show version info',
  'show paths for current session files and logs':
    'show paths for current session files and logs',
  'submit a bug report': 'submit a bug report',
  Status: 'Status',

  // ============================================================================
  // System Information Fields
  // ============================================================================
  'Qwen Code': 'Qwen Code',
  Runtime: 'Runtime',
  OS: 'OS',
  Auth: 'Auth',
  Model: 'Model',
  'Fast Model': 'Fast Model',
  Sandbox: 'Sandbox',
  'Session ID': 'Session ID',
  'Base URL': 'Base URL',
  Proxy: 'Proxy',
  'Memory Usage': 'Memory Usage',
  'IDE Client': 'IDE Client',

  // ============================================================================
  // Commands - General
  // ============================================================================
  'Analyzes the project and creates a tailored QWEN.md file.':
    'Analyzes the project and creates a tailored QWEN.md file.',
  'List available Qwen Code tools. Usage: /tools [desc]':
    'List available Qwen Code tools. Usage: /tools [desc]',
  'Open the skills panel (browse, search, toggle, pick).':
    'Open the skills panel (browse, search, toggle, pick).',
  'Move this session to a new working directory':
    'Move this session to a new working directory',
  // SkillsManagerDialog (the panel `/skills` opens)
  'Manage Skills': 'Manage Skills',
  'Skills configuration saved.': 'Skills configuration saved.',
  'Skills configuration saved, but refresh failed: {{error}}. Restart to ensure the new state is applied.':
    'Skills configuration saved, but refresh failed: {{error}}. Restart to ensure the new state is applied.',
  'Workspace is untrusted; workspace settings are ignored by the merged config. Run /trust first to persist skills changes here, or edit ~/.qwen/settings.json directly to manage skills at user scope.':
    'Workspace is untrusted; workspace settings are ignored by the merged config. Run /trust first to persist skills changes here, or edit ~/.qwen/settings.json directly to manage skills at user scope.',
  'SkillManager not available.': 'SkillManager not available.',
  'Loading skills…': 'Loading skills…',
  'Failed to load skills: {{error}}': 'Failed to load skills: {{error}}',
  'Failed to save skills configuration: {{error}}':
    'Failed to save skills configuration: {{error}}',
  'All available skills are disabled. Edit ~/.qwen/settings.json or .qwen/settings.json (skills.disabled) to re-enable.':
    'All available skills are disabled. Edit ~/.qwen/settings.json or .qwen/settings.json (skills.disabled) to re-enable.',
  'Press esc to close.': 'Press esc to close.',
  '{{count}} skills · ': '{{count}} skills · ',
  '{{matched}} / {{total}} skills · ': '{{matched}} / {{total}} skills · ',
  'Space toggle · Enter pick (fill input) · Esc save & exit · workspace scope':
    'Space toggle · Enter pick (fill input) · Esc save & exit · workspace scope',
  'Search:': 'Search:',
  'type to filter…': 'type to filter…',
  'No skills are currently available.': 'No skills are currently available.',
  'No skills match the search.': 'No skills match the search.',
  'Locked by settings entries you cannot toggle here:':
    'Locked by settings entries you cannot toggle here:',
  '{{count}} locked not shown': '{{count}} locked not shown',
  'higher scope': 'higher scope',
  '  {{name}} {{description}}  [locked: {{scope}}]':
    '  {{name}} {{description}}  [locked: {{scope}}]',
  '↑/↓ navigate · backspace edits search':
    '↑/↓ navigate · backspace edits search',
  Bundled: 'Bundled',
  'Available Qwen Code CLI tools:': 'Available Qwen Code CLI tools:',
  'No tools available': 'No tools available',
  'View or change the approval mode for tool usage':
    'View or change the approval mode for tool usage',
  'Invalid approval mode "{{arg}}". Valid modes: {{modes}}':
    'Invalid approval mode "{{arg}}". Valid modes: {{modes}}',
  'Approval mode set to "{{mode}}"': 'Approval mode set to "{{mode}}"',
  'View or change the language setting': 'View or change the language setting',
  'List background tasks (text dump — interactive dialog opens via the footer pill)':
    'List background tasks (text dump — interactive dialog opens via the footer pill)',
  'Delete a previous session': 'Delete a previous session',
  'Run installation and environment diagnostics':
    'Run installation and environment diagnostics',
  'Browse dynamic model catalogs and choose which models stay enabled locally':
    'Browse dynamic model catalogs and choose which models stay enabled locally',
  'Generate a one-line session recap now':
    'Generate a one-line session recap now',
  'Rename the current conversation. --auto lets the fast model pick a title.':
    'Rename the current conversation. --auto lets the fast model pick a title.',
  'Rewind conversation to a previous turn':
    'Rewind conversation to a previous turn',
  'Rewind Conversation': 'Rewind Conversation',
  'No user turns to rewind to.': 'No user turns to rewind to.',
  'Rewind to: ': 'Rewind to: ',
  'Restore code and conversation': 'Restore code and conversation',
  'Restore conversation only': 'Restore conversation only',
  'Restore code only': 'Restore code only',
  'Never mind': 'Never mind',
  'Computing file changes...': 'Computing file changes...',
  'Restoring...': 'Restoring...',
  'Restored {{count}} file(s).': 'Restored {{count}} file(s).',
  'Failed to restore files: {{error}}': 'Failed to restore files: {{error}}',
  'Rewind failed: {{error}}': 'Rewind failed: {{error}}',
  'Cannot rewind conversation: no active model client.':
    'Cannot rewind conversation: no active model client.',
  'Code restored, but conversation could not be rewound (no active client).':
    'Code restored, but conversation could not be rewound (no active client).',
  'Conversation rewound. Edit your prompt and press Enter to continue.':
    'Conversation rewound. Edit your prompt and press Enter to continue.',
  'Rewinding does not affect files edited manually or via shell commands.':
    'Rewinding does not affect files edited manually or via shell commands.',
  'Cannot rewind to a turn that was compressed. Try a more recent turn.':
    'Cannot rewind to a turn that was compressed. Try a more recent turn.',
  'Cannot rewind the conversation to this turn: it no longer matches the model history (for example, after a retry). Try a more recent turn.':
    'Cannot rewind the conversation to this turn: it no longer matches the model history (for example, after a retry). Try a more recent turn.',
  'File restore is unavailable for this turn (no captured file changes, or this turn predates the current session).':
    'File restore is unavailable for this turn (no captured file changes, or this turn predates the current session).',
  '(+{{insertions}} -{{deletions}} in {{count}} file)':
    '(+{{insertions}} -{{deletions}} in {{count}} file)',
  '(+{{insertions}} -{{deletions}} in {{count}} files)':
    '(+{{insertions}} -{{deletions}} in {{count}} files)',
  'Failed to restore {{count}} file(s): {{files}}':
    'Failed to restore {{count}} file(s): {{files}}',
  'Cannot restore files: this turn was created before file checkpointing was enabled.':
    'Cannot restore files: this turn was created before file checkpointing was enabled.',
  'No files needed to be restored.': 'No files needed to be restored.',
  '↑↓ to navigate · Enter to select · Esc to go back':
    '↑↓ to navigate · Enter to select · Esc to go back',
  '↑↓ to navigate · Enter to select · Esc to cancel':
    '↑↓ to navigate · Enter to select · Esc to cancel',
  'Enter/Y to confirm · Esc/N to go back':
    'Enter/Y to confirm · Esc/N to go back',
  'change the theme': 'change the theme',
  'Select Theme': 'Select Theme',
  Preview: 'Preview',
  '(Use Enter to select, Tab to configure scope)':
    '(Use Enter to select, Tab to configure scope)',
  '(Use Enter to apply scope, Tab to go back)':
    '(Use Enter to apply scope, Tab to go back)',
  'Theme configuration unavailable due to NO_COLOR env variable.':
    'Theme configuration unavailable due to NO_COLOR env variable.',
  'Theme "{{themeName}}" not found.': 'Theme "{{themeName}}" not found.',
  'Theme "{{themeName}}" not found in selected scope.':
    'Theme "{{themeName}}" not found in selected scope.',
  'Clear conversation history and free up context':
    'Clear conversation history and free up context',
  'Compresses the context by replacing it with a summary.':
    'Compresses the context by replacing it with a summary.',
  'Fast context compression without AI. Strips old tool outputs and thinking parts.':
    'Fast context compression without AI. Strips old tool outputs and thinking parts.',
  'open full Qwen Code documentation in your browser':
    'open full Qwen Code documentation in your browser',
  'Configuration not available.': 'Configuration not available.',
  'Connect an LLM provider': 'Connect an LLM provider',
  'Copy to clipboard: reply, code (by lang), LaTeX, or Mermaid. N = Nth-latest message, index = block number':
    'Copy to clipboard: reply, code (by lang), LaTeX, or Mermaid. N = Nth-latest message, index = block number',
  'Show working-tree change stats versus HEAD':
    'Show working-tree change stats versus HEAD',
  'Could not determine current working directory.':
    'Could not determine current working directory.',
  'Failed to compute git diff stats': 'Failed to compute git diff stats',
  'No diff available. Either this is not a git repository, HEAD is missing, or a merge/rebase/cherry-pick/revert is in progress.':
    'No diff available. Either this is not a git repository, HEAD is missing, or a merge/rebase/cherry-pick/revert is in progress.',
  'Clean working tree — no changes against HEAD.':
    'Clean working tree — no changes against HEAD.',
  '{{count}} file changed, +{{added}} / -{{removed}}':
    '{{count}} file changed, +{{added}} / -{{removed}}',
  '{{count}} files changed, +{{added}} / -{{removed}}':
    '{{count}} files changed, +{{added}} / -{{removed}}',
  '{{count}} file changed': '{{count}} file changed',
  '{{count}} files changed': '{{count}} files changed',
  '…and {{hidden}} more (showing first {{shown}})':
    '…and {{hidden}} more (showing first {{shown}})',
  '(binary)': '(binary)',
  '(binary, new)': '(binary, new)',
  '(new)': '(new)',
  '(new, partial)': '(new, partial)',
  '(deleted)': '(deleted)',
  '(binary, deleted)': '(binary, deleted)',

  // ============================================================================
  // Commands - Agents
  // ============================================================================
  'Manage subagents for specialized task delegation.':
    'Manage subagents for specialized task delegation.',
  'Manage existing subagents (view, edit, delete).':
    'Manage existing subagents (view, edit, delete).',
  'Create a new subagent with guided setup.':
    'Create a new subagent with guided setup.',
  'Create a reusable skill from a knowledge source (file, URL, conversation, or text).':
    'Create a reusable skill from a knowledge source (file, URL, conversation, or text).',
  'The current model or provider does not support native video input for /learn. Switch to a video-capable model on an OpenAI-compatible provider and try again.':
    'The current model or provider does not support native video input for /learn. Switch to a video-capable model on an OpenAI-compatible provider and try again.',
  'YouTube page URLs cannot be sent as native video input. Download the video into your workspace and pass the local video file path to /learn.':
    'YouTube page URLs cannot be sent as native video input. Download the video into your workspace and pass the local video file path to /learn.',
  'The local video could not be attached for /learn.':
    'The local video could not be attached for /learn.',

  // ============================================================================
  // Agents - Management Dialog
  // ============================================================================
  Agents: 'Agents',
  'Choose Action': 'Choose Action',
  'Edit {{name}}': 'Edit {{name}}',
  'Edit Tools: {{name}}': 'Edit Tools: {{name}}',
  'Edit Color: {{name}}': 'Edit Color: {{name}}',
  'Delete {{name}}': 'Delete {{name}}',
  'Unknown Step': 'Unknown Step',
  'Esc to close': 'Esc to close',
  Transcript: 'Transcript',
  'Read {{count}} file': 'Read {{count}} file',
  'Read {{count}} files': 'Read {{count}} files',
  'Reading {{count}} file': 'Reading {{count}} file',
  'Reading {{count}} files': 'Reading {{count}} files',
  'Edited {{count}} file': 'Edited {{count}} file',
  'Edited {{count}} files': 'Edited {{count}} files',
  'Editing {{count}} file': 'Editing {{count}} file',
  'Editing {{count}} files': 'Editing {{count}} files',
  'Wrote {{count}} file': 'Wrote {{count}} file',
  'Wrote {{count}} files': 'Wrote {{count}} files',
  'Writing {{count}} file': 'Writing {{count}} file',
  'Writing {{count}} files': 'Writing {{count}} files',
  'Searched {{count}} pattern': 'Searched {{count}} pattern',
  'Searched {{count}} patterns': 'Searched {{count}} patterns',
  'Searching {{count}} pattern': 'Searching {{count}} pattern',
  'Searching {{count}} patterns': 'Searching {{count}} patterns',
  'Listed {{count}} directory': 'Listed {{count}} directory',
  'Listed {{count}} directories': 'Listed {{count}} directories',
  'Listing {{count}} directory': 'Listing {{count}} directory',
  'Listing {{count}} directories': 'Listing {{count}} directories',
  'Ran {{count}} command': 'Ran {{count}} command',
  'Ran {{count}} commands': 'Ran {{count}} commands',
  'Running {{count}} command': 'Running {{count}} command',
  'Running {{count}} commands': 'Running {{count}} commands',
  'Ran {{count}} agent': 'Ran {{count}} agent',
  'Ran {{count}} agents': 'Ran {{count}} agents',
  'Running {{count}} agent': 'Running {{count}} agent',
  'Running {{count}} agents': 'Running {{count}} agents',
  'Used {{count}} tool': 'Used {{count}} tool',
  'Used {{count}} tools': 'Used {{count}} tools',
  'Using {{count}} tool': 'Using {{count}} tool',
  'Using {{count}} tools': 'Using {{count}} tools',
  'Enter to select, ↑↓ to navigate, Esc to close':
    'Enter to select, ↑↓ to navigate, Esc to close',
  'Esc to go back': 'Esc to go back',
  'Enter to confirm, Esc to cancel': 'Enter to confirm, Esc to cancel',
  'Enter to select, ↑↓ to navigate, Esc to go back':
    'Enter to select, ↑↓ to navigate, Esc to go back',
  'Enter to submit, Esc to go back': 'Enter to submit, Esc to go back',
  'Invalid step: {{step}}': 'Invalid step: {{step}}',
  'No subagents found.': 'No subagents found.',
  "Use '/agents create' to create your first subagent.":
    "Use '/agents create' to create your first subagent.",
  '(built-in)': '(built-in)',
  '(overridden by project level agent)': '(overridden by project level agent)',
  'Project Level ({{path}})': 'Project Level ({{path}})',
  'User Level ({{path}})': 'User Level ({{path}})',
  'Built-in Agents': 'Built-in Agents',
  'Extension Agents': 'Extension Agents',
  'Using: {{count}} agents': 'Using: {{count}} agents',
  'View Agent': 'View Agent',
  'Edit Agent': 'Edit Agent',
  'Delete Agent': 'Delete Agent',
  Back: 'Back',
  'No agent selected': 'No agent selected',
  'File Path: ': 'File Path: ',
  'Tools: ': 'Tools: ',
  'Color: ': 'Color: ',
  'Description:': 'Description:',
  'System Prompt:': 'System Prompt:',
  'Open in editor': 'Open in editor',
  'Edit tools': 'Edit tools',
  'Edit color': 'Edit color',
  '✗ Error:': '✗ Error:',
  'Are you sure you want to delete agent "{{name}}"?':
    'Are you sure you want to delete agent "{{name}}"?',
  // ============================================================================
  // Agents - Creation Wizard
  // ============================================================================
  'Project Level (.qwen/agents/)': 'Project Level (.qwen/agents/)',
  'User Level (~/.qwen/agents/)': 'User Level (~/.qwen/agents/)',
  '✓ Subagent Created Successfully!': '✓ Subagent Created Successfully!',
  'Subagent "{{name}}" has been saved to {{level}} level.':
    'Subagent "{{name}}" has been saved to {{level}} level.',
  'Name: ': 'Name: ',
  'Location: ': 'Location: ',
  '✗ Error saving subagent:': '✗ Error saving subagent:',
  'Warnings:': 'Warnings:',
  'Name "{{name}}" already exists at {{level}} level - will overwrite existing subagent':
    'Name "{{name}}" already exists at {{level}} level - will overwrite existing subagent',
  'Name "{{name}}" exists at user level - project level will take precedence':
    'Name "{{name}}" exists at user level - project level will take precedence',
  'Name "{{name}}" exists at project level - existing subagent will take precedence':
    'Name "{{name}}" exists at project level - existing subagent will take precedence',
  'Description is over {{length}} characters':
    'Description is over {{length}} characters',
  'System prompt is over {{length}} characters':
    'System prompt is over {{length}} characters',
  // Agents - Creation Wizard Steps
  'Step {{n}}: Choose Location': 'Step {{n}}: Choose Location',
  'Step {{n}}: Choose Generation Method':
    'Step {{n}}: Choose Generation Method',
  'Generate with Qwen Code (Recommended)':
    'Generate with Qwen Code (Recommended)',
  'Manual Creation': 'Manual Creation',
  'Describe what this subagent should do and when it should be used. (Be comprehensive for best results)':
    'Describe what this subagent should do and when it should be used. (Be comprehensive for best results)',
  'e.g., Expert code reviewer that reviews code based on best practices...':
    'e.g., Expert code reviewer that reviews code based on best practices...',
  'Generating subagent configuration...':
    'Generating subagent configuration...',
  'Failed to generate subagent: {{error}}':
    'Failed to generate subagent: {{error}}',
  'Step {{n}}: Describe Your Subagent': 'Step {{n}}: Describe Your Subagent',
  'Step {{n}}: Enter Subagent Name': 'Step {{n}}: Enter Subagent Name',
  'Step {{n}}: Enter System Prompt': 'Step {{n}}: Enter System Prompt',
  'Step {{n}}: Enter Description': 'Step {{n}}: Enter Description',
  // Agents - Tool Selection
  'Step {{n}}: Select Tools': 'Step {{n}}: Select Tools',
  'All Tools (Default)': 'All Tools (Default)',
  'All Tools': 'All Tools',
  'Read-only Tools': 'Read-only Tools',
  'Read & Edit Tools': 'Read & Edit Tools',
  'Read & Edit & Execution Tools': 'Read & Edit & Execution Tools',
  'All tools selected, including MCP tools':
    'All tools selected, including MCP tools',
  'Selected tools:': 'Selected tools:',
  'Read-only tools:': 'Read-only tools:',
  'Edit tools:': 'Edit tools:',
  'Execution tools:': 'Execution tools:',
  'Step {{n}}: Choose Background Color': 'Step {{n}}: Choose Background Color',
  'Step {{n}}: Confirm and Save': 'Step {{n}}: Confirm and Save',
  // Agents - Navigation & Instructions
  'Esc to cancel': 'Esc to cancel',
  'Press Enter to save, e to save and edit, Esc to go back':
    'Press Enter to save, e to save and edit, Esc to go back',
  'Press Enter to continue, {{navigation}}Esc to {{action}}':
    'Press Enter to continue, {{navigation}}Esc to {{action}}',
  cancel: 'cancel',
  'go back': 'go back',
  '↑↓ to navigate, ': '↑↓ to navigate, ',
  'Enter a clear, unique name for this subagent.':
    'Enter a clear, unique name for this subagent.',
  'e.g., Code Reviewer': 'e.g., Code Reviewer',
  'Name cannot be empty.': 'Name cannot be empty.',
  "Write the system prompt that defines this subagent's behavior. Be comprehensive for best results.":
    "Write the system prompt that defines this subagent's behavior. Be comprehensive for best results.",
  'e.g., You are an expert code reviewer...':
    'e.g., You are an expert code reviewer...',
  'System prompt cannot be empty.': 'System prompt cannot be empty.',
  'Describe when and how this subagent should be used.':
    'Describe when and how this subagent should be used.',
  'e.g., Reviews code for best practices and potential bugs.':
    'e.g., Reviews code for best practices and potential bugs.',
  'Description cannot be empty.': 'Description cannot be empty.',
  'Failed to launch editor: {{error}}': 'Failed to launch editor: {{error}}',
  'Failed to save and edit subagent: {{error}}':
    'Failed to save and edit subagent: {{error}}',

  // ============================================================================
  // Extensions - Management Dialog
  // ============================================================================
  'Manage Extensions': 'Manage Extensions',
  'Extension Details': 'Extension Details',
  'View Extension': 'View Extension',
  'Update Extension': 'Update Extension',
  'Disable Extension': 'Disable Extension',
  'Enable Extension': 'Enable Extension',
  'Uninstall Extension': 'Uninstall Extension',
  'Select Scope': 'Select Scope',
  'User Scope': 'User Scope',
  'Workspace Scope': 'Workspace Scope',
  'No extensions found.': 'No extensions found.',
  'Updating...': 'Updating...',
  Unknown: 'Unknown',
  Error: 'Error',
  'Stopped because': 'Stopped because',
  'Version:': 'Version:',
  'Status:': 'Status:',
  'Are you sure you want to uninstall extension "{{name}}"?':
    'Are you sure you want to uninstall extension "{{name}}"?',
  'This action cannot be undone.': 'This action cannot be undone.',
  'Extension "{{name}}" updated successfully.':
    'Extension "{{name}}" updated successfully.',
  // Extension dialog - missing keys
  'Name:': 'Name:',
  'MCP Servers:': 'MCP Servers:',
  'Settings:': 'Settings:',
  active: 'active',
  disabled: 'disabled',
  enabled: 'enabled',
  'disabled (bare mode)': 'disabled (bare mode)',
  'disabled (safe mode)': 'disabled (safe mode)',
  'disabled (disableAllHooks)': 'disabled (disableAllHooks)',
  'disabled (folder not trusted)': 'disabled (folder not trusted)',
  'disabled (turned off for this session)':
    'disabled (turned off for this session)',
  'View Details': 'View Details',
  'Update failed:': 'Update failed:',
  'Updating {{name}}...': 'Updating {{name}}...',
  'Update complete!': 'Update complete!',
  'User (global)': 'User (global)',
  'Workspace (project-specific)': 'Workspace (project-specific)',
  'Disable "{{name}}" - Select Scope': 'Disable "{{name}}" - Select Scope',
  'Enable "{{name}}" - Select Scope': 'Enable "{{name}}" - Select Scope',
  'No extension selected': 'No extension selected',
  '{{count}} extensions installed': '{{count}} extensions installed',
  "Use '/extensions install' to install your first extension.":
    "Use '/extensions install' to install your first extension.",
  // Update status values
  'up to date': 'up to date',
  'update available': 'update available',
  'checking...': 'checking...',
  'not updatable': 'not updatable',
  error: 'error',

  // ============================================================================
  // Commands - General (continued)
  // ============================================================================
  'View and edit Qwen Code settings': 'View and edit Qwen Code settings',
  Settings: 'Settings',
  'To see changes, Qwen Code must be restarted. Press r to exit and apply changes now.':
    'To see changes, Qwen Code must be restarted. Press r to exit and apply changes now.',
  // ============================================================================
  // Settings Labels
  // ============================================================================
  'Code Mode Only (Experimental)': 'Code Mode Only (Experimental)',
  'Vim Mode': 'Vim Mode',
  'Attribution: commit': 'Attribution: commit',
  'Terminal Bell Notification': 'Terminal Bell Notification',
  'Enable Usage Statistics': 'Enable Usage Statistics',
  Theme: 'Theme',
  'Preferred Editor': 'Preferred Editor',
  'Auto-connect to IDE': 'Auto-connect to IDE',
  'Debug Keystroke Logging': 'Debug Keystroke Logging',
  'Language: UI': 'Language: UI',
  'Language: Model': 'Language: Model',
  'Output Format': 'Output Format',
  'Hide Window Title': 'Hide Window Title',
  'Show Status in Title': 'Show Status in Title',
  'Hide Tips': 'Hide Tips',
  'Show Tool Call Arguments': 'Show Tool Call Arguments',
  'Show Line Numbers in Code': 'Show Line Numbers in Code',
  'Show Citations': 'Show Citations',
  'Custom Witty Phrases': 'Custom Witty Phrases',
  'Show Welcome Back Dialog': 'Show Welcome Back Dialog',
  'Enable User Feedback': 'Enable User Feedback',
  'How is Qwen doing this session? (optional)':
    'How is Qwen doing this session? (optional)',
  Bad: 'Bad',
  Fine: 'Fine',
  Good: 'Good',
  Dismiss: 'Dismiss',
  'Screen Reader Mode': 'Screen Reader Mode',
  'Max Session Turns': 'Max Session Turns',
  'Skip Next Speaker Check': 'Skip Next Speaker Check',
  'Skip Loop Detection': 'Skip Loop Detection',
  'Skip Startup Context': 'Skip Startup Context',
  'Enable OpenAI Logging': 'Enable OpenAI Logging',
  'OpenAI Logging Directory': 'OpenAI Logging Directory',
  Timeout: 'Timeout',
  'Max Retries': 'Max Retries',
  'Load Memory From Include Directories':
    'Load Memory From Include Directories',
  'Respect .gitignore': 'Respect .gitignore',
  'Respect .qwenignore': 'Respect .qwenignore',
  'Enable Recursive File Search': 'Enable Recursive File Search',
  'Interactive Shell (PTY)': 'Interactive Shell (PTY)',
  'Show Color': 'Show Color',
  'Auto Accept': 'Auto Accept',
  'Use Ripgrep': 'Use Ripgrep',
  'Use Builtin Ripgrep': 'Use Builtin Ripgrep',
  'Tool Output Truncation Threshold': 'Tool Output Truncation Threshold',
  'Tool Output Truncation Lines': 'Tool Output Truncation Lines',
  'Folder Trust': 'Folder Trust',
  'Tool Schema Compliance': 'Tool Schema Compliance',
  Unset: 'Unset',
  // Settings enum options
  'Auto (detect from system)': 'Auto (detect from system)',
  'Auto (follow user input)': 'Auto (follow user input)',
  'Auto (detect terminal theme)': 'Auto (detect terminal theme)',
  Auto: 'Auto',
  Text: 'Text',
  JSON: 'JSON',
  Plan: 'Plan',
  'Ask permissions': 'Ask permissions',
  'Auto Edit': 'Auto Edit',
  YOLO: 'YOLO',
  'toggle vim mode on/off': 'toggle vim mode on/off',
  'Show usage statistics dashboard.': 'Show usage statistics dashboard.',
  'Show model-specific usage statistics.':
    'Show model-specific usage statistics.',
  'Show tool-specific usage statistics.':
    'Show tool-specific usage statistics.',
  'Show skill-specific usage statistics.':
    'Show skill-specific usage statistics.',
  'Show daily token usage statistics.': 'Show daily token usage statistics.',
  'Show monthly token usage statistics.':
    'Show monthly token usage statistics.',
  'Export token usage statistics to CSV or JSON.':
    'Export token usage statistics to CSV or JSON.',
  'No usage data.': 'No usage data.',
  '{{label}}: {{tokens}} tokens ({{requests}} requests)':
    '{{label}}: {{tokens}} tokens ({{requests}} requests)',
  'Daily token usage for {{value}}': 'Daily token usage for {{value}}',
  'Monthly token usage for {{value}}': 'Monthly token usage for {{value}}',
  'Total: {{tokens}} tokens': 'Total: {{tokens}} tokens',
  'Requests: {{requests}}': 'Requests: {{requests}}',
  'Breakdown:': 'Breakdown:',
  'Input: {{tokens}}': 'Input: {{tokens}}',
  'Output: {{tokens}}': 'Output: {{tokens}}',
  'Cached (included in Input): {{tokens}}':
    'Cached (included in Input): {{tokens}}',
  'Thoughts: {{tokens}}': 'Thoughts: {{tokens}}',
  'By model:': 'By model:',
  'By auth type:': 'By auth type:',
  'By model/auth type:': 'By model/auth type:',
  'By source:': 'By source:',
  'Failed to load token usage stats: {{error}}':
    'Failed to load token usage stats: {{error}}',
  'Expected --format csv or --format json.':
    'Expected --format csv or --format json.',
  'Expected a file path after --output.':
    'Expected a file path after --output.',
  'Unexpected argument: {{argument}}': 'Unexpected argument: {{argument}}',
  'Usage: /stats export <daily|monthly> [YYYY-MM-DD|YYYY-MM] [--format csv|json] [--output path]':
    'Usage: /stats export <daily|monthly> [YYYY-MM-DD|YYYY-MM] [--format csv|json] [--output path]',
  'Token usage export path must be within the project working directory.':
    'Token usage export path must be within the project working directory.',
  'Export target does not exist: {{path}}':
    'Export target does not exist: {{path}}',
  'Cannot resolve export path within the working directory.':
    'Cannot resolve export path within the working directory.',
  'Could not create a temporary export file.':
    'Could not create a temporary export file.',
  'Token usage exported to {{format}}: {{path}}':
    'Token usage exported to {{format}}: {{path}}',
  'Failed to export token usage stats: {{error}}':
    'Failed to export token usage stats: {{error}}',
  'Unclosed quote in arguments.': 'Unclosed quote in arguments.',
  'Note: generation timing (TTFT/TPS) belongs to generation metrics.':
    'Note: generation timing (TTFT/TPS) belongs to generation metrics.',
  'exit the cli': 'exit the cli',
  'Manage workspace directories': 'Manage workspace directories',
  'Add directories to the workspace. Use comma to separate multiple paths':
    'Add directories to the workspace. Use comma to separate multiple paths',
  'Show all directories in the workspace':
    'Show all directories in the workspace',
  'set external editor preference': 'set external editor preference',
  'Select Editor': 'Select Editor',
  'Editor Preference': 'Editor Preference',
  'These editors are currently supported. Please note that some editors cannot be used in sandbox mode.':
    'These editors are currently supported. Please note that some editors cannot be used in sandbox mode.',
  'Your preferred editor is:': 'Your preferred editor is:',
  'Manage extensions': 'Manage extensions',
  'Manage installed extensions': 'Manage installed extensions',
  'Disable an extension': 'Disable an extension',
  'Enable an extension': 'Enable an extension',
  'Install an extension from a git repo or local path':
    'Install an extension from a git repo or local path',
  'Uninstall an extension': 'Uninstall an extension',
  'No extensions installed.': 'No extensions installed.',
  'Extension "{{name}}" not found.': 'Extension "{{name}}" not found.',
  'The scope to install the extension in: "user" (global, default) or "project" (current workspace only).':
    'The scope to install the extension in: "user" (global, default) or "project" (current workspace only).',
  'Extension "{{name}}" installed successfully and enabled for the current workspace.':
    'Extension "{{name}}" installed successfully and enabled for the current workspace.',
  'Marketplace "{{name}}" not found.': 'Marketplace "{{name}}" not found.',
  'No marketplace sources added yet.': 'No marketplace sources added yet.',
  'No marketplaces added yet.': 'No marketplaces added yet.',
  'Adds a marketplace source (Claude format).':
    'Adds a marketplace source (Claude format).',
  'The marketplace source to add: owner/repo (GitHub), a git or https URL, or a local path.':
    'The marketplace source to add: owner/repo (GitHub), a git or https URL, or a local path.',
  'Removes a marketplace source.': 'Removes a marketplace source.',
  'The name of the marketplace to remove.':
    'The name of the marketplace to remove.',
  'Lists configured marketplace sources.':
    'Lists configured marketplace sources.',
  'Re-fetches a marketplace source and its plugin listing.':
    'Re-fetches a marketplace source and its plugin listing.',
  'The name of the marketplace to update.':
    'The name of the marketplace to update.',
  'Manage marketplace sources for discovering extensions.':
    'Manage marketplace sources for discovering extensions.',
  'You need at least one command before continuing.':
    'You need at least one command before continuing.',
  'No extensions to update.': 'No extensions to update.',
  'Usage: /extensions install <source>': 'Usage: /extensions install <source>',
  'Installing extension from "{{source}}"...':
    'Installing extension from "{{source}}"...',
  'Extension "{{name}}" installed successfully.':
    'Extension "{{name}}" installed successfully.',
  'Failed to install extension from "{{source}}": {{error}}':
    'Failed to install extension from "{{source}}": {{error}}',
  'Do you want to continue? [Y/n]: ': 'Do you want to continue? [Y/n]: ',
  'Do you want to continue?': 'Do you want to continue?',
  'Installing extension "{{name}}".': 'Installing extension "{{name}}".',
  '**Extensions may introduce unexpected behavior. Ensure you have investigated the extension source and trust the author.**':
    '**Extensions may introduce unexpected behavior. Ensure you have investigated the extension source and trust the author.**',
  'This extension will run the following MCP servers:':
    'This extension will run the following MCP servers:',
  local: 'local',
  remote: 'remote',
  'This extension will add the following commands: {{commands}}.':
    'This extension will add the following commands: {{commands}}.',
  'This extension will append info to your QWEN.md context using {{fileName}}':
    'This extension will append info to your QWEN.md context using {{fileName}}',
  'This extension will install the following skills:':
    'This extension will install the following skills:',
  'This extension will install the following subagents:':
    'This extension will install the following subagents:',
  'This extension will install the following workflows (JavaScript scripts that can start subagents):':
    'This extension will install the following workflows (JavaScript scripts that can start subagents):',
  'These workflow scripts changed since the installed version: {{names}}.':
    'These workflow scripts changed since the installed version: {{names}}.',
  'Installation cancelled for "{{name}}".':
    'Installation cancelled for "{{name}}".',
  'You are installing an extension from {{originSource}}. Some features may not work perfectly with Qwen Code.':
    'You are installing an extension from {{originSource}}. Some features may not work perfectly with Qwen Code.',
  '--ref and --auto-update are not applicable for marketplace extensions.':
    '--ref and --auto-update are not applicable for marketplace extensions.',
  'Extension "{{name}}" installed successfully and enabled.':
    'Extension "{{name}}" installed successfully and enabled.',
  'The github URL, local path, or marketplace source (marketplace-url:plugin-name) of the extension to install.':
    'The github URL, local path, or marketplace source (marketplace-url:plugin-name) of the extension to install.',
  'The git ref to install from.': 'The git ref to install from.',
  '--registry is only applicable for npm extensions.':
    '--registry is only applicable for npm extensions.',
  'Custom npm registry URL (only for npm extensions).':
    'Custom npm registry URL (only for npm extensions).',
  '--ref is not applicable for npm extensions. Use @version suffix instead (e.g. @scope/package@1.2.0).':
    '--ref is not applicable for npm extensions. Use @version suffix instead (e.g. @scope/package@1.2.0).',
  'Installs an extension from a git repository URL, local path, scoped npm package (@scope/name), or claude marketplace (marketplace-url:plugin-name).':
    'Installs an extension from a git repository URL, local path, scoped npm package (@scope/name), or claude marketplace (marketplace-url:plugin-name).',
  Description: 'Description',
  'Delete Session': 'Delete Session',
  'Enable auto-update for this extension.':
    'Enable auto-update for this extension.',
  'Enable pre-release versions for this extension.':
    'Enable pre-release versions for this extension.',
  'Acknowledge the security risks of installing an extension and skip the confirmation prompt.':
    'Acknowledge the security risks of installing an extension and skip the confirmation prompt.',
  'The source argument must be provided.':
    'The source argument must be provided.',
  'Extension "{{name}}" successfully uninstalled.':
    'Extension "{{name}}" successfully uninstalled.',
  'Uninstalls an extension.': 'Uninstalls an extension.',
  'The name or source path of the extension to uninstall.':
    'The name or source path of the extension to uninstall.',
  'Please include the name of the extension to uninstall as a positional argument.':
    'Please include the name of the extension to uninstall as a positional argument.',
  'Enables an extension.': 'Enables an extension.',
  'The name of the extension to enable.':
    'The name of the extension to enable.',
  'The scope to enable the extension in. If not set, will be enabled in all scopes.':
    'The scope to enable the extension in. If not set, will be enabled in all scopes.',
  'Extension "{{name}}" successfully enabled for scope "{{scope}}".':
    'Extension "{{name}}" successfully enabled for scope "{{scope}}".',
  'Extension "{{name}}" successfully enabled in all scopes.':
    'Extension "{{name}}" successfully enabled in all scopes.',
  'Invalid scope: {{scope}}. Please use one of {{scopes}}.':
    'Invalid scope: {{scope}}. Please use one of {{scopes}}.',
  'Disables an extension.': 'Disables an extension.',
  'The name of the extension to disable.':
    'The name of the extension to disable.',
  'The scope to disable the extension in.':
    'The scope to disable the extension in.',
  'Extension "{{name}}" successfully disabled for scope "{{scope}}".':
    'Extension "{{name}}" successfully disabled for scope "{{scope}}".',
  'Extension "{{name}}" successfully updated: {{oldVersion}} → {{newVersion}}.':
    'Extension "{{name}}" successfully updated: {{oldVersion}} → {{newVersion}}.',
  'Unable to install extension "{{name}}" due to missing install metadata':
    'Unable to install extension "{{name}}" due to missing install metadata',
  'Extension "{{name}}" is already up to date.':
    'Extension "{{name}}" is already up to date.',
  'Updates all extensions or a named extension to the latest version.':
    'Updates all extensions or a named extension to the latest version.',
  'Update all extensions.': 'Update all extensions.',
  'The name of the extension to update.':
    'The name of the extension to update.',
  'Either an extension name or --all must be provided':
    'Either an extension name or --all must be provided',
  'List installed extensions': 'List installed extensions',
  'Lists installed extensions.': 'Lists installed extensions.',
  'Path:': 'Path:',
  'Source:': 'Source:',
  'Type:': 'Type:',
  'Ref:': 'Ref:',
  'Release tag:': 'Release tag:',
  'Enabled (User):': 'Enabled (User):',
  'Enabled (Workspace):': 'Enabled (Workspace):',
  'Context files:': 'Context files:',
  'Skills:': 'Skills:',
  'Agents:': 'Agents:',
  'Workflows:': 'Workflows:',
  'MCP servers:': 'MCP servers:',
  'Link extension failed to install.': 'Link extension failed to install.',
  'Extension "{{name}}" linked successfully and enabled.':
    'Extension "{{name}}" linked successfully and enabled.',
  'Links an extension from a local path. Updates made to the local path will always be reflected.':
    'Links an extension from a local path. Updates made to the local path will always be reflected.',
  'The name of the extension to link.': 'The name of the extension to link.',
  'Set a specific setting for an extension.':
    'Set a specific setting for an extension.',
  'Name of the extension to configure.': 'Name of the extension to configure.',
  'The setting to configure (name or env var).':
    'The setting to configure (name or env var).',
  'The scope to set the setting in.': 'The scope to set the setting in.',
  'List all settings for an extension.': 'List all settings for an extension.',
  'Name of the extension.': 'Name of the extension.',
  'Extension "{{name}}" has no settings to configure.':
    'Extension "{{name}}" has no settings to configure.',
  'Settings for "{{name}}":': 'Settings for "{{name}}":',
  '(workspace)': '(workspace)',
  '(user)': '(user)',
  '[not set]': '[not set]',
  '[value stored in keychain]': '[value stored in keychain]',
  'Value:': 'Value:',
  'Manage extension settings': 'Manage extension settings',
  'Manage extension settings.': 'Manage extension settings.',
  'You need to specify a command (set or list).':
    'You need to specify a command (set or list).',
  // ============================================================================
  // Plugin Choice / Marketplace
  // ============================================================================
  'No plugins available in this marketplace.':
    'No plugins available in this marketplace.',
  'Select a plugin to install from marketplace "{{name}}":':
    'Select a plugin to install from marketplace "{{name}}":',
  'Plugin selection cancelled.': 'Plugin selection cancelled.',
  'Select a plugin from "{{name}}"': 'Select a plugin from "{{name}}"',
  'Use ↑↓ or j/k to navigate, Enter to select, Escape to cancel':
    'Use ↑↓ or j/k to navigate, Enter to select, Escape to cancel',
  '{{count}} more above': '{{count}} more above',
  '{{count}} more below': '{{count}} more below',
  'manage IDE integration': 'manage IDE integration',
  'check status of IDE integration': 'check status of IDE integration',
  'install required IDE companion for {{ideName}}':
    'install required IDE companion for {{ideName}}',
  'enable IDE integration': 'enable IDE integration',
  'disable IDE integration': 'disable IDE integration',
  'IDE integration is not supported in your current environment. To use this feature, run Qwen Code in one of these supported IDEs: VS Code or VS Code forks.':
    'IDE integration is not supported in your current environment. To use this feature, run Qwen Code in one of these supported IDEs: VS Code or VS Code forks.',
  'Set up GitHub Actions': 'Set up GitHub Actions',
  'Configure terminal keybindings for multiline input (VS Code, Cursor, Windsurf, Trae)':
    'Configure terminal keybindings for multiline input (VS Code, Cursor, Windsurf, Trae)',
  'Please restart your terminal for the changes to take effect.':
    'Please restart your terminal for the changes to take effect.',
  'Failed to configure terminal: {{error}}':
    'Failed to configure terminal: {{error}}',
  'Could not determine {{terminalName}} config path on Windows: APPDATA environment variable is not set.':
    'Could not determine {{terminalName}} config path on Windows: APPDATA environment variable is not set.',
  '{{terminalName}} keybindings.json exists but is not a valid JSON array. Please fix the file manually or delete it to allow automatic configuration.':
    '{{terminalName}} keybindings.json exists but is not a valid JSON array. Please fix the file manually or delete it to allow automatic configuration.',
  'File: {{file}}': 'File: {{file}}',
  'Failed to parse {{terminalName}} keybindings.json. The file contains invalid JSON. Please fix the file manually or delete it to allow automatic configuration.':
    'Failed to parse {{terminalName}} keybindings.json. The file contains invalid JSON. Please fix the file manually or delete it to allow automatic configuration.',
  'Error: {{error}}': 'Error: {{error}}',
  'Shift+Enter binding already exists': 'Shift+Enter binding already exists',
  'Ctrl+Enter binding already exists': 'Ctrl+Enter binding already exists',
  'Existing keybindings detected. Will not modify to avoid conflicts.':
    'Existing keybindings detected. Will not modify to avoid conflicts.',
  'Please check and modify manually if needed: {{file}}':
    'Please check and modify manually if needed: {{file}}',
  'Added Shift+Enter and Ctrl+Enter keybindings to {{terminalName}}.':
    'Added Shift+Enter and Ctrl+Enter keybindings to {{terminalName}}.',
  'Modified: {{file}}': 'Modified: {{file}}',
  '{{terminalName}} keybindings already configured.':
    '{{terminalName}} keybindings already configured.',
  'Failed to configure {{terminalName}}.':
    'Failed to configure {{terminalName}}.',
  'Your terminal is already configured for an optimal experience with multiline input (Shift+Enter and Ctrl+Enter).':
    'Your terminal is already configured for an optimal experience with multiline input (Shift+Enter and Ctrl+Enter).',
  // ============================================================================
  // Commands - Hooks
  // ============================================================================
  'Manage Qwen Code hooks': 'Manage Qwen Code hooks',
  'List all configured hooks': 'List all configured hooks',
  // Hooks - Dialog
  Hooks: 'Hooks',
  'Loading hooks...': 'Loading hooks...',
  'Error loading hooks:': 'Error loading hooks:',
  'Press Escape to close': 'Press Escape to close',
  'Press Escape, Ctrl+C, or Ctrl+D to cancel':
    'Press Escape, Ctrl+C, or Ctrl+D to cancel',
  'Press Space, Enter, or Escape to dismiss':
    'Press Space, Enter, or Escape to dismiss',
  'No hook selected': 'No hook selected',
  // Hooks - List Step
  'No hook events found.': 'No hook events found.',
  '{{count}} hook configured': '{{count}} hook configured',
  '{{count}} hooks configured': '{{count}} hooks configured',
  'This menu is read-only. To add or modify hooks, edit settings.json directly or ask Qwen Code.':
    'This menu is read-only. To add or modify hooks, edit settings.json directly or ask Qwen Code.',
  'Reopen this menu to reload hook definitions.':
    'Reopen this menu to reload hook definitions.',
  'Hook controls and HTTP security settings require a restart.':
    'Hook controls and HTTP security settings require a restart.',
  'Failed to reload hook definitions: {{error}}':
    'Failed to reload hook definitions: {{error}}',
  'Enter to select · Esc to cancel': 'Enter to select · Esc to cancel',
  // Hooks - Detail Step
  'Exit codes:': 'Exit codes:',
  'Configured hooks:': 'Configured hooks:',
  'No hooks configured for this event.': 'No hooks configured for this event.',
  'To add hooks, edit settings.json directly or ask Qwen.':
    'To add hooks, edit settings.json directly or ask Qwen.',
  'Enter to select · Esc to go back': 'Enter to select · Esc to go back',
  // Hooks - Config Detail Step
  'Hook details': 'Hook details',
  'Event:': 'Event:',
  'Extension:': 'Extension:',
  'Desc:': 'Desc:',
  'No hook config selected': 'No hook config selected',
  'To modify or remove this hook, edit settings.json directly or ask Qwen to help.':
    'To modify or remove this hook, edit settings.json directly or ask Qwen to help.',
  'Safe mode is on, so no hooks run in this session.':
    'Safe mode is on, so no hooks run in this session.',
  'Bare mode is on, so no hooks run in this session.':
    'Bare mode is on, so no hooks run in this session.',
  'All hooks are disabled by the disableAllHooks setting.':
    'All hooks are disabled by the disableAllHooks setting.',
  'Timeout:': 'Timeout:',
  'Status message:': 'Status message:',
  'Condition:': 'Condition:',
  'Options:': 'Options:',
  'Skill:': 'Skill:',
  'runs in background': 'runs in background',
  'runs once': 'runs once',
  sequential: 'sequential',
  // Hooks - Disabled Step
  'Hook Configuration - Disabled': 'Hook Configuration - Disabled',
  'All hooks are currently disabled. You have {{count}} that are not running.':
    'All hooks are currently disabled. You have {{count}} that are not running.',
  '{{count}} configured hook': '{{count}} configured hook',
  '{{count}} configured hooks': '{{count}} configured hooks',
  'When hooks are disabled:': 'When hooks are disabled:',
  'No hook commands will execute': 'No hook commands will execute',
  'StatusLine will not be displayed': 'StatusLine will not be displayed',
  'Tool operations will proceed without hook validation':
    'Tool operations will proceed without hook validation',
  'To re-enable hooks, remove "disableAllHooks" from settings.json or ask Qwen Code.':
    'To re-enable hooks, remove "disableAllHooks" from settings.json or ask Qwen Code.',
  // Hooks - Source
  Project: 'Project',
  User: 'User',
  Skill: 'Skill',
  System: 'System',
  Extension: 'Extension',
  'Local Settings': 'Local Settings',
  'User Settings': 'User Settings',
  'System Settings': 'System Settings',
  Extensions: 'Extensions',
  'Session (temporary)': 'Session (temporary)',
  // Hooks - Event Descriptions (short)
  'Before tool execution': 'Before tool execution',
  'After tool execution': 'After tool execution',
  'After tool execution fails': 'After tool execution fails',
  'When notifications are sent': 'When notifications are sent',
  'When the user submits a prompt': 'When the user submits a prompt',
  'When a slash command expands into a prompt':
    'When a slash command expands into a prompt',
  'When a new session is started': 'When a new session is started',
  'Right before Qwen Code concludes its response':
    'Right before Qwen Code concludes its response',
  'When a subagent (Agent tool call) is started':
    'When a subagent (Agent tool call) is started',
  'Right before a subagent concludes its response':
    'Right before a subagent concludes its response',
  'Before conversation compaction': 'Before conversation compaction',
  'When a session is ending': 'When a session is ending',
  'When a permission dialog is displayed':
    'When a permission dialog is displayed',
  'When a new todo item is created': 'When a new todo item is created',
  'When a todo item is marked as completed':
    'When a todo item is marked as completed',
  // Hooks - Event Descriptions (detailed)
  'Input to command is JSON of tool call arguments.':
    'Input to command is JSON of tool call arguments.',
  'Input to command is JSON with fields "inputs" (tool call arguments) and "response" (tool call response).':
    'Input to command is JSON with fields "inputs" (tool call arguments) and "response" (tool call response).',
  'Input to command is JSON with tool_name, tool_input, tool_use_id, error, error_type, is_interrupt, and is_timeout.':
    'Input to command is JSON with tool_name, tool_input, tool_use_id, error, error_type, is_interrupt, and is_timeout.',
  'Input to command is JSON with notification message and type.':
    'Input to command is JSON with notification message and type.',
  'Input to command is JSON with "prompt" (the current model-bound prompt) and optional "submitted_prompt" (the text projection captured at a supported submission boundary).':
    'Input to command is JSON with "prompt" (the current model-bound prompt) and optional "submitted_prompt" (the text projection captured at a supported submission boundary).',
  'Input to command is JSON with command_name, command_args, and expanded prompt text.':
    'Input to command is JSON with command_name, command_args, and expanded prompt text.',
  'Input to command is JSON with session start source.':
    'Input to command is JSON with session start source.',
  'Input to command is JSON with session end reason.':
    'Input to command is JSON with session end reason.',
  'Input to command is JSON with agent_id and agent_type.':
    'Input to command is JSON with agent_id and agent_type.',
  'Input to command is JSON with agent_id, agent_type, and agent_transcript_path.':
    'Input to command is JSON with agent_id, agent_type, and agent_transcript_path.',
  'Input to command is JSON with compaction details.':
    'Input to command is JSON with compaction details.',
  'Input to command is JSON with tool_name, tool_input, and tool_use_id. Output JSON with hookSpecificOutput containing decision to allow or deny.':
    'Input to command is JSON with tool_name, tool_input, and tool_use_id. Output JSON with hookSpecificOutput containing decision to allow or deny.',
  'Input to command is JSON with todo_id, todo_content, todo_status, all_todos, and phase. In validation, output JSON with decision (allow/block/deny) and reason. In postWrite, block/deny is ignored.':
    'Input to command is JSON with todo_id, todo_content, todo_status, all_todos, and phase. In validation, output JSON with decision (allow/block/deny) and reason. In postWrite, block/deny is ignored.',
  'Input to command is JSON with todo_id, todo_content, previous_status, all_todos, and phase. In validation, output JSON with decision (allow/block/deny) and reason. In postWrite, block/deny is ignored.':
    'Input to command is JSON with todo_id, todo_content, previous_status, all_todos, and phase. In validation, output JSON with decision (allow/block/deny) and reason. In postWrite, block/deny is ignored.',
  // Hooks - Exit Code Descriptions
  'stdout/stderr not shown': 'stdout/stderr not shown',
  'show stderr to model and continue conversation':
    'show stderr to model and continue conversation',
  'show stderr to user only': 'show stderr to user only',
  'stdout shown in transcript mode (ctrl+o)':
    'stdout shown in transcript mode (ctrl+o)',
  'show stderr to model immediately': 'show stderr to model immediately',
  'show stderr to user only but continue with tool call':
    'show stderr to user only but continue with tool call',
  'block processing, erase original prompt, and show stderr to user only':
    'block processing, erase original prompt, and show stderr to user only',
  'block expanded prompt submission and show stderr to user only':
    'block expanded prompt submission and show stderr to user only',
  'stdout shown to Qwen': 'stdout shown to Qwen',
  'show stderr to user only (blocking errors ignored)':
    'show stderr to user only (blocking errors ignored)',
  'command completes successfully': 'command completes successfully',
  'stdout shown to subagent': 'stdout shown to subagent',
  'show stderr to subagent and continue having it run':
    'show stderr to subagent and continue having it run',
  'stdout appended as custom compact instructions':
    'stdout appended as custom compact instructions',
  'block compaction': 'block compaction',
  'show stderr to user only but continue with compaction':
    'show stderr to user only but continue with compaction',
  'use hook decision if provided': 'use hook decision if provided',
  'allow todo creation': 'allow todo creation',
  'block todo creation and show reason to model':
    'block todo creation and show reason to model',
  'allow todo completion': 'allow todo completion',
  'block todo completion and show reason to model':
    'block todo completion and show reason to model',
  // Hooks - Messages
  'Config not loaded.': 'Config not loaded.',
  'Hooks are not enabled. Enable hooks in settings to use this feature.':
    'Hooks are not enabled. Enable hooks in settings to use this feature.',
  // ============================================================================
  // Commands - Session Export
  // ============================================================================
  'Export current session message history to a file':
    'Export current session message history to a file',
  'Export session to HTML format': 'Export session to HTML format',
  'Export session to JSON format': 'Export session to JSON format',
  'Export session to JSONL format (one message per line)':
    'Export session to JSONL format (one message per line)',
  'Export session to markdown format': 'Export session to markdown format',

  // ============================================================================
  // Commands - Insights
  // ============================================================================
  'generate personalized programming insights from your chat history':
    'generate personalized programming insights from your chat history',

  // ============================================================================
  // Commands - Session History
  // ============================================================================
  'Resume a previous session': 'Resume a previous session',
  'Fork the current conversation into a new session':
    'Fork the current conversation into a new session',
  'Spawn a background agent that inherits the full conversation':
    'Spawn a background agent that inherits the full conversation',
  'Please provide a directive. Usage: /fork <directive>':
    'Please provide a directive. Usage: /fork <directive>',
  'Cannot fork while a response or tool call is in progress. Wait for it to finish or resolve the pending tool call.':
    'Cannot fork while a response or tool call is in progress. Wait for it to finish or resolve the pending tool call.',
  'Cannot fork before the first conversation turn.':
    'Cannot fork before the first conversation turn.',
  'The agent tool is unavailable; cannot fork.':
    'The agent tool is unavailable; cannot fork.',
  'Failed to launch fork: {{error}}': 'Failed to launch fork: {{error}}',
  'the background agent could not be started.':
    'the background agent could not be started.',
  'User launched a background fork via /fork: {{directive}}':
    'User launched a background fork via /fork: {{directive}}',
  'Forked into a background agent. It inherits this conversation and runs without blocking — track it in the background tasks panel; it reports back when done.':
    'Forked into a background agent. It inherits this conversation and runs without blocking — track it in the background tasks panel; it reports back when done.',
  'Cannot branch while a response or tool call is in progress. Wait for it to finish or resolve the pending tool call.':
    'Cannot branch while a response or tool call is in progress. Wait for it to finish or resolve the pending tool call.',
  'No conversation to branch.': 'No conversation to branch.',
  'Restore a tool call. This will reset the conversation and file history to the state it was in when the tool call was suggested':
    'Restore a tool call. This will reset the conversation and file history to the state it was in when the tool call was suggested',
  'Could not detect terminal type. Supported terminals: VS Code, Cursor, Windsurf, and Trae.':
    'Could not detect terminal type. Supported terminals: VS Code, Cursor, Windsurf, and Trae.',
  'Terminal "{{terminal}}" is not supported yet.':
    'Terminal "{{terminal}}" is not supported yet.',

  // === History collapse/expand commands ===
  'Set history to collapse by default when resuming a session':
    'Set history to collapse by default when resuming a session',
  'Set history to expand by default when resuming a session':
    'Set history to expand by default when resuming a session',
  'Expand the currently collapsed history transcript':
    'Expand the currently collapsed history transcript',
  'Control history display preferences and visibility':
    'Control history display preferences and visibility',
  'History will be collapsed by default for future resumed sessions.':
    'History will be collapsed by default for future resumed sessions.',
  'History will be expanded by default for future resumed sessions.':
    'History will be expanded by default for future resumed sessions.',
  'History is already expanded in this session.':
    'History is already expanded in this session.',
  'Usage: /history collapse-on-resume|expand-on-resume|expand-now':
    'Usage: /history collapse-on-resume|expand-on-resume|expand-now',
  'History collapsed: {{n}} messages hidden. Use /history expand-now to show.':
    'History collapsed: {{n}} messages hidden. Use /history expand-now to show.',

  // ============================================================================
  // Commands - Language
  // ============================================================================
  'Invalid language. Available: {{options}}':
    'Invalid language. Available: {{options}}',
  'Language subcommands do not accept additional arguments.':
    'Language subcommands do not accept additional arguments.',
  'Current UI language: {{lang}}': 'Current UI language: {{lang}}',
  'Current LLM output language: {{lang}}':
    'Current LLM output language: {{lang}}',
  'Set UI language': 'Set UI language',
  'Set LLM output language': 'Set LLM output language',
  'Usage: /language ui [{{options}}]': 'Usage: /language ui [{{options}}]',
  'Usage: /language output <language>': 'Usage: /language output <language>',
  'Example: /language output 中文': 'Example: /language output 中文',
  'Example: /language output English': 'Example: /language output English',
  'Example: /language output 日本語': 'Example: /language output 日本語',
  'UI language changed to {{lang}}': 'UI language changed to {{lang}}',
  'LLM output language set to {{lang}}': 'LLM output language set to {{lang}}',
  'Please restart the application for the changes to take effect.':
    'Please restart the application for the changes to take effect.',
  'Failed to generate LLM output language rule file: {{error}}':
    'Failed to generate LLM output language rule file: {{error}}',
  'Invalid command. Available subcommands:':
    'Invalid command. Available subcommands:',
  'Available subcommands:': 'Available subcommands:',
  'To request additional UI language packs, please open an issue on GitHub.':
    'To request additional UI language packs, please open an issue on GitHub.',
  'Available options:': 'Available options:',
  'Set UI language to {{name}}': 'Set UI language to {{name}}',

  // ============================================================================
  // Commands - Approval Mode
  // ============================================================================
  'Tool Approval Mode': 'Tool Approval Mode',
  'Analyze only, do not modify files or execute commands':
    'Analyze only, do not modify files or execute commands',
  'Require approval for file edits or shell commands':
    'Require approval for file edits or shell commands',
  'Automatically approve file edits': 'Automatically approve file edits',
  'Use classifier to automatically approve safe tool calls':
    'Use classifier to automatically approve safe tool calls',
  'Automatically approve all tools': 'Automatically approve all tools',
  'Workspace approval mode exists and takes priority. User-level change will have no effect.':
    'Workspace approval mode exists and takes priority. User-level change will have no effect.',
  'Apply To': 'Apply To',
  'Workspace Settings': 'Workspace Settings',
  'Open auto-memory folder': 'Open auto-memory folder',
  'Auto-memory: {{status}}': 'Auto-memory: {{status}}',
  'Auto-dream: {{status}} · {{lastDream}} · /dream to run':
    'Auto-dream: {{status}} · {{lastDream}} · /dream to run',
  'Auto-skill: {{status}}': 'Auto-skill: {{status}}',
  never: 'never',
  on: 'on',
  off: 'off',
  'Remove matching entries from managed auto-memory.':
    'Remove matching entries from managed auto-memory.',
  'Usage: /forget <memory text to remove>':
    'Usage: /forget <memory text to remove>',
  'No managed auto-memory entries matched: {{query}}':
    'No managed auto-memory entries matched: {{query}}',
  'Consolidate managed auto-memory topic files.':
    'Consolidate managed auto-memory topic files.',
  'Import MCP servers from Claude configs':
    'Import MCP servers from Claude configs',
  'Open MCP management dialog': 'Open MCP management dialog',
  'Could not retrieve tool registry.': 'Could not retrieve tool registry.',
  "Successfully authenticated and refreshed tools for '{{name}}'.":
    "Successfully authenticated and refreshed tools for '{{name}}'.",
  "Re-discovering tools from '{{name}}'...":
    "Re-discovering tools from '{{name}}'...",
  "Discovered {{count}} tool(s) from '{{name}}'.":
    "Discovered {{count}} tool(s) from '{{name}}'.",
  'Authentication complete. Returning to server details...':
    'Authentication complete. Returning to server details...',
  'Authentication successful.': 'Authentication successful.',
  // ============================================================================
  // MCP Management Dialog
  // ============================================================================
  'Manage MCP servers': 'Manage MCP servers',
  'Server Detail': 'Server Detail',
  Tools: 'Tools',
  'Tool Detail': 'Tool Detail',
  'Loading...': 'Loading...',
  'Unknown step': 'Unknown step',
  'Esc to back': 'Esc to back',
  '↑↓ to navigate · Enter to select · Esc to close':
    '↑↓ to navigate · Enter to select · Esc to close',
  '↑↓ to navigate · Enter to select · Esc to back':
    '↑↓ to navigate · Enter to select · Esc to back',
  '↑↓ to navigate · Enter to confirm · Esc to back':
    '↑↓ to navigate · Enter to confirm · Esc to back',
  'User Settings (global)': 'User Settings (global)',
  'Workspace Settings (project-specific)':
    'Workspace Settings (project-specific)',
  'Disable server:': 'Disable server:',
  'Select where to add the server to the exclude list:':
    'Select where to add the server to the exclude list:',
  'Press Enter to confirm, Esc to cancel':
    'Press Enter to confirm, Esc to cancel',
  'View tools': 'View tools',
  'View resources': 'View resources',
  Reconnect: 'Reconnect',
  Enable: 'Enable',
  Disable: 'Disable',
  Authenticate: 'Authenticate',
  'Re-authenticate': 'Re-authenticate',
  'Clear Authentication': 'Clear Authentication',
  'Server:': 'Server:',
  'Command:': 'Command:',
  'Working Directory:': 'Working Directory:',
  'No server selected': 'No server selected',
  prompts: 'prompts',
  'Error:': 'Error:',
  tool: 'tool',
  tools: 'tools',
  resource: 'resource',
  resources: 'resources',
  connected: 'connected',
  connecting: 'connecting',
  disconnected: 'disconnected',
  'needs authentication': 'needs authentication',

  // MCP Server List
  'User MCPs': 'User MCPs',
  'Project MCPs': 'Project MCPs',
  'Extension MCPs': 'Extension MCPs',
  server: 'server',
  servers: 'servers',
  'Add MCP servers to your settings to get started.':
    'Add MCP servers to your settings to get started.',
  'Run qwen --debug to see error logs': 'Run qwen --debug to see error logs',

  // MCP OAuth Authentication
  'OAuth Authentication': 'OAuth Authentication',
  'Authenticating... Please complete the login in your browser.':
    'Authenticating... Please complete the login in your browser.',
  'Press c to copy the authorization URL to your clipboard.':
    'Press c to copy the authorization URL to your clipboard.',
  'Copy request sent to your terminal. If paste is empty, copy the URL above manually.':
    'Copy request sent to your terminal. If paste is empty, copy the URL above manually.',
  'Cannot write to terminal — copy the URL above manually.':
    'Cannot write to terminal — copy the URL above manually.',
  // MCP Tool List
  'No tools available for this server.': 'No tools available for this server.',
  destructive: 'destructive',
  'read-only': 'read-only',
  'open-world': 'open-world',
  idempotent: 'idempotent',
  'Tools for {{serverName}}': 'Tools for {{serverName}}',
  '{{current}}/{{total}}': '{{current}}/{{total}}',

  // MCP Tool Detail
  required: 'required',
  Parameters: 'Parameters',
  'No tool selected': 'No tool selected',
  Server: 'Server',

  // MCP Resource List/Detail
  'No resources available for this server.':
    'No resources available for this server.',
  'Resources for {{serverName}}': 'Resources for {{serverName}}',
  'No resource selected': 'No resource selected',
  'Resource Detail': 'Resource Detail',
  'URI:': 'URI:',
  'MIME Type:': 'MIME Type:',
  'Size:': 'Size:',
  '{{count}} bytes': '{{count}} bytes',
  'Reference in chat': 'Reference in chat',
  'MCP server': 'MCP server',
  'MCP resource server': 'MCP resource server',

  // Invalid tool related translations
  '{{count}} invalid tools': '{{count}} invalid tools',
  invalid: 'invalid',
  'invalid: {{reason}}': 'invalid: {{reason}}',
  'missing name': 'missing name',
  'missing description': 'missing description',
  '(unnamed)': '(unnamed)',
  'Warning: This tool cannot be called by the LLM':
    'Warning: This tool cannot be called by the LLM',
  Reason: 'Reason',
  'Tools must have both name and description to be used by the LLM.':
    'Tools must have both name and description to be used by the LLM.',
  // ===========================================================
  // Commands - Summary
  // ============================================================================
  'Generate a project summary and save it to .qwen/PROJECT_SUMMARY.md':
    'Generate a project summary and save it to .qwen/PROJECT_SUMMARY.md',
  'No chat client available to generate summary.':
    'No chat client available to generate summary.',
  'Already generating summary, wait for previous request to complete':
    'Already generating summary, wait for previous request to complete',
  'No conversation found to summarize.': 'No conversation found to summarize.',
  'Summary path already exists and is not a generated summary: {{path}}':
    'Summary path already exists and is not a generated summary: {{path}}',
  'Summary path must be within the project root.':
    'Summary path must be within the project root.',
  'Summary path resolves to an existing directory: {{path}}':
    'Summary path resolves to an existing directory: {{path}}',
  'Summary path ends with a separator but is an existing file: {{path}}':
    'Summary path ends with a separator but is an existing file: {{path}}',
  'Failed to generate project context summary: {{error}}':
    'Failed to generate project context summary: {{error}}',
  'Saved project summary to {{filePathForDisplay}}.':
    'Saved project summary to {{filePathForDisplay}}.',
  'Saving project summary...': 'Saving project summary...',
  'Generating project summary...': 'Generating project summary...',
  'Processing summary...': 'Processing summary...',
  'Project summary generated and saved successfully!':
    'Project summary generated and saved successfully!',
  'Saved to: {{filePath}}': 'Saved to: {{filePath}}',
  'Failed to generate summary - no text content received from LLM response':
    'Failed to generate summary - no text content received from LLM response',

  // ============================================================================
  // Commands - Model
  // ============================================================================
  'Switch the model for this session (--fast for suggestion model, [model-id] to switch immediately).':
    'Switch the model for this session (--fast for suggestion model, [model-id] to switch immediately).',
  'Switch the model for this session (--fast for suggestion model, --voice for voice transcription model, [model-id] to switch immediately).':
    'Switch the model for this session (--fast for suggestion model, --voice for voice transcription model, [model-id] to switch immediately).',
  'Switch the model for this session (--fast for suggestion model, --voice for voice transcription model, --vision for the vision bridge model, --project to persist to project settings, --global to persist to user settings, [model-id] to switch immediately, or [model-id] [prompt] to run a one-off prompt on another model; the inline prompt is sent verbatim without @file expansion).':
    'Switch the model for this session (--fast for suggestion model, --voice for voice transcription model, --vision for the vision bridge model, --project to persist to project settings, --global to persist to user settings, [model-id] to switch immediately, or [model-id] [prompt] to run a one-off prompt on another model; the inline prompt is sent verbatim without @file expansion).',
  'Switch the model for this session (--fast for suggestion model, --voice for voice transcription model, --vision for the vision bridge model, --compaction for chat compression model, --image for the image generation model, --project to persist to project settings, --global to persist to user settings, [model-id] to switch immediately, or [model-id] [prompt] to run a one-off prompt on another model; the inline prompt is sent verbatim without @file expansion).':
    'Switch the model for this session (--fast for suggestion model, --voice for voice transcription model, --vision for the vision bridge model, --compaction for chat compression model, --image for the image generation model, --project to persist to project settings, --global to persist to user settings, [model-id] to switch immediately, or [model-id] [prompt] to run a one-off prompt on another model; the inline prompt is sent verbatim without @file expansion).',
  "Inline one-shot override isn't supported in this mode — run '/model {{model}}' first, then send your prompt.":
    "Inline one-shot override isn't supported in this mode — run '/model {{model}}' first, then send your prompt.",
  "Inline one-shot override can't switch providers. '{{model}}' belongs to a different provider — run '/model {{model}}' first, then send your prompt.":
    "Inline one-shot override can't switch providers. '{{model}}' belongs to a different provider — run '/model {{model}}' first, then send your prompt.",
  "⚠ '{{model}}' is not a known image-capable model; the vision bridge may fail on images.":
    "⚠ '{{model}}' is not a known image-capable model; the vision bridge may fail on images.",
  'Set a lighter model for prompt suggestions and speculative execution':
    'Set a lighter model for prompt suggestions and speculative execution',
  'Toggle voice dictation input': 'Toggle voice dictation input',
  'Set the model for voice transcription':
    'Set the model for voice transcription',
  'Set the image-capable model used to transcribe images for a text-only main model':
    'Set the image-capable model used to transcribe images for a text-only main model',
  'Set the model used to generate images':
    'Set the model used to generate images',
  'Set the model used for chat compression (auto-compaction)':
    'Set the model used for chat compression (auto-compaction)',
  'Persist the model selection to the project settings (workspace scope)':
    'Persist the model selection to the project settings (workspace scope)',
  'Persist the model selection to the user settings (global scope)':
    'Persist the model selection to the user settings (global scope)',
  'Select Fast Model': 'Select Fast Model',
  'Select Vision Model': 'Select Vision Model',
  'Select Image Model': 'Select Image Model',
  'Select Compaction Model': 'Select Compaction Model',
  'Select Voice Model': 'Select Voice Model',
  'Vision Model': 'Vision Model',
  'Image Model': 'Image Model',
  'Compaction Model': 'Compaction Model',
  'Compaction model override cleared': 'Compaction model override cleared',
  'Current compaction model: {{compactionModel}}\nUse "/model --compaction <model-id>" to set compaction model, or "/model --compaction clear" to clear the override.':
    'Current compaction model: {{compactionModel}}\nUse "/model --compaction <model-id>" to set compaction model, or "/model --compaction clear" to clear the override.',
  'not set (falls back to the main model)':
    'not set (falls back to the main model)',
  'Configure models in settings.modelProviders and ensure the required environment variables are set. In interactive mode, run /auth to configure or switch providers, or run /model --compaction without a model to choose from configured models.':
    'Configure models in settings.modelProviders and ensure the required environment variables are set. In interactive mode, run /auth to configure or switch providers, or run /model --compaction without a model to choose from configured models.',
  'Voice Model': 'Voice Model',
  'Selected compaction model is unavailable.':
    'Selected compaction model is unavailable.',
  'Selected voice model is unavailable.':
    'Selected voice model is unavailable.',
  'Selected image model is unavailable.':
    'Selected image model is unavailable.',
  "Voice model '{{model}}' is configured more than once. Remove duplicate model ids before selecting it for voice transcription.":
    "Voice model '{{model}}' is configured more than once. Remove duplicate model ids before selecting it for voice transcription.",
  'Voice dictation: {{status}} (mode: {{mode}}, {{modelText}}).':
    'Voice dictation: {{status}} (mode: {{mode}}, {{modelText}}).',
  'model: {{voiceModel}}': 'model: {{voiceModel}}',
  'no voice model selected': 'no voice model selected',
  'Voice dictation disabled.': 'Voice dictation disabled.',
  'Usage: /voice [hold|tap|off|status]': 'Usage: /voice [hold|tap|off|status]',
  'No voice model selected. Run /model --voice to choose one before enabling voice dictation.':
    'No voice model selected. Run /model --voice to choose one before enabling voice dictation.',
  'Voice dictation enabled (tap mode). Tap Space at an empty prompt to start, tap again or pause to stop and submit, using {{voiceModel}}.':
    'Voice dictation enabled (tap mode). Tap Space at an empty prompt to start, tap again or pause to stop and submit, using {{voiceModel}}.',
  'Voice dictation enabled (hold mode). Hold Space at an empty prompt to dictate with {{voiceModel}}.':
    'Voice dictation enabled (hold mode). Hold Space at an empty prompt to dictate with {{voiceModel}}.',
  'No models are configured.': 'No models are configured.',
  'Configured models: {{models}}.': 'Configured models: {{models}}.',
  'Configure a unique model id in settings.modelProviders or run /model --voice to select an available model.':
    'Configure a unique model id in settings.modelProviders or run /model --voice to select an available model.',
  "Voice model '{{modelName}}' is not configured.":
    "Voice model '{{modelName}}' is not configured.",
  "Voice model '{{modelName}}' cannot be used for transcription.":
    "Voice model '{{modelName}}' cannot be used for transcription.",
  "Voice model '{{modelName}}' cannot be used for transcription. Configure an OpenAI-compatible model with baseUrl in settings.modelProviders.":
    "Voice model '{{modelName}}' cannot be used for transcription. Configure an OpenAI-compatible model with baseUrl in settings.modelProviders.",
  'Configure an OpenAI-compatible model with baseUrl in settings.modelProviders.':
    'Configure an OpenAI-compatible model with baseUrl in settings.modelProviders.',
  'Microphone access is denied. Enable it for your terminal in System Settings → Privacy & Security → Microphone, then restart voice dictation.':
    'Microphone access is denied. Enable it for your terminal in System Settings → Privacy & Security → Microphone, then restart voice dictation.',
  'Voice dictation is not supported on {{platform}}.':
    'Voice dictation is not supported on {{platform}}.',
  'Voice dictation needs microphone access, which is unavailable in this WSL session. Use WSLg/PulseAudio, or run Qwen Code on a host with a microphone.':
    'Voice dictation needs microphone access, which is unavailable in this WSL session. Use WSLg/PulseAudio, or run Qwen Code on a host with a microphone.',
  'Voice dictation needs microphone access. macOS will ask the first time you record — approve it, then start again. Your first recording may be empty while the dialog is open.':
    'Voice dictation needs microphone access. macOS will ask the first time you record — approve it, then start again. Your first recording may be empty while the dialog is open.',
  'Voice: recording': 'Voice: recording',
  'Voice: transcribing': 'Voice: transcribing',
  'Voice: refining': 'Voice: refining',
  'listening…': 'listening…',
  'transcribing…': 'transcribing…',
  'refining…': 'refining…',
  'Content generator configuration not available.':
    'Content generator configuration not available.',
  'Authentication type not available.': 'Authentication type not available.',
  'No models available for the current authentication type ({{authType}}).':
    'No models available for the current authentication type ({{authType}}).',
  // Needs translation
  ' (not in model registry)': ' (not in model registry)',

  // ============================================================================
  // Commands - Clear
  // ============================================================================
  'Starting a new session, resetting chat, and clearing terminal.':
    'Starting a new session, resetting chat, and clearing terminal.',
  'Starting a new session and clearing.':
    'Starting a new session and clearing.',

  // ============================================================================
  // Commands - Compress
  // ============================================================================
  'Already compressing, wait for previous request to complete':
    'Already compressing, wait for previous request to complete',
  'Failed to compress chat history.': 'Failed to compress chat history.',
  'Failed to compress chat history: {{error}}':
    'Failed to compress chat history: {{error}}',
  'Compressing chat history': 'Compressing chat history',
  'Chat history compressed from {{originalTokens}} to {{newTokens}} tokens.':
    'Chat history compressed from {{originalTokens}} to {{newTokens}} tokens.',
  'Compression was not beneficial for this history size.':
    'Compression was not beneficial for this history size.',
  'Chat history compression did not reduce size. This may indicate issues with the compression prompt.':
    'Chat history compression did not reduce size. This may indicate issues with the compression prompt.',
  'Could not compress chat history due to a token counting error.':
    'Could not compress chat history due to a token counting error.',
  'Could not compress chat history because the compression summary was empty.':
    'Could not compress chat history because the compression summary was empty.',
  'Could not compress chat history because the compression summary was truncated.':
    'Could not compress chat history because the compression summary was truncated.',
  'Could not compress chat history due to an API error.':
    'Could not compress chat history due to an API error.',
  // ============================================================================
  // Commands - Directory
  // ============================================================================
  'Configuration is not available.': 'Configuration is not available.',
  'Please provide at least one path to add.':
    'Please provide at least one path to add.',
  'The /directory add command is not supported in restrictive sandbox profiles. Please use --include-directories when starting the session instead.':
    'The /directory add command is not supported in restrictive sandbox profiles. Please use --include-directories when starting the session instead.',
  "Error adding '{{path}}': {{error}}": "Error adding '{{path}}': {{error}}",
  'Successfully added QWEN.md files from the following directories if there are:\n- {{directories}}':
    'Successfully added QWEN.md files from the following directories if there are:\n- {{directories}}',
  'Error refreshing memory: {{error}}': 'Error refreshing memory: {{error}}',
  'Successfully added directories:\n- {{directories}}':
    'Successfully added directories:\n- {{directories}}',
  'Current workspace directories:\n{{directories}}':
    'Current workspace directories:\n{{directories}}',

  // ============================================================================
  // Commands - Docs
  // ============================================================================
  'Please open the following URL in your browser to view the documentation:\n{{url}}':
    'Please open the following URL in your browser to view the documentation:\n{{url}}',
  'Opening documentation in your browser: {{url}}':
    'Opening documentation in your browser: {{url}}',

  // ============================================================================
  // Dialogs - Tool Confirmation
  // ============================================================================
  'Do you want to proceed?': 'Do you want to proceed?',
  'Yes, allow once': 'Yes, allow once',
  'Allow always': 'Allow always',
  Yes: 'Yes',
  No: 'No',
  'No (esc)': 'No (esc)',
  'Modify in progress:': 'Modify in progress:',
  'Save and close external editor to continue':
    'Save and close external editor to continue',
  'Apply this change?': 'Apply this change?',
  'Yes, allow always': 'Yes, allow always',
  'Modify with external editor': 'Modify with external editor',
  'No, suggest changes (esc)': 'No, suggest changes (esc)',
  "Allow execution of: '{{command}}'?": "Allow execution of: '{{command}}'?",
  'Always allow in this project': 'Always allow in this project',
  'Always allow {{action}} in this project':
    'Always allow {{action}} in this project',
  'Always allow for this user': 'Always allow for this user',
  'Always allow {{action}} for this user':
    'Always allow {{action}} for this user',
  'Yes, restore previous mode ({{mode}})':
    'Yes, restore previous mode ({{mode}})',
  'Yes, and auto-accept edits': 'Yes, and auto-accept edits',
  'Yes, and manually approve edits': 'Yes, and manually approve edits',
  'No, keep planning (esc)': 'No, keep planning (esc)',
  'URLs to fetch:': 'URLs to fetch:',
  'MCP Server: {{server}}': 'MCP Server: {{server}}',
  'Tool: {{tool}}': 'Tool: {{tool}}',
  'Allow execution of MCP tool "{{tool}}" from server "{{server}}"?':
    'Allow execution of MCP tool "{{tool}}" from server "{{server}}"?',
  // ============================================================================
  // Dialogs - Shell Confirmation
  // ============================================================================
  'Shell Command Execution': 'Shell Command Execution',
  'A custom command wants to run the following shell commands:':
    'A custom command wants to run the following shell commands:',
  // ============================================================================
  // Dialogs - Welcome Back
  // ============================================================================
  'Current Plan:': 'Current Plan:',
  'Progress: {{done}}/{{total}} tasks completed':
    'Progress: {{done}}/{{total}} tasks completed',
  ', {{inProgress}} in progress': ', {{inProgress}} in progress',
  'Pending Tasks:': 'Pending Tasks:',
  'What would you like to do?': 'What would you like to do?',
  'Choose how to proceed with your session:':
    'Choose how to proceed with your session:',
  'Start new chat session': 'Start new chat session',
  'Continue previous conversation': 'Continue previous conversation',
  'Welcome back! (Last updated: {{timeAgo}})':
    'Welcome back! (Last updated: {{timeAgo}})',
  'Overall Goal:': 'Overall Goal:',
  'Connect a Provider': 'Connect a Provider',
  'You must connect a provider to proceed. Press Ctrl+C again to exit.':
    'You must connect a provider to proceed. Press Ctrl+C again to exit.',
  'Terms of Services and Privacy Notice':
    'Terms of Services and Privacy Notice',
  'Qwen OAuth': 'Qwen OAuth',
  'Discontinued — switch to Coding Plan or API Key':
    'Discontinued — switch to Coding Plan or API Key',
  'Qwen OAuth free tier was discontinued on 2026-04-15. Please select Coding Plan or API Key instead.':
    'Qwen OAuth free tier was discontinued on 2026-04-15. Please select Coding Plan or API Key instead.',
  'Qwen OAuth free tier was discontinued on 2026-04-15. Please select a model from another provider or run /auth to switch.':
    'Qwen OAuth free tier was discontinued on 2026-04-15. Please select a model from another provider or run /auth to switch.',
  '\n⚠ Qwen OAuth free tier was discontinued on 2026-04-15. Please select another option.\n':
    '\n⚠ Qwen OAuth free tier was discontinued on 2026-04-15. Please select another option.\n',
  'Paid \u00B7 Up to 6,000 requests/5 hrs \u00B7 All Alibaba Cloud Coding Plan Models':
    'Paid \u00B7 Up to 6,000 requests/5 hrs \u00B7 All Alibaba Cloud Coding Plan Models',
  'For teams \u00B7 Paid \u00B7 Up to 6,000 requests/5 hrs \u00B7 All Alibaba Cloud Coding Plan Models':
    'For teams \u00B7 Paid \u00B7 Up to 6,000 requests/5 hrs \u00B7 All Alibaba Cloud Coding Plan Models',
  'For individual developers \u00B7 Pay per model call \u00B7 5-hour/weekly quotas':
    'For individual developers \u00B7 Pay per model call \u00B7 5-hour/weekly quotas',
  Subscribe: 'Subscribe',
  'Paid subscription plans from Alibaba Cloud ModelStudio':
    'Paid subscription plans from Alibaba Cloud ModelStudio',
  'Select Subscription Plan': 'Select Subscription Plan',
  'Alibaba Cloud Coding Plan': 'Alibaba Cloud Coding Plan',
  'Alibaba Cloud Token Plan': 'Alibaba Cloud Token Plan',
  'Pay-as-you-go tokens \u00B7 Configure ModelStudio standard API key':
    'Pay-as-you-go tokens \u00B7 Configure ModelStudio standard API key',
  'For individuals \u00B7 Pay-as-you-go tokens \u00B7 Dedicated Token Plan endpoint':
    'For individuals \u00B7 Pay-as-you-go tokens \u00B7 Dedicated Token Plan endpoint',
  'For teams/companies \u00B7 Credits deducted by token usage \u00B7 Dedicated API key and base URL':
    'For teams/companies \u00B7 Credits deducted by token usage \u00B7 Dedicated API key and base URL',
  'Token Plan documentation': 'Token Plan documentation',
  'Bring your own API key': 'Bring your own API key',
  'Browser-based authentication with third-party providers (e.g. OpenRouter, ModelScope)':
    'Browser-based authentication with third-party providers (e.g. OpenRouter, ModelScope)',
  'Authentication is enforced to be {{enforcedType}}, but you are currently using {{currentType}}.':
    'Authentication is enforced to be {{enforcedType}}, but you are currently using {{currentType}}.',
  'Qwen OAuth Authentication': 'Qwen OAuth Authentication',
  'Please visit this URL to authorize:': 'Please visit this URL to authorize:',
  'Waiting for authorization': 'Waiting for authorization',
  'Time remaining:': 'Time remaining:',
  'Qwen OAuth Authentication Timeout': 'Qwen OAuth Authentication Timeout',
  'OAuth token expired (over {{seconds}} seconds). Please select authentication method again.':
    'OAuth token expired (over {{seconds}} seconds). Please select authentication method again.',
  'Press any key to return to authentication type selection.':
    'Press any key to return to authentication type selection.',
  'Waiting for Qwen OAuth authentication...':
    'Waiting for Qwen OAuth authentication...',
  'Authentication timed out. Please try again.':
    'Authentication timed out. Please try again.',
  'Waiting for auth... (Press ESC or CTRL+C to cancel)':
    'Waiting for auth... (Press ESC or CTRL+C to cancel)',
  'Missing API key for OpenAI-compatible auth. Set settings.security.auth.apiKey, or set the {{envKeyHint}} environment variable.':
    'Missing API key for OpenAI-compatible auth. Set settings.security.auth.apiKey, or set the {{envKeyHint}} environment variable.',
  '{{envKeyHint}} environment variable not found. Please set it in your .env file or environment variables.':
    '{{envKeyHint}} environment variable not found. Please set it in your .env file or environment variables.',
  '{{envKeyHint}} environment variable not found (or set settings.security.auth.apiKey). Please set it in your .env file or environment variables.':
    '{{envKeyHint}} environment variable not found (or set settings.security.auth.apiKey). Please set it in your .env file or environment variables.',
  'Missing API key for OpenAI-compatible auth. Set the {{envKeyHint}} environment variable.':
    'Missing API key for OpenAI-compatible auth. Set the {{envKeyHint}} environment variable.',
  'Anthropic provider missing required baseUrl in modelProviders[].baseUrl.':
    'Anthropic provider missing required baseUrl in modelProviders[].baseUrl.',
  'ANTHROPIC_BASE_URL environment variable not found.':
    'ANTHROPIC_BASE_URL environment variable not found.',
  'Invalid auth method selected.': 'Invalid auth method selected.',
  'Failed to authenticate. Message: {{message}}':
    'Failed to authenticate. Message: {{message}}',
  'Authenticated successfully with {{authType}} credentials.':
    'Authenticated successfully with {{authType}} credentials.',
  'Invalid QWEN_DEFAULT_AUTH_TYPE value: "{{value}}". Valid values are: {{validValues}}':
    'Invalid QWEN_DEFAULT_AUTH_TYPE value: "{{value}}". Valid values are: {{validValues}}',
  // ============================================================================
  // Dialogs - Model
  // ============================================================================
  'Select Model': 'Select Model',
  ' (this project)': ' (this project)',
  ' (global)': ' (global)',
  'API Key': 'API Key',
  '(default)': '(default)',
  '(not set)': '(not set)',
  Modality: 'Modality',
  'Context Window': 'Context Window',
  text: 'text',
  'text-only': 'text-only',
  image: 'image',
  pdf: 'pdf',
  audio: 'audio',
  video: 'video',
  'not set': 'not set',
  'Current voice model: {{voiceModel}}\nUse "/model --voice <model-id>" to set voice model.':
    'Current voice model: {{voiceModel}}\nUse "/model --voice <model-id>" to set voice model.',
  'Current vision model: {{visionModel}}\nUse "/model --vision <model-id>" to set the vision bridge model.':
    'Current vision model: {{visionModel}}\nUse "/model --vision <model-id>" to set the vision bridge model.',
  'Current image model: {{imageModel}}\nUse "/model --image <model-id>" to set the image generation model.':
    'Current image model: {{imageModel}}\nUse "/model --image <model-id>" to set the image generation model.',
  "Voice model '{{modelName}}' is ambiguous. Configure a unique model id before using /model --voice.":
    "Voice model '{{modelName}}' is ambiguous. Configure a unique model id before using /model --voice.",
  "Image model '{{modelName}}' matches multiple configured endpoints. Run /model --image without an argument and choose the exact endpoint.":
    "Image model '{{modelName}}' matches multiple configured endpoints. Run /model --image without an argument and choose the exact endpoint.",
  "Image model '{{modelName}}' must declare a valid HTTPS baseUrl and credential environment variable.":
    "Image model '{{modelName}}' must declare a valid HTTPS baseUrl and credential environment variable.",
  "'{{model}}' must declare a valid HTTPS baseUrl and credential environment variable.":
    "'{{model}}' must declare a valid HTTPS baseUrl and credential environment variable.",
  none: 'none',
  unknown: 'unknown',
  // ============================================================================
  // Dialogs - Permissions
  // ============================================================================
  'Manage folder trust settings': 'Manage folder trust settings',
  'Manage permission rules': 'Manage permission rules',
  Allow: 'Allow',
  Ask: 'Ask',
  Deny: 'Deny',
  Workspace: 'Workspace',
  "Qwen Code won't ask before using allowed tools.":
    "Qwen Code won't ask before using allowed tools.",
  'Qwen Code will ask before using these tools.':
    'Qwen Code will ask before using these tools.',
  'Qwen Code is not allowed to use denied tools.':
    'Qwen Code is not allowed to use denied tools.',
  'Manage trusted directories for this workspace.':
    'Manage trusted directories for this workspace.',
  'Any use of the {{tool}} tool': 'Any use of the {{tool}} tool',
  "{{tool}} commands matching '{{pattern}}'":
    "{{tool}} commands matching '{{pattern}}'",
  'From user settings': 'From user settings',
  'From project settings': 'From project settings',
  'From session': 'From session',
  'Project settings': 'Project settings',
  'Checked in at .qwen/settings.json': 'Checked in at .qwen/settings.json',
  'User settings': 'User settings',
  'Saved in at ~/.qwen/settings.json': 'Saved in at ~/.qwen/settings.json',
  'Add a new rule…': 'Add a new rule…',
  'Add {{type}} permission rule': 'Add {{type}} permission rule',
  'Permission rules are a tool name, optionally followed by a specifier in parentheses.':
    'Permission rules are a tool name, optionally followed by a specifier in parentheses.',
  'e.g.,': 'e.g.,',
  or: 'or',
  'Enter permission rule…': 'Enter permission rule…',
  'Enter to submit · Esc to cancel': 'Enter to submit · Esc to cancel',
  'Where should this rule be saved?': 'Where should this rule be saved?',
  'Enter to confirm · Esc to cancel': 'Enter to confirm · Esc to cancel',
  'Delete {{type}} rule?': 'Delete {{type}} rule?',
  'Are you sure you want to delete this permission rule?':
    'Are you sure you want to delete this permission rule?',
  'Permissions:': 'Permissions:',
  '(←/→ or tab to cycle)': '(←/→ or tab to cycle)',
  'Press ↑↓ to navigate · Enter to select · Type to search · Esc to cancel':
    'Press ↑↓ to navigate · Enter to select · Type to search · Esc to cancel',
  'Search…': 'Search…',
  // Workspace directory management
  'Add directory…': 'Add directory…',
  'Add directory to workspace': 'Add directory to workspace',
  'Qwen Code can read files in the workspace, and make edits when auto-accept edits is on.':
    'Qwen Code can read files in the workspace, and make edits when auto-accept edits is on.',
  'Qwen Code will be able to read files in this directory and make edits when auto-accept edits is on.':
    'Qwen Code will be able to read files in this directory and make edits when auto-accept edits is on.',
  'Enter the path to the directory:': 'Enter the path to the directory:',
  'Enter directory path…': 'Enter directory path…',
  'Tab to complete · Enter to add · Esc to cancel':
    'Tab to complete · Enter to add · Esc to cancel',
  'Remove directory?': 'Remove directory?',
  'Are you sure you want to remove this directory from the workspace?':
    'Are you sure you want to remove this directory from the workspace?',
  '  (Original working directory)': '  (Original working directory)',
  '  (from settings)': '  (from settings)',
  'Directory does not exist.': 'Directory does not exist.',
  'Path is not a directory.': 'Path is not a directory.',
  'This directory is already in the workspace.':
    'This directory is already in the workspace.',
  'Already covered by existing directory: {{dir}}':
    'Already covered by existing directory: {{dir}}',

  // ============================================================================
  // Status Bar
  // ============================================================================
  'Using:': 'Using:',
  '{{count}} open file': '{{count}} open file',
  '{{count}} open files': '{{count}} open files',
  '(ctrl+g to view)': '(ctrl+g to view)',
  '{{count}} {{name}} file': '{{count}} {{name}} file',
  '{{count}} {{name}} files': '{{count}} {{name}} files',
  '{{count}} MCP server': '{{count}} MCP server',
  '{{count}} MCP servers': '{{count}} MCP servers',
  '{{count}} Blocked': '{{count}} Blocked',
  '(ctrl+t to view)': '(ctrl+t to view)',
  '(ctrl+t to toggle)': '(ctrl+t to toggle)',
  'Press Ctrl+C again to exit.': 'Press Ctrl+C again to exit.',
  'Press Ctrl+D again to exit.': 'Press Ctrl+D again to exit.',
  'Press Esc again to clear.': 'Press Esc again to clear.',
  'Ctrl+Q to queue · ↑ to edit queued messages':
    'Ctrl+Q to queue · ↑ to edit queued messages',
  'Enter to steer · Ctrl+Q to queue': 'Enter to steer · Ctrl+Q to queue',
  '{{count}} queued': '{{count}} queued',
  'Queue message for the next turn': 'Queue message for the next turn',

  // ============================================================================
  // MCP Status
  // ============================================================================
  'No MCP servers configured.': 'No MCP servers configured.',
  '◌ MCP servers are starting up ({{count}} initializing)...':
    '◌ MCP servers are starting up ({{count}} initializing)...',
  'Note: First startup may take longer. Tool availability will update automatically.':
    'Note: First startup may take longer. Tool availability will update automatically.',
  'Configured MCP servers:': 'Configured MCP servers:',
  Ready: 'Ready',
  'Starting... (first startup may take longer)':
    'Starting... (first startup may take longer)',
  Disconnected: 'Disconnected',
  '{{count}} tool': '{{count}} tool',
  '{{count}} tools': '{{count}} tools',
  '{{count}} prompt': '{{count}} prompt',
  '{{count}} prompts': '{{count}} prompts',
  '(from {{extensionName}})': '(from {{extensionName}})',
  OAuth: 'OAuth',
  'OAuth expired': 'OAuth expired',
  'OAuth not authenticated': 'OAuth not authenticated',
  'tools and prompts will appear when ready':
    'tools and prompts will appear when ready',
  '{{count}} tools cached': '{{count}} tools cached',
  'Tools:': 'Tools:',
  'Parameters:': 'Parameters:',
  'Prompts:': 'Prompts:',
  'Resources:': 'Resources:',
  Blocked: 'Blocked',
  '★ Tips:': '★ Tips:',
  Use: 'Use',
  'to show server and tool descriptions':
    'to show server and tool descriptions',
  'to show tool parameter schemas': 'to show tool parameter schemas',
  'to hide descriptions': 'to hide descriptions',
  'to authenticate with OAuth-enabled servers':
    'to authenticate with OAuth-enabled servers',
  Press: 'Press',
  'to toggle tool descriptions on/off': 'to toggle tool descriptions on/off',
  "Starting OAuth authentication for MCP server '{{name}}'...":
    "Starting OAuth authentication for MCP server '{{name}}'...",
  // ============================================================================
  // Startup Tips
  // ============================================================================
  'Tips:': 'Tips:',
  'Use /compress when the conversation gets long to summarize history and free up context.':
    'Use /compress when the conversation gets long to summarize history and free up context.',
  'Start a fresh idea with /clear or /new; the previous session stays available in history.':
    'Start a fresh idea with /clear or /new; the previous session stays available in history.',
  'Use /bug to submit issues to the maintainers when something goes off.':
    'Use /bug to submit issues to the maintainers when something goes off.',
  'Switch auth type quickly with /auth.':
    'Switch auth type quickly with /auth.',
  'You can run any shell commands from Qwen Code using ! (e.g. !ls).':
    'You can run any shell commands from Qwen Code using ! (e.g. !ls).',
  'Type / to open the command popup; Tab autocompletes slash commands and saved prompts.':
    'Type / to open the command popup; Tab autocompletes slash commands and saved prompts.',
  'You can resume a previous conversation by running qwen --continue or qwen --resume.':
    'You can resume a previous conversation by running qwen --continue or qwen --resume.',
  'You can switch permission mode quickly with Shift+Tab or /approval-mode.':
    'You can switch permission mode quickly with Shift+Tab or /approval-mode.',
  'You can switch permission mode quickly with Tab or /approval-mode.':
    'You can switch permission mode quickly with Tab or /approval-mode.',
  'Try /insight to generate personalized insights from your chat history.':
    'Try /insight to generate personalized insights from your chat history.',
  'Add a QWEN.md file to give Qwen Code persistent project context.':
    'Add a QWEN.md file to give Qwen Code persistent project context.',
  'Use /btw to ask a quick side question without disrupting the conversation.':
    'Use /btw to ask a quick side question without disrupting the conversation.',
  'Context is almost full! Run /compress now or start /new to continue.':
    'Context is almost full! Run /compress now or start /new to continue.',
  'Context is getting full. Use /compress to free up space.':
    'Context is getting full. Use /compress to free up space.',
  'Long conversation? /compress summarizes history to free context.':
    'Long conversation? /compress summarizes history to free context.',

  // ============================================================================
  // Exit Screen / Stats
  // ============================================================================
  'Agent powering down. Goodbye!': 'Agent powering down. Goodbye!',
  'To continue this session, run': 'To continue this session, run',
  'Interaction Summary': 'Interaction Summary',
  'Session ID:': 'Session ID:',
  'Tool Calls:': 'Tool Calls:',
  'Success Rate:': 'Success Rate:',
  'User Agreement:': 'User Agreement:',
  reviewed: 'reviewed',
  'Code Changes:': 'Code Changes:',
  Performance: 'Performance',
  'Generation Metrics': 'Generation Metrics',
  'Latest Request': 'Latest Request',
  'Generation Time': 'Generation Time',
  'Average TTFT': 'Average TTFT',
  'Session TPS': 'Session TPS',
  'Wall Time:': 'Wall Time:',
  'Agent Active:': 'Agent Active:',
  'API Time:': 'API Time:',
  'Tool Time:': 'Tool Time:',
  'Session Stats': 'Session Stats',
  'Model Usage': 'Model Usage',
  Reqs: 'Reqs',
  'Input Tokens': 'Input Tokens',
  'Output Tokens': 'Output Tokens',
  'Savings Highlight:': 'Savings Highlight:',
  'of input tokens were served from the cache, reducing costs.':
    'of input tokens were served from the cache, reducing costs.',
  'Tip: For a full token breakdown, run `/stats model`.':
    'Tip: For a full token breakdown, run `/stats model`.',
  'Model Stats For Nerds': 'Model Stats For Nerds',
  'Tool Stats For Nerds': 'Tool Stats For Nerds',
  Metric: 'Metric',
  API: 'API',
  Requests: 'Requests',
  Errors: 'Errors',
  'Avg Latency': 'Avg Latency',
  Tokens: 'Tokens',
  Total: 'Total',
  Prompt: 'Prompt',
  Cached: 'Cached',
  Thoughts: 'Thoughts',
  Output: 'Output',
  'No API calls have been made in this session.':
    'No API calls have been made in this session.',
  'Tool Name': 'Tool Name',
  Calls: 'Calls',
  'Success Rate': 'Success Rate',
  'Avg Duration': 'Avg Duration',
  'User Decision Summary': 'User Decision Summary',
  'Total Reviewed Suggestions:': 'Total Reviewed Suggestions:',
  ' » Accepted:': ' » Accepted:',
  ' » Rejected:': ' » Rejected:',
  ' » Modified:': ' » Modified:',
  ' Overall Agreement Rate:': ' Overall Agreement Rate:',
  'No tool calls have been made in this session.':
    'No tool calls have been made in this session.',
  'Session start time is unavailable, cannot calculate stats.':
    'Session start time is unavailable, cannot calculate stats.',

  // ============================================================================
  // Command Format Migration
  // ============================================================================
  'Command Format Migration': 'Command Format Migration',
  'Found {{count}} TOML command file:': 'Found {{count}} TOML command file:',
  'Found {{count}} TOML command files:': 'Found {{count}} TOML command files:',
  'Current tasks': 'Current tasks',
  'Background tasks': 'Background tasks',
  'No tasks currently running': 'No tasks currently running',
  'No entry to show.': 'No entry to show.',
  'needs approval': 'needs approval',
  'Large workflow': 'Large workflow',
  'Large workflow: {{agents}} agents scheduled (warning threshold {{cap}}).':
    'Large workflow: {{agents}} agents scheduled (warning threshold {{cap}}).',
  'Large workflow: ~{{tokens}} output tokens projected (warning threshold {{cap}}).':
    'Large workflow: ~{{tokens}} output tokens projected (warning threshold {{cap}}).',
  'rejected — edit config to re-approve':
    'rejected — edit config to re-approve',
  'Background agent needs approval': 'Background agent needs approval',
  'Approve or deny the request above': 'Approve or deny the request above',
  'from nested agent': 'from nested agent',
  Running: 'Running',
  Pausing: 'Pausing',
  Paused: 'Paused',
  'Pause is cooperative; in-flight work may finish before the workflow is paused. An agent call waiting on a tool approval keeps the run in this state and still counts against the active-time limit until the approval is answered.':
    'Pause is cooperative; in-flight work may finish before the workflow is paused. An agent call waiting on a tool approval keeps the run in this state and still counts against the active-time limit until the approval is answered.',
  'Paused: no new agents will start; script code between agent calls keeps running. Press p to resume. /clear, /branch, and switching sessions cancel paused runs.':
    'Paused: no new agents will start; script code between agent calls keeps running. Press p to resume. /clear, /branch, and switching sessions cancel paused runs.',
  'Pause/resume was rejected; the workflow state changed. Try again.':
    'Pause/resume was rejected; the workflow state changed. Try again.',
  'Tip: use `/workflows p <runId>` or Background tasks + p to cooperatively pause/resume; use `/workflows <runId>` for details.':
    'Tip: use `/workflows p <runId>` or Background tasks + p to cooperatively pause/resume; use `/workflows <runId>` for details.',
  Completed: 'Completed',
  Failed: 'Failed',
  Stopped: 'Stopped',
  Shell: 'Shell',
  Monitor: 'Monitor',
  Command: 'Command',
  Dream: 'Dream',
  '[dream] memory consolidation': '[dream] memory consolidation',
  '[dream] memory consolidation (reviewing {{count}} session)':
    '[dream] memory consolidation (reviewing {{count}} session)',
  '[dream] memory consolidation (reviewing {{count}} sessions)':
    '[dream] memory consolidation (reviewing {{count}} sessions)',
  '{{count}} session': '{{count}} session',
  '{{count}} sessions': '{{count}} sessions',
  '{{count}} topic': '{{count}} topic',
  '{{count}} topics': '{{count}} topics',
  '{{count}} tokens': '{{count}} tokens',
  '{{count}} tool call': '{{count}} tool call',
  '{{count}} tool calls': '{{count}} tool calls',
  '{{count}} event': '{{count}} event',
  '{{count}} events': '{{count}} events',
  '{{count}} dropped': '{{count}} dropped',
  'pid {{pid}}': 'pid {{pid}}',
  'exit {{exitCode}}': 'exit {{exitCode}}',
  'Sessions reviewing': 'Sessions reviewing',
  Progress: 'Progress',
  'Resume blocked': 'Resume blocked',
  'Working dir': 'Working dir',
  'Output file': 'Output file',
  'Topics touched ({{count}})': 'Topics touched ({{count}})',
  '{{count}} more': '{{count}} more',
  'Lock release warning': 'Lock release warning',
  'Metadata write warning': 'Metadata write warning',
  "Subsequent dreams may be skipped as locked until the next session's staleness sweep cleans the file.":
    "Subsequent dreams may be skipped as locked until the next session's staleness sweep cleans the file.",
  "The scheduler gate did not see this dream's timestamp; the next dream cycle may re-fire sooner than usual.":
    "The scheduler gate did not see this dream's timestamp; the next dream cycle may re-fire sooner than usual.",
  '... and {{count}} more': '... and {{count}} more',
  'The TOML format is deprecated. Would you like to migrate them to Markdown format?':
    'The TOML format is deprecated. Would you like to migrate them to Markdown format?',
  '(Backups will be created and original files will be preserved)':
    '(Backups will be created and original files will be preserved)',

  // ============================================================================
  // Loading Phrases
  // ============================================================================
  'Waiting for user confirmation...': 'Waiting for user confirmation...',
  // ============================================================================
  // Loading Phrases
  // ============================================================================
  WITTY_LOADING_PHRASES: [
    "I'm Feeling Lucky",
    'Shipping awesomeness... ',
    'Painting the serifs back on...',
    'Navigating the slime mold...',
    'Consulting the digital spirits...',
    'Reticulating splines...',
    'Warming up the AI hamsters...',
    'Asking the magic conch shell...',
    'Generating witty retort...',
    'Polishing the algorithms...',
    "Don't rush perfection (or my code)...",
    'Brewing fresh bytes...',
    'Counting electrons...',
    'Engaging cognitive processors...',
    'Checking for syntax errors in the universe...',
    'One moment, optimizing humor...',
    'Shuffling punchlines...',
    'Untangling neural nets...',
    'Compiling brilliance...',
    'Loading wit.exe...',
    'Summoning the cloud of wisdom...',
    'Preparing a witty response...',
    "Just a sec, I'm debugging reality...",
    'Confuzzling the options...',
    'Tuning the cosmic frequencies...',
    'Crafting a response worthy of your patience...',
    'Compiling the 1s and 0s...',
    'Resolving dependencies... and existential crises...',
    'Defragmenting memories... both RAM and personal...',
    'Rebooting the humor module...',
    'Caching the essentials (mostly cat memes)...',
    'Optimizing for ludicrous speed',
    "Swapping bits... don't tell the bytes...",
    'Garbage collecting... be right back...',
    'Assembling the interwebs...',
    'Converting coffee into code...',
    'Updating the syntax for reality...',
    'Rewiring the synapses...',
    'Looking for a misplaced semicolon...',
    "Greasin' the cogs of the machine...",
    'Pre-heating the servers...',
    'Calibrating the flux capacitor...',
    'Engaging the improbability drive...',
    'Channeling the Force...',
    'Aligning the stars for optimal response...',
    'So say we all...',
    'Loading the next great idea...',
    "Just a moment, I'm in the zone...",
    'Preparing to dazzle you with brilliance...',
    "Just a tick, I'm polishing my wit...",
    "Hold tight, I'm crafting a masterpiece...",
    "Just a jiffy, I'm debugging the universe...",
    "Just a moment, I'm aligning the pixels...",
    "Just a sec, I'm optimizing the humor...",
    "Just a moment, I'm tuning the algorithms...",
    'Warp speed engaged...',
    'Mining for more Dilithium crystals...',
    "Don't panic...",
    'Following the white rabbit...',
    'The truth is in here... somewhere...',
    'Blowing on the cartridge...',
    'Loading... Do a barrel roll!',
    'Waiting for the respawn...',
    'Finishing the Kessel Run in less than 12 parsecs...',
    "The cake is not a lie, it's just still loading...",
    'Fiddling with the character creation screen...',
    "Just a moment, I'm finding the right meme...",
    "Pressing 'A' to continue...",
    'Herding digital cats...',
    'Polishing the pixels...',
    'Finding a suitable loading screen pun...',
    'Distracting you with this witty phrase...',
    'Almost there... probably...',
    'Our hamsters are working as fast as they can...',
    'Giving Cloudy a pat on the head...',
    'Petting the cat...',
    'Rickrolling my boss...',
    'Never gonna give you up, never gonna let you down...',
    'Slapping the bass...',
    'Tasting the snozberries...',
    "I'm going the distance, I'm going for speed...",
    'Is this the real life? Is this just fantasy?...',
    "I've got a good feeling about this...",
    'Poking the bear...',
    'Doing research on the latest memes...',
    'Figuring out how to make this more witty...',
    'Hmmm... let me think...',
    'What do you call a fish with no eyes? A fsh...',
    'Why did the computer go to therapy? It had too many bytes...',
    "Why don't programmers like nature? It has too many bugs...",
    'Why do programmers prefer dark mode? Because light attracts bugs...',
    'Why did the developer go broke? Because they used up all their cache...',
    "What can you do with a broken pencil? Nothing, it's pointless...",
    'Applying percussive maintenance...',
    'Searching for the correct USB orientation...',
    'Ensuring the magic smoke stays inside the wires...',
    'Trying to exit Vim...',
    'Spinning up the hamster wheel...',
    "That's not a bug, it's an undocumented feature...",
    'Engage.',
    "I'll be back... with an answer.",
    'My other process is a TARDIS...',
    'Communing with the machine spirit...',
    'Letting the thoughts marinate...',
    'Just remembered where I put my keys...',
    'Pondering the orb...',
    "I've seen things you people wouldn't believe... like a user who reads loading messages.",
    'Initiating thoughtful gaze...',
    "What's a computer's favorite snack? Microchips.",
    "Why do Java developers wear glasses? Because they don't C#.",
    'Charging the laser... pew pew!',
    'Dividing by zero... just kidding!',
    'Looking for an adult superviso... I mean, processing.',
    'Making it go beep boop.',
    'Buffering... because even AIs need a moment.',
    'Entangling quantum particles for a faster response...',
    'Polishing the chrome... on the algorithms.',
    'Are you not entertained? (Working on it!)',
    'Summoning the code gremlins... to help, of course.',
    'Just waiting for the dial-up tone to finish...',
    'Recalibrating the humor-o-meter.',
    'My other loading screen is even funnier.',
    "Pretty sure there's a cat walking on the keyboard somewhere...",
    'Enhancing... Enhancing... Still loading.',
    "It's not a bug, it's a feature... of this loading screen.",
    'Have you tried turning it off and on again? (The loading screen, not me.)',
    'Constructing additional pylons...',
  ],

  // ============================================================================
  // Extension Settings Input
  // ============================================================================
  'Enter value...': 'Enter value...',
  'Enter sensitive value...': 'Enter sensitive value...',
  'Press Enter to submit, Escape to cancel':
    'Press Enter to submit, Escape to cancel',

  // ============================================================================
  // Command Migration Tool
  // ============================================================================
  'Markdown file already exists: {{filename}}':
    'Markdown file already exists: {{filename}}',
  'TOML Command Format Deprecation Notice':
    'TOML Command Format Deprecation Notice',
  'Found {{count}} command file(s) in TOML format:':
    'Found {{count}} command file(s) in TOML format:',
  'The TOML format for commands is being deprecated in favor of Markdown format.':
    'The TOML format for commands is being deprecated in favor of Markdown format.',
  'Markdown format is more readable and easier to edit.':
    'Markdown format is more readable and easier to edit.',
  'You can migrate these files automatically using:':
    'You can migrate these files automatically using:',
  'Or manually convert each file:': 'Or manually convert each file:',
  'TOML: prompt = "..." / description = "..."':
    'TOML: prompt = "..." / description = "..."',
  'Markdown: YAML frontmatter + content':
    'Markdown: YAML frontmatter + content',
  'The migration tool will:': 'The migration tool will:',
  'Convert TOML files to Markdown': 'Convert TOML files to Markdown',
  'Create backups of original files': 'Create backups of original files',
  'Preserve all command functionality': 'Preserve all command functionality',
  'TOML format will continue to work for now, but migration is recommended.':
    'TOML format will continue to work for now, but migration is recommended.',

  // ============================================================================
  // Extensions - Explore Command
  // ============================================================================
  'Open extensions page in your browser':
    'Open extensions page in your browser',
  'Unknown extensions source: {{source}}.':
    'Unknown extensions source: {{source}}.',
  'Would open extensions page in your browser: {{url}} (skipped in test environment)':
    'Would open extensions page in your browser: {{url}} (skipped in test environment)',
  'View available extensions at {{url}}':
    'View available extensions at {{url}}',
  'Opening extensions page in your browser: {{url}}':
    'Opening extensions page in your browser: {{url}}',
  'Failed to open browser. Check out the extensions gallery at {{url}}':
    'Failed to open browser. Check out the extensions gallery at {{url}}',
  'Retrying in {{seconds}} seconds… (attempt {{attempt}}/{{maxRetries}})':
    'Retrying in {{seconds}} seconds… (attempt {{attempt}}/{{maxRetries}})',
  'Press Ctrl+Y to retry': 'Press Ctrl+Y to retry',
  'No failed request to retry.': 'No failed request to retry.',
  'to retry last request': 'to retry last request',
  'to queue for the next turn': 'to queue for the next turn',

  // ============================================================================
  // Coding Plan Authentication
  // ============================================================================
  'API key cannot be empty.': 'API key cannot be empty.',
  'Invalid API key. Coding Plan API keys start with "sk-sp-". Please check.':
    'Invalid API key. Coding Plan API keys start with "sk-sp-". Please check.',
  'Invalid API key. Pay-as-you-go keys start with "sk-" or "sk-ws-". Token Plan keys ("sk-sp-") need the Token Plan entry instead.':
    'Invalid API key. Pay-as-you-go keys start with "sk-" or "sk-ws-". Token Plan keys ("sk-sp-") need the Token Plan entry instead.',
  'Invalid API key. Token Plan API keys start with "sk-sp-". Generate one from the Token Plan console, or use the Standard API Key entry for a pay-as-you-go key.':
    'Invalid API key. Token Plan API keys start with "sk-sp-". Generate one from the Token Plan console, or use the Standard API Key entry for a pay-as-you-go key.',
  'You can get your Coding Plan API key here':
    'You can get your Coding Plan API key here',
  'You can get your Token Plan API key here':
    'You can get your Token Plan API key here',
  'API key is stored in settings.env. You can migrate it to a .env file for better security.':
    'API key is stored in settings.env. You can migrate it to a .env file for better security.',
  'New model configurations are available for Alibaba Cloud Coding Plan. Update now?':
    'New model configurations are available for Alibaba Cloud Coding Plan. Update now?',
  'Coding Plan configuration updated successfully. New models are now available.':
    'Coding Plan configuration updated successfully. New models are now available.',
  'Coding Plan API key not found. Please re-authenticate with Coding Plan.':
    'Coding Plan API key not found. Please re-authenticate with Coding Plan.',
  'Failed to update Coding Plan configuration: {{message}}':
    'Failed to update Coding Plan configuration: {{message}}',

  // ============================================================================
  // Custom API Key Configuration
  // ============================================================================
  'You can configure your API key and models in settings.json':
    'You can configure your API key and models in settings.json',
  'Refer to the documentation for setup instructions':
    'Refer to the documentation for setup instructions',

  // ============================================================================
  // Auth Dialog - View Titles and Labels
  // ============================================================================
  'Coding Plan': 'Coding Plan',
  QwenCloud: 'QwenCloud',
  'QwenCloud · Access Method': 'QwenCloud · Access Method',
  'Official recommended setup: Token Plan or Standard API Key':
    'Official recommended setup: Token Plan or Standard API Key',
  'Pay-as-you-go · Connect with an existing platform API key':
    'Pay-as-you-go · Connect with an existing platform API key',
  'Subscription with a monthly Credit quota · Dedicated endpoint (Personal and Team editions)':
    'Subscription with a monthly Credit quota · Dedicated endpoint (Personal and Team editions)',
  'China — 千问AI平台': 'China — 千问AI平台',
  'International — QwenCloud': 'International — QwenCloud',
  Platform: 'Platform',
  Custom: 'Custom',
  'Select Region for Coding Plan': 'Select Region for Coding Plan',
  'Choose based on where your account is registered':
    'Choose based on where your account is registered',
  'Enter Coding Plan API Key': 'Enter Coding Plan API Key',
  'Enter Token Plan API Key': 'Enter Token Plan API Key',

  // ============================================================================
  // Coding Plan International Updates
  // ============================================================================
  'New model configurations are available for {{region}}. Update now?':
    'New model configurations are available for {{region}}. Update now?',
  '{{region}} configuration updated successfully. Model switched to "{{model}}".':
    '{{region}} configuration updated successfully. Model switched to "{{model}}".',
  // ============================================================================
  // Context Usage Component
  // ============================================================================
  'Context Usage': 'Context Usage',
  '% used': '% used',
  '% context used': '% context used',
  'Context exceeds limit! Use /compress or /clear to reduce.':
    'Context exceeds limit! Use /compress or /clear to reduce.',
  'No API response yet. Send a message to see actual usage.':
    'No API response yet. Send a message to see actual usage.',
  'Estimated usage, including the conversation':
    'Estimated usage, including the conversation',
  'No provider usage yet. These are local estimates, including the conversation.':
    'No provider usage yet. These are local estimates, including the conversation.',
  'Estimated pre-conversation overhead': 'Estimated pre-conversation overhead',
  'Context window': 'Context window',
  tokens: 'tokens',
  Used: 'Used',
  Free: 'Free',
  'Autocompact buffer': 'Autocompact buffer',
  'Usage by category': 'Usage by category',
  'System prompt': 'System prompt',
  'Built-in tools': 'Built-in tools',
  'MCP tools': 'MCP tools',
  'Memory files': 'Memory files',
  Skills: 'Skills',
  Messages: 'Messages',
  'Startup context': 'Startup context',
  Unattributed: 'Unattributed',
  'Cached prefix': 'Cached prefix',
  'Run /context detail for per-item breakdown.':
    'Run /context detail for per-item breakdown.',
  'Show context window usage breakdown. Use "/context detail" for per-item breakdown.':
    'Show context window usage breakdown. Use "/context detail" for per-item breakdown.',
  'body loaded': 'body loaded',
  memory: 'memory',
  '{{region}} configuration updated successfully.':
    '{{region}} configuration updated successfully.',
  'Authenticated successfully with {{region}}. API key and model configs saved to settings.json.':
    'Authenticated successfully with {{region}}. API key and model configs saved to settings.json.',
  'Tip: Use /model to switch between available Coding Plan models.':
    'Tip: Use /model to switch between available Coding Plan models.',
  'Type something...': 'Type something...',
  Submit: 'Submit',
  'Submit answers': 'Submit answers',
  Cancel: 'Cancel',
  'Your answers:': 'Your answers:',
  '(not answered)': '(not answered)',
  'Ready to submit your answers?': 'Ready to submit your answers?',
  '↑/↓: Navigate | ←/→: Switch tabs | Enter: Select':
    '↑/↓: Navigate | ←/→: Switch tabs | Enter: Select',
  '↑/↓: Navigate | Enter: Select | Esc: Cancel':
    '↑/↓: Navigate | Enter: Select | Esc: Cancel',
  'Authenticate using Qwen OAuth': 'Authenticate using Qwen OAuth',
  'Authenticate using Alibaba Cloud Coding Plan':
    'Authenticate using Alibaba Cloud Coding Plan',
  'Region for Coding Plan (china/global)':
    'Region for Coding Plan (china/global)',
  'API key for Coding Plan': 'API key for Coding Plan',
  'Show current authentication status': 'Show current authentication status',
  'Authentication completed successfully.':
    'Authentication completed successfully.',
  'Starting Qwen OAuth authentication...':
    'Starting Qwen OAuth authentication...',
  'Successfully authenticated with Qwen OAuth.':
    'Successfully authenticated with Qwen OAuth.',
  'Failed to authenticate with Qwen OAuth: {{error}}':
    'Failed to authenticate with Qwen OAuth: {{error}}',
  'Processing Alibaba Cloud Coding Plan authentication...':
    'Processing Alibaba Cloud Coding Plan authentication...',
  'Successfully authenticated with Alibaba Cloud Coding Plan.':
    'Successfully authenticated with Alibaba Cloud Coding Plan.',
  'Failed to authenticate with Coding Plan: {{error}}':
    'Failed to authenticate with Coding Plan: {{error}}',
  '中国 (China)': '中国 (China)',
  '阿里云百炼 (aliyun.com)': '阿里云百炼 (aliyun.com)',
  'Get or set any setting by dot-path key':
    'Get or set any setting by dot-path key',
  'Invalid boolean value: "{{value}}". Use "true" or "false".':
    'Invalid boolean value: "{{value}}". Use "true" or "false".',
  'Cannot toggle a number setting. Provide a value: key=<number>.':
    'Cannot toggle a number setting. Provide a value: key=<number>.',
  'Invalid number value: "{{value}}".': 'Invalid number value: "{{value}}".',
  'Cannot toggle a string setting. Provide a value: key=<value>.':
    'Cannot toggle a string setting. Provide a value: key=<value>.',
  'Cannot toggle an enum setting. Provide one of: {{options}}.':
    'Cannot toggle an enum setting. Provide one of: {{options}}.',
  'Invalid enum value: "{{value}}". Valid values: {{options}}.':
    'Invalid enum value: "{{value}}". Valid values: {{options}}.',
  'Setting "{{type}}" type cannot be set via /config. Edit settings.json directly.':
    'Setting "{{type}}" type cannot be set via /config. Edit settings.json directly.',
  'Unsupported setting type: "{{type}}".':
    'Unsupported setting type: "{{type}}".',
  'Available settings:': 'Available settings:',
  'Unknown setting key: "{{key}}". Did you mean "{{suggestion}}"?':
    'Unknown setting key: "{{key}}". Did you mean "{{suggestion}}"?',
  'Unknown setting key: "{{key}}".': 'Unknown setting key: "{{key}}".',
  'Failed to set "{{key}}": {{error}}': 'Failed to set "{{key}}": {{error}}',
  'Set {{key}} = {{value}}': 'Set {{key}} = {{value}}',
  '(This setting requires a restart to take effect.)':
    '(This setting requires a restart to take effect.)',
  '(Security-sensitive setting — verify you are not exposing credentials.)':
    '(Security-sensitive setting — verify you are not exposing credentials.)',
  'Setting tools.approvalMode to "yolo" is blocked via /config for security reasons. Edit settings.json directly if you understand the risks.':
    'Setting tools.approvalMode to "yolo" is blocked via /config for security reasons. Edit settings.json directly if you understand the risks.',
  '(empty)': '(empty)',
  Global: 'Global',
  'Alibaba Cloud (alibabacloud.com)': 'Alibaba Cloud (alibabacloud.com)',
  'Select region for Coding Plan:': 'Select region for Coding Plan:',
  'Enter your Coding Plan API key: ': 'Enter your Coding Plan API key: ',
  'Select authentication method:': 'Select authentication method:',
  '\n=== Authentication Status ===\n': '\n=== Authentication Status ===\n',
  '⚠  No authentication method configured.\n':
    '⚠  No authentication method configured.\n',
  'Run one of the following commands to get started:\n':
    'Run one of the following commands to get started:\n',
  '  qwen auth qwen-oauth     - Authenticate with Qwen OAuth (discontinued)':
    '  qwen auth qwen-oauth     - Authenticate with Qwen OAuth (discontinued)',
  'Or simply run:': 'Or simply run:',
  '  qwen auth                - Interactive authentication setup\n':
    '  qwen auth                - Interactive authentication setup\n',
  '✓ Authentication Method: Qwen OAuth': '✓ Authentication Method: Qwen OAuth',
  '  Type: Free tier (discontinued 2026-04-15)':
    '  Type: Free tier (discontinued 2026-04-15)',
  '  Limit: No longer available': '  Limit: No longer available',
  'Qwen OAuth free tier was discontinued on 2026-04-15. Run /auth to switch to Coding Plan, OpenRouter, Fireworks AI, or another provider.':
    'Qwen OAuth free tier was discontinued on 2026-04-15. Run /auth to switch to Coding Plan, OpenRouter, Fireworks AI, or another provider.',
  '✓ Authentication Method: Alibaba Cloud Coding Plan':
    '✓ Authentication Method: Alibaba Cloud Coding Plan',
  '中国 (China) - 阿里云百炼': '中国 (China) - 阿里云百炼',
  'Global - Alibaba Cloud': 'Global - Alibaba Cloud',
  '  Region: {{region}}': '  Region: {{region}}',
  '  Current Model: {{model}}': '  Current Model: {{model}}',
  '  Config Version: {{version}}': '  Config Version: {{version}}',
  '  Status: API key configured\n': '  Status: API key configured\n',
  '⚠  Authentication Method: Alibaba Cloud Coding Plan (Incomplete)':
    '⚠  Authentication Method: Alibaba Cloud Coding Plan (Incomplete)',
  '  Issue: API key not found in environment or settings\n':
    '  Issue: API key not found in environment or settings\n',
  '  Run `qwen auth coding-plan` to re-configure.\n':
    '  Run `qwen auth coding-plan` to re-configure.\n',
  '✓ Authentication Method: {{type}}': '✓ Authentication Method: {{type}}',
  '  Status: Configured\n': '  Status: Configured\n',
  'Failed to check authentication status: {{error}}':
    'Failed to check authentication status: {{error}}',
  'Select an option:': 'Select an option:',
  'Raw mode not available. Please run in an interactive terminal.':
    'Raw mode not available. Please run in an interactive terminal.',
  '(Use ↑ ↓ arrows to navigate, Enter to select, Ctrl+C to exit)\n':
    '(Use ↑ ↓ arrows to navigate, Enter to select, Ctrl+C to exit)\n',
  'Switch to plan mode or exit plan mode':
    'Switch to plan mode or exit plan mode',
  'Set how hard reasoning-capable models think ({{tiers}}); mapped and clamped per provider.':
    'Set how hard reasoning-capable models think ({{tiers}}); mapped and clamped per provider.',
  'Choose the output style that shapes how responses are written ({{styles}}, or a custom style name).':
    'Choose the output style that shapes how responses are written ({{styles}}, or a custom style name).',
  'It is saved but does not apply while this workspace is untrusted.':
    'It is saved but does not apply while this workspace is untrusted.',
  'Set or control a session goal': 'Set or control a session goal',
  'Exited plan mode. Previous approval mode restored.':
    'Exited plan mode. Previous approval mode restored.',
  'Enabled plan mode. The agent will analyze and plan without executing tools.':
    'Enabled plan mode. The agent will analyze and plan without executing tools.',
  'Already in plan mode. Use "/plan exit" to exit plan mode.':
    'Already in plan mode. Use "/plan exit" to exit plan mode.',
  'Not in plan mode. Use "/plan" to enter plan mode first.':
    'Not in plan mode. Use "/plan" to enter plan mode first.',
  "Set up Qwen Code's status line UI": "Set up Qwen Code's status line UI",

  // === Core: added from PR #3328 ===
  'Open the memory manager.': 'Open the memory manager.',
  'Show current process memory diagnostics':
    'Show current process memory diagnostics',
  'Record a CPU profile for Chrome DevTools analysis':
    'Record a CPU profile for Chrome DevTools analysis',
  'Roll back a standalone update to the previous version':
    'Roll back a standalone update to the previous version',
  'Rollback is not available in ACP mode.':
    'Rollback is not available in ACP mode.',
  'Rollback is only available for standalone installations.':
    'Rollback is only available for standalone installations.',
  'Rollback successful. Restart your terminal to use the previous version.':
    'Rollback successful. Restart your terminal to use the previous version.',
  'Rollback failed:': 'Rollback failed:',
  'Rollback on Windows requires manual intervention. Rename qwen-code.old to qwen-code in your installation directory.':
    'Rollback on Windows requires manual intervention. Rename qwen-code.old to qwen-code in your installation directory.',
  'Save a durable memory to the memory system.':
    'Save a durable memory to the memory system.',
  'Ask a quick side question without affecting the main conversation':
    'Ask a quick side question without affecting the main conversation',
  'Get a second opinion on the current conversation from a reviewer model':
    'Get a second opinion on the current conversation from a reviewer model',
  'Configure the Advisor model': 'Configure the Advisor model',
  'Disable Advisor': 'Disable Advisor',
  'Select Advisor Model': 'Select Advisor Model',
  'Advisor disabled': 'Advisor disabled',
  'Advisor set to {{model}}': 'Advisor set to {{model}}',
  'Selected Advisor model is unavailable.':
    'Selected Advisor model is unavailable.',
  'Advisor configuration is unavailable.':
    'Advisor configuration is unavailable.',
  'Consulting advisor...': 'Consulting advisor...',
  'Advisor review failed: {{error}}': 'Advisor review failed: {{error}}',
  'No conversation context available for /advisor':
    'No conversation context available for /advisor',
  'Focus too long (max {{max}} chars)': 'Focus too long (max {{max}} chars)',
  'Another operation is in progress, wait for it to complete before running /advisor':
    'Another operation is in progress, wait for it to complete before running /advisor',
  'No response received.': 'No response received.',
  'No model configured.': 'No model configured.',
  'Manage Arena sessions': 'Manage Arena sessions',
  'Start an Arena session with multiple models competing on the same task':
    'Start an Arena session with multiple models competing on the same task',
  'Stop the current Arena session': 'Stop the current Arena session',
  'Show the current Arena session status':
    'Show the current Arena session status',
  'Select a model result and merge its diff into the current workspace':
    'Select a model result and merge its diff into the current workspace',
  'No running Arena session found.': 'No running Arena session found.',
  'No Arena session found. Start one with /arena start.':
    'No Arena session found. Start one with /arena start.',
  'Arena session is still running. Wait for it to complete or use /arena stop first.':
    'Arena session is still running. Wait for it to complete or use /arena stop first.',
  'No successful agent results to select from. All agents failed or were cancelled.':
    'No successful agent results to select from. All agents failed or were cancelled.',
  'Use /arena stop to end the session.': 'Use /arena stop to end the session.',
  'No idle agent found matching "{{name}}".':
    'No idle agent found matching "{{name}}".',
  'Failed to apply changes from {{label}}: {{error}}':
    'Failed to apply changes from {{label}}: {{error}}',
  'Applied changes from {{label}} to workspace. Arena session complete.':
    'Applied changes from {{label}} to workspace. Arena session complete.',
  'Discard all Arena results and clean up worktrees?':
    'Discard all Arena results and clean up worktrees?',
  'Arena results discarded. All worktrees cleaned up.':
    'Arena results discarded. All worktrees cleaned up.',
  'Arena is not supported in non-interactive mode. Use interactive mode to start an Arena session.':
    'Arena is not supported in non-interactive mode. Use interactive mode to start an Arena session.',
  'Arena is not supported in non-interactive mode. Use interactive mode to stop an Arena session.':
    'Arena is not supported in non-interactive mode. Use interactive mode to stop an Arena session.',
  'Arena is not supported in non-interactive mode.':
    'Arena is not supported in non-interactive mode.',
  'An Arena session exists. Use /arena stop or /arena select to end it before starting a new one.':
    'An Arena session exists. Use /arena stop or /arena select to end it before starting a new one.',
  'Usage: /arena start --models model1,model2 <task>':
    'Usage: /arena start --models model1,model2 <task>',
  'Models to compete (required, at least 2)':
    'Models to compete (required, at least 2)',
  'Format: authType:modelId or just modelId':
    'Format: authType:modelId or just modelId',
  'Arena requires at least 2 models. Use --models model1,model2 to specify.':
    'Arena requires at least 2 models. Use --models model1,model2 to specify.',
  'Arena started with {{count}} agents on task: "{{task}}"\nModels:\n{{modelList}}':
    'Arena started with {{count}} agents on task: "{{task}}"\nModels:\n{{modelList}}',
  'Arena panes are running in tmux. Attach with: `{{command}}`':
    'Arena panes are running in tmux. Attach with: `{{command}}`',
  '[{{label}}] failed: {{error}}': '[{{label}}] failed: {{error}}',
  'Loading suggestions...': 'Loading suggestions...',
  'Show per-item context usage breakdown.':
    'Show per-item context usage breakdown.',
  'No compression needed.': 'No compression needed.',

  // ============================================================================
  // Stats
  // ============================================================================

  // statsCommand non-interactive output
  'Session duration: {{duration}}': 'Session duration: {{duration}}',
  'Prompts: {{count}}': 'Prompts: {{count}}',
  'API requests: {{count}}': 'API requests: {{count}}',
  'Tokens — prompt: {{prompt}}, output: {{output}}':
    'Tokens — prompt: {{prompt}}, output: {{output}}',
  'Tool calls: {{total}} ({{success}} ok, {{fail}} fail)':
    'Tool calls: {{total}} ({{success}} ok, {{fail}} fail)',
  'Files: +{{added}} / -{{removed}} lines':
    'Files: +{{added}} / -{{removed}} lines',
  prompt: 'prompt',
  output: 'output',
  cached: 'cached',
  'Estimated cost: ${{cost}}': 'Estimated cost: ${{cost}}',
  'No model usage data yet.': 'No model usage data yet.',
  'No tool usage data yet.': 'No tool usage data yet.',

  // StatsDialog
  Models: 'Models',
  'All time': 'All time',
  'Last 7 days': 'Last 7 days',
  'Last 30 days': 'Last 30 days',
  'N/A': 'N/A',
  Sessions: 'Sessions',
  days: 'days',
  Input: 'Input',
  'Tool calls': 'Tool calls',
  'Code changes': 'Code changes',
  Projects: 'Projects',
  Name: 'Name',
  Duration: 'Duration',
  'Activity Heatmap': 'Activity Heatmap',
  'Loading stats...': 'Loading stats...',
  '\u2191 tabs \u00b7 r to cycle dates \u00b7 esc to close':
    '\u2191 tabs \u00b7 r to cycle dates \u00b7 esc to close',
  Cost: 'Cost',
  Less: 'Less',
  More: 'More',
  '(no data)': '(no data)',
  d: 'd',
  h: 'h',
  m: 'm',

  // Stats Dashboard — keyboard hints (not translated)
  'tab \xB7 esc': 'tab \xB7 esc',
  'tab \xB7 r dates \xB7 \u2190\u2192 month \xB7 esc':
    'tab \xB7 r dates \xB7 \u2190\u2192 month \xB7 esc',
  'tab \xB7 r dates \xB7 esc': 'tab \xB7 r dates \xB7 esc',

  // Stats Dashboard — labels
  Session: 'Session',
  Activity: 'Activity',
  Efficiency: 'Efficiency',
  Success: 'Success',
  Today: 'Today',
  'Cache Hit Rate': 'Cache Hit Rate',
  'Tool Success': 'Tool Success',
  'Tool Leaderboard': 'Tool Leaderboard',
  Time: 'Time',
  Cache: 'Cache',
  Latency: 'Latency',
  'Code Impact': 'Code Impact',
  'Failed to load stats. Press r to retry.':
    'Failed to load stats. Press r to retry.',
  net: 'net',
  streak: 'streak',
  best: 'best',
  'Token Trend': 'Token Trend',
  'In/Out': 'In/Out',
  'API Requests': 'API Requests',
  'Tool Calls': 'Tool Calls',
  'Success rate': 'Success rate',
  'Code Changes': 'Code Changes',
  Tool: 'Tool',
  reqs: 'reqs',
  in: 'in',
  out: 'out',

  // Update command
  'Check for Qwen Code updates and install if available':
    'Check for Qwen Code updates and install if available',
  'Qwen Code update available! {{current}} → {{latest}}':
    'Qwen Code update available! {{current}} → {{latest}}',
  'A new version of Qwen Code is available! {{current}} → {{latest}}':
    'A new version of Qwen Code is available! {{current}} → {{latest}}',
  'Qwen Code {{version}} is up to date!':
    'Qwen Code {{version}} is up to date!',
  'Failed to check for updates ({{reason}}). Please check your network or registry configuration.':
    'Failed to check for updates ({{reason}}). Please check your network or registry configuration.',
  'Update check skipped ({{reason}}) — run /update to retry.':
    'Update check skipped ({{reason}}) — run /update to retry.',
  'registry did not respond within {{seconds}}s':
    'registry did not respond within {{seconds}}s',
  'registry unreachable': 'registry unreachable',
  'registry error': 'registry error',
  'Unable to check for updates: {{reason}}':
    'Unable to check for updates: {{reason}}',
  'Update successful! The new version will be used on your next run.':
    'Update successful! The new version will be used on your next run.',
  'Update downloaded. It will be applied after you exit this session.':
    'Update downloaded. It will be applied after you exit this session.',
  'Update failed: {{error}}': 'Update failed: {{error}}',
  'Downloading update...': 'Downloading update...',
  'Update successful! Please restart Qwen Code to use the new version. Switching model providers before restarting may not work correctly.':
    'Update successful! Please restart Qwen Code to use the new version. Switching model providers before restarting may not work correctly.',
  'Automatic update failed. Please try updating manually.':
    'Automatic update failed. Please try updating manually.',
  'Automatic update failed: {{error}}. Re-run the installer to update manually.':
    'Automatic update failed: {{error}}. Re-run the installer to update manually.',
  'Running from a local git clone. Please update with "git pull".':
    'Running from a local git clone. Please update with "git pull".',
  'Running via npx, update not applicable.':
    'Running via npx, update not applicable.',
  'Running via pnpx, update not applicable.':
    'Running via pnpx, update not applicable.',
  'Running via bunx, update not applicable.':
    'Running via bunx, update not applicable.',
  'Installed via Homebrew. Please update with "brew upgrade".':
    'Installed via Homebrew. Please update with "brew upgrade".',
  "Locally installed. Please update via your project's package.json.":
    "Locally installed. Please update via your project's package.json.",
  'Update requires sudo. Please run:': 'Update requires sudo. Please run:',
  'Standalone install detected. Attempting to automatically update now...':
    'Standalone install detected. Attempting to automatically update now...',
  'Standalone install detected. Please rerun the standalone installer to update:':
    'Standalone install detected. Please rerun the standalone installer to update:',
  'Run the following to update:': 'Run the following to update:',
  'Unable to auto-update this standalone installation. Please reinstall from:':
    'Unable to auto-update this standalone installation. Please reinstall from:',
  'Manual update required. Please reinstall Qwen Code.':
    'Manual update required. Please reinstall Qwen Code.',
  'This session uses the custom sandbox image {{image}}. Update that image and restart Qwen Code.':
    'This session uses the custom sandbox image {{image}}. Update that image and restart Qwen Code.',
  'Update Qwen Code on the host, then restart the sandbox.':
    'Update Qwen Code on the host, then restart the sandbox.',
  'The update will be installed after you exit this session.':
    'The update will be installed after you exit this session.',
  'Run /update to install the update on the host.':
    'Run /update to install the update on the host.',
  'Run /update to install the update.': 'Run /update to install the update.',
  '⚠️ History gap: earlier conversation was lost before this point (storage interruption) and could not be recovered.':
    '⚠️ History gap: earlier conversation was lost before this point (storage interruption) and could not be recovered.',

  // ============================================================================
  // reload-plugins command
  // ============================================================================
  '{{count}} extension': '{{count}} extension',
  '{{count}} extensions': '{{count}} extensions',
  '{{count}} command': '{{count}} command',
  '{{count}} commands': '{{count}} commands',
  '{{count}} skill': '{{count}} skill',
  '{{count}} skills': '{{count}} skills',
  '{{count}} agent': '{{count}} agent',
  '{{count}} agents': '{{count}} agents',
  '{{count}} workflow': '{{count}} workflow',
  '{{count}} workflows': '{{count}} workflows',
  '{{count}} hook': '{{count}} hook',
  '{{count}} hooks': '{{count}} hooks',
  '{{count}} extension MCP server': '{{count}} extension MCP server',
  '{{count}} extension MCP servers': '{{count}} extension MCP servers',
  '{{count}} extension LSP server': '{{count}} extension LSP server',
  '{{count}} extension LSP servers': '{{count}} extension LSP servers',
  'Reload extension changes from disk': 'Reload extension changes from disk',
  'Reloaded extensions: {{summary}}': 'Reloaded extensions: {{summary}}',
  'Reload failed: {{message}}': 'Reload failed: {{message}}',
  'Reload failed.': 'Reload failed.',
  'Extensions changed on disk. Run /reload-plugins to apply updates.':
    'Extensions changed on disk. Run /reload-plugins to apply updates.',
  'Failed to refresh extension content: {{message}}. Run /reload-plugins to apply updates.':
    'Failed to refresh extension content: {{message}}. Run /reload-plugins to apply updates.',
  'Failed to refresh extension content. Run /reload-plugins to apply updates.':
    'Failed to refresh extension content. Run /reload-plugins to apply updates.',
  'Extension reload did not complete. Run /reload-plugins to try again.':
    'Extension reload did not complete. Run /reload-plugins to try again.',
  'Precondition check': 'Precondition check',
  'Precondition not met — this scheduled run was skipped.':
    'Precondition not met — this scheduled run was skipped.',
  'The precondition check was cancelled — this scheduled run was skipped.':
    'The precondition check was cancelled — this scheduled run was skipped.',
  'The precondition check was interrupted — this scheduled run was skipped.':
    'The precondition check was interrupted — this scheduled run was skipped.',
  'The precondition check failed — this scheduled run was skipped.':
    'The precondition check failed — this scheduled run was skipped.',
  'Running this scheduled task in a new session: {{link}}':
    'Running this scheduled task in a new session: {{link}}',
  'This scheduled run could not be started: {{error}}':
    'This scheduled run could not be started: {{error}}',
  'Session recording stopped after a write failure. New messages for the affected session will not be saved. Check disk space and permissions, then start a new session to resume recording. See the debug log for details.':
    'Session recording stopped after a write failure. New messages for the affected session will not be saved. Check disk space and permissions, then start a new session to resume recording. See the debug log for details.',
  'Session recording stopped after a write failure. New messages for the affected session will not be saved. Check disk space and permissions, then run `/clear` to start a new recorded session. See the debug log for details.':
    'Session recording stopped after a write failure. New messages for the affected session will not be saved. Check disk space and permissions, then run `/clear` to start a new recorded session. See the debug log for details.',

  // ==========================================================================
  // Auto-skill curator (/curator command)
  // ==========================================================================
  'Maintain project auto-skills based on recent use.':
    'Maintain project auto-skills based on recent use.',
  'Show project auto-skill lifecycle status.':
    'Show project auto-skill lifecycle status.',
  'Run project auto-skill lifecycle maintenance.':
    'Run project auto-skill lifecycle maintenance.',
  'Restore an archived project auto-skill.':
    'Restore an archived project auto-skill.',
  'Auto-skill curator': 'Auto-skill curator',
  'Last run: {{time}}': 'Last run: {{time}}',
  'Active: {{count}}': 'Active: {{count}}',
  'Stale: {{count}}': 'Stale: {{count}}',
  'Archived: {{count}}': 'Archived: {{count}}',
  'Stale skills:': 'Stale skills:',
  'Pinned skills:': 'Pinned skills:',
  'Archived skills:': 'Archived skills:',
  'Dry run complete.': 'Dry run complete.',
  'Curator run complete.': 'Curator run complete.',
  'Checked: {{count}}': 'Checked: {{count}}',
  'First observed: {{count}}': 'First observed: {{count}}',
  'Marked stale: {{count}}': 'Marked stale: {{count}}',
  'Reactivated: {{count}}': 'Reactivated: {{count}}',
  'Skipped archive collisions: {{count}}':
    'Skipped archive collisions: {{count}}',
  'Archive candidates:': 'Archive candidates:',
  'Skipped archive collisions:': 'Skipped archive collisions:',
  'Skipped rename errors: {{count}}': 'Skipped rename errors: {{count}}',
  'Skipped rename errors:': 'Skipped rename errors:',
  '{{verb}}: {{count}}': '{{verb}}: {{count}}',
  'Would archive': 'Would archive',
  Archived: 'Archived',
  'Failed to read auto-skill curator status: {{message}}':
    'Failed to read auto-skill curator status: {{message}}',
  'Usage: /curator run [--dry-run]': 'Usage: /curator run [--dry-run]',
  'Failed to run auto-skill curator: {{message}}':
    'Failed to run auto-skill curator: {{message}}',
  'Usage: /curator restore <directory>': 'Usage: /curator restore <directory>',
  'Restored auto-skill: {{name}}': 'Restored auto-skill: {{name}}',
  'Failed to restore auto-skill: {{message}}':
    'Failed to restore auto-skill: {{message}}',
  'Exclude an auto-skill from automatic maintenance.':
    'Exclude an auto-skill from automatic maintenance.',
  'Return a pinned auto-skill to automatic maintenance.':
    'Return a pinned auto-skill to automatic maintenance.',
  'Usage: /curator pin <directory>': 'Usage: /curator pin <directory>',
  'Usage: /curator unpin <directory>': 'Usage: /curator unpin <directory>',
  'Pinned auto-skill: {{name}}': 'Pinned auto-skill: {{name}}',
  'Unpinned auto-skill: {{name}}': 'Unpinned auto-skill: {{name}}',
  'Failed to update auto-skill pin: {{message}}':
    'Failed to update auto-skill pin: {{message}}',
  'Auto-skill curator changes are disabled in safe mode.':
    'Auto-skill curator changes are disabled in safe mode.',
  'Auto-skill curator changes are only available in trusted workspaces. Trust this folder via `/trust` and try again.':
    'Auto-skill curator changes are only available in trusted workspaces. Trust this folder via `/trust` and try again.',
  'Kept model as {{model}}': 'Kept model as {{model}}',
  'Review messages held from other Qwen Code sessions (accept | deny), and manage trusted controllers (controllers | revoke)':
    'Review messages held from other Qwen Code sessions (accept | deny), and manage trusted controllers (controllers | revoke)',
  'Create a git commit with an AI-drafted message':
    'Create a git commit with an AI-drafted message',
};
