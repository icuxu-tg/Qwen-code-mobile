/**
 * @license
 * Copyright 2025 Qwen
 * SPDX-License-Identifier: Apache-2.0
 */

// Portuguese translations for Qwen Code CLI (pt-BR)

export default {
  // ============================================================================
  // Help / UI Components
  // ============================================================================
  'Basics:': 'Noções básicas:',
  'Add context': 'Adicionar contexto',
  'Use {{symbol}} to specify files for context (e.g., {{example}}) to target specific files or folders.':
    'Use {{symbol}} para especificar arquivos para o contexto (ex: {{example}}) para atingir arquivos ou pastas específicos.',
  '@': '@',
  '@src/myFile.ts': '@src/myFile.ts',
  'Shell mode': 'Modo shell',
  'YOLO mode': 'Modo YOLO',
  'Auto mode': 'Modo auto',
  'auto_mode.entry_notice':
    'Modo auto ativado.\n   Um classificador LLM avalia cada chamada de ferramenta — ações seguras são aprovadas automaticamente,\n   ações arriscadas são bloqueadas. Sair: Shift+Tab ou /approval-mode default.',
  'plan mode': 'modo planejamento',
  'auto-accept edits': 'aceitar edições automaticamente',
  'Accepting edits': 'Aceitando edições',
  '(shift + tab to cycle)': '(Shift + Tab para alternar)',
  'Execute shell commands via {{symbol}} (e.g., {{example1}}) or use natural language (e.g., {{example2}}).':
    'Execute comandos shell via {{symbol}} (ex: {{example1}}) ou use linguagem natural (ex: {{example2}}).',
  '!': '!',
  '!npm run start': '!npm run start',
  'start server': 'iniciar servidor',
  'Commands:': 'Comandos:',
  'shell command': 'comando shell',
  'Model Context Protocol command (from external servers)':
    'Comando Model Context Protocol (de servidores externos)',
  'Keyboard Shortcuts:': 'Atalhos de teclado:',
  'Toggle this help display': 'Alternar exibição desta ajuda',
  'Toggle shell mode': 'Alternar modo shell',
  'Open command menu': 'Abrir menu de comandos',
  'Add file context': 'Adicionar contexto de arquivo',
  'Accept suggestion / Autocomplete': 'Aceitar sugestão / Autocompletar',
  'Reverse search history': 'Pesquisa reversa no histórico',
  'Press ? again to close': 'Pressione ? novamente para fechar',
  // Keyboard shortcuts panel descriptions
  'for shell mode': 'para modo shell',
  'for commands': 'para comandos',
  'for file paths': 'para caminhos de arquivo',
  'to clear input': 'para limpar entrada',
  'to cycle approvals': 'para alternar aprovações',
  'to quit': 'para sair',
  'for newline': 'para nova linha',
  'to clear screen': 'para limpar a tela',
  'to search history': 'para pesquisar no histórico',
  'to paste images': 'para colar imagens',
  'for external editor': 'para editor externo',
  'to expand details': 'para expandir os detalhes',
  'Jump through words in the input': 'Pular palavras na entrada',
  'Close dialogs, cancel requests, or quit application':
    'Fechar diálogos, cancelar solicitações ou sair do aplicativo',
  'New line': 'Nova linha',
  'New line (Alt+Enter works for certain linux distros)':
    'Nova linha (Alt+Enter funciona em certas distros linux)',
  'Clear the screen': 'Limpar a tela',
  'Open input in external editor': 'Abrir entrada no editor externo',
  'Send message': 'Enviar mensagem',
  'Initializing...': 'Inicializando...',
  'Connecting to MCP servers... ({{connected}}/{{total}})':
    'Conectando aos MCP servers... ({{connected}}/{{total}})',
  'Type your message or @path/to/file':
    'Digite sua mensagem ou @caminho/do/arquivo',
  '? for shortcuts': '? para atalhos',
  'Pasting…': 'Colando…',
  "Press 'i' for INSERT mode and 'Esc' for NORMAL mode.":
    "Pressione 'i' para modo INSERÇÃO e 'Esc' para modo NORMAL.",
  'Cancel operation / Clear input (double press)':
    'Cancelar operação / Limpar entrada (pressionar duas vezes)',
  'Cycle approval modes': 'Alternar modos de aprovação',
  'Cycle through your prompt history': 'Alternar histórico de prompts',
  'For a full list of shortcuts, see {{docPath}}':
    'Para uma lista completa de atalhos, consulte {{docPath}}',
  'docs/keyboard-shortcuts.md': 'docs/keyboard-shortcuts.md',
  'for help on Qwen Code': 'para ajuda sobre o Qwen Code',
  'show version info': 'mostrar informações de versão',
  'submit a bug report': 'enviar um relatório de erro',
  // ============================================================================
  // System Information Fields
  // ============================================================================
  'Qwen Code': 'Qwen Code',
  OS: 'SO',
  Auth: 'Autenticação',
  Model: 'Modelo',
  'Fast Model': 'Modelo Rápido',
  Sandbox: 'Sandbox',
  'Session ID': 'ID da Sessão',
  'Base URL': 'Base URL',
  Proxy: 'Proxy',
  'Memory Usage': 'Uso de Memória',
  'IDE Client': 'Cliente IDE',

  // ============================================================================
  // Commands - General
  // ============================================================================
  'Analyzes the project and creates a tailored QWEN.md file.':
    'Analisa o projeto e cria um arquivo QWEN.md personalizado.',
  'List available Qwen Code tools. Usage: /tools [desc]':
    'Listar ferramentas Qwen Code disponíveis. Uso: /tools [desc]',
  'Open the skills panel (browse, search, toggle, pick).':
    'Abrir o painel de habilidades (explorar, pesquisar, ativar, selecionar).',
  'Manage Skills': 'Gerenciar Habilidades',
  'Skills configuration saved.': 'Configuração de habilidades salva.',
  'Skills configuration saved, but refresh failed: {{error}}. Restart to ensure the new state is applied.':
    'Configuração de habilidades salva, mas a atualização falhou: {{error}}. Reinicie para garantir que o novo estado seja aplicado.',
  'Workspace is untrusted; workspace settings are ignored by the merged config. Run /trust first to persist skills changes here, or edit ~/.qwen/settings.json directly to manage skills at user scope.':
    'O espaço de trabalho não é confiável; as configurações do espaço de trabalho são ignoradas pela configuração combinada. Execute /trust primeiro, ou edite ~/.qwen/settings.json diretamente para gerenciar habilidades no escopo do usuário.',
  'SkillManager not available.': 'SkillManager indisponível.',
  'Loading skills…': 'Carregando habilidades…',
  'Failed to load skills: {{error}}':
    'Falha ao carregar habilidades: {{error}}',
  'Failed to save skills configuration: {{error}}':
    'Falha ao salvar a configuração de habilidades: {{error}}',
  'All available skills are disabled. Edit ~/.qwen/settings.json or .qwen/settings.json (skills.disabled) to re-enable.':
    'Todas as habilidades disponíveis estão desativadas. Edite ~/.qwen/settings.json ou .qwen/settings.json (skills.disabled) para reativá-las.',
  'Press esc to close.': 'Pressione Esc para fechar.',
  '{{count}} skills · ': '{{count}} habilidades · ',
  '{{matched}} / {{total}} skills · ': '{{matched}} / {{total}} habilidades · ',
  'Space toggle · Enter pick (fill input) · Esc save & exit · workspace scope':
    'Espaço alternar · Enter selecionar (preencher entrada) · Esc salvar & sair · escopo do espaço de trabalho',
  'Search:': 'Pesquisar:',
  'type to filter…': 'digite para filtrar…',
  'No skills are currently available.':
    'Nenhuma habilidade está disponível no momento.',
  'No skills match the search.': 'Nenhuma habilidade corresponde à pesquisa.',
  'Locked by settings entries you cannot toggle here:':
    'Bloqueado por entradas de configuração (não é possível alternar aqui):',
  '{{count}} locked not shown': '{{count}} habilidades bloqueadas não exibidas',
  'higher scope': 'escopo superior',
  '  {{name}} {{description}}  [locked: {{scope}}]':
    '  {{name}} {{description}}  [bloqueado: {{scope}}]',
  '↑/↓ navigate · backspace edits search':
    '↑/↓ navegar · Backspace edita a pesquisa',
  Bundled: 'Integrada',
  'Available Qwen Code CLI tools:': 'Ferramentas CLI do Qwen Code disponíveis:',
  'No tools available': 'Nenhuma ferramenta disponível',
  'View or change the approval mode for tool usage':
    'Ver ou alterar o modo de aprovação para uso de ferramentas',
  'Invalid approval mode "{{arg}}". Valid modes: {{modes}}':
    'Modo de aprovação inválido "{{arg}}". Modos válidos: {{modes}}',
  'Approval mode set to "{{mode}}"':
    'Modo de aprovação definido como "{{mode}}"',
  'View or change the language setting':
    'Ver ou alterar a configuração de idioma',
  'List background tasks (text dump — interactive dialog opens via the footer pill)':
    'Listar tarefas em segundo plano (saída em texto; a caixa de diálogo interativa pode ser aberta pelo indicador no rodapé)',
  'Delete a previous session': 'Excluir uma sessão anterior',
  'Run installation and environment diagnostics':
    'Executar diagnósticos de instalação e ambiente',
  'Browse dynamic model catalogs and choose which models stay enabled locally':
    'Navegar pelos catálogos dinâmicos de modelos e escolher quais modelos permanecem ativados localmente',
  'Generate a one-line session recap now':
    'Gerar agora um resumo da sessão em uma linha',
  'Rename the current conversation. --auto lets the fast model pick a title.':
    'Renomear a conversa atual. --auto permite que o modelo rápido escolha um título.',
  'Rewind conversation to a previous turn':
    'Voltar a conversa para um turno anterior',
  'Rewind Conversation': 'Rebobinar conversa',
  'No user turns to rewind to.': 'Nenhum turno de usuário para rebobinar.',
  'Rewind to: ': 'Rebobinar para: ',
  'Restore code and conversation': 'Restaurar código e conversa',
  'Restore conversation only': 'Restaurar apenas a conversa',
  'Restore code only': 'Restaurar apenas o código',
  'Never mind': 'Deixa pra lá',
  'Computing file changes...': 'Calculando alterações de arquivo...',
  'Restoring...': 'Restaurando...',
  'Restored {{count}} file(s).': '{{count}} arquivo(s) restaurado(s).',
  'Failed to restore files: {{error}}':
    'Falha ao restaurar arquivos: {{error}}',
  'Rewind failed: {{error}}': 'Falha ao retroceder: {{error}}',
  'Cannot rewind conversation: no active model client.':
    'Não é possível retroceder a conversa: nenhum cliente de modelo ativo.',
  'Code restored, but conversation could not be rewound (no active client).':
    'Código restaurado, mas a conversa não pôde ser retrocedida (sem cliente ativo).',
  'Conversation rewound. Edit your prompt and press Enter to continue.':
    'Conversa retrocedida. Edite seu prompt e pressione Enter para continuar.',
  'Rewinding does not affect files edited manually or via shell commands.':
    'O retrocesso não afeta arquivos editados manualmente ou por meio de comandos shell.',
  'Cannot rewind to a turn that was compressed. Try a more recent turn.':
    'Não é possível retroceder para um turno que foi compactado. Tente um turno mais recente.',
  'Cannot rewind the conversation to this turn: it no longer matches the model history (for example, after a retry). Try a more recent turn.':
    'Não é possível retroceder a conversa para este turno: ele não corresponde mais ao histórico do modelo (por exemplo, após uma nova tentativa). Tente um turno mais recente.',
  'File restore is unavailable for this turn (no captured file changes, or this turn predates the current session).':
    'A restauração de arquivos não está disponível para este turno (sem alterações capturadas, ou o turno é anterior à sessão atual).',
  '(+{{insertions}} -{{deletions}} in {{count}} file)':
    '(+{{insertions}} -{{deletions}} em {{count}} arquivo)',
  '(+{{insertions}} -{{deletions}} in {{count}} files)':
    '(+{{insertions}} -{{deletions}} em {{count}} arquivos)',
  'Failed to restore {{count}} file(s): {{files}}':
    'Falha ao restaurar {{count}} arquivo(s): {{files}}',
  'Cannot restore files: this turn was created before file checkpointing was enabled.':
    'Não é possível restaurar arquivos: este turno foi criado antes do checkpoint de arquivos ser ativado.',
  'No files needed to be restored.': 'Nenhum arquivo precisou ser restaurado.',
  '↑↓ to navigate · Enter to select · Esc to go back':
    '↑↓ navegar · Enter selecionar · Esc voltar',
  '↑↓ to navigate · Enter to select · Esc to cancel':
    '↑↓ navegar · Enter selecionar · Esc cancelar',
  'Enter/Y to confirm · Esc/N to go back': 'Enter/Y confirmar · Esc/N voltar',
  'change the theme': 'alterar o tema',
  'Select Theme': 'Selecionar Tema',
  Preview: 'Visualizar',
  '(Use Enter to select, Tab to configure scope)':
    '(Use Enter para selecionar, Tab para configurar o escopo)',
  '(Use Enter to apply scope, Tab to go back)':
    '(Use Enter para aplicar o escopo, Tab para voltar)',
  'Theme configuration unavailable due to NO_COLOR env variable.':
    'Configuração de tema indisponível devido à variável de ambiente NO_COLOR.',
  'Theme "{{themeName}}" not found.': 'Tema "{{themeName}}" não encontrado.',
  'Theme "{{themeName}}" not found in selected scope.':
    'Tema "{{themeName}}" não encontrado no escopo selecionado.',
  'Clear conversation history and free up context':
    'Limpar histórico de conversa e liberar contexto',
  'Compresses the context by replacing it with a summary.':
    'Comprime o contexto substituindo-o por um resumo.',
  'open full Qwen Code documentation in your browser':
    'abrir documentação completa do Qwen Code no seu navegador',
  'Configuration not available.': 'Configuração não disponível.',
  'Connect an LLM provider': 'Conectar a um provedor LLM',
  'Copy the last AI response to clipboard (/copy N for Nth-latest)':
    'Copiar a última resposta da IA para a área de transferência (/copy N para a N-ésima)',

  // ============================================================================
  // Commands - Agents
  // ============================================================================
  'Manage subagents for specialized task delegation.':
    'Gerenciar subagentes para delegação de tarefas especializadas.',
  'Manage existing subagents (view, edit, delete).':
    'Gerenciar subagentes existentes (ver, editar, excluir).',
  'Create a new subagent with guided setup.':
    'Criar um novo subagente com configuração guiada.',

  // ============================================================================
  // Agents - Management Dialog
  // ============================================================================
  Agents: 'Agentes',
  'Choose Action': 'Escolher Ação',
  'Edit {{name}}': 'Editar {{name}}',
  'Edit Tools: {{name}}': 'Editar Ferramentas: {{name}}',
  'Edit Color: {{name}}': 'Editar Cor: {{name}}',
  'Delete {{name}}': 'Excluir {{name}}',
  'Unknown Step': 'Etapa Desconhecida',
  'Esc to close': 'Esc para fechar',
  Transcript: 'Transcrição',
  'Read {{count}} file': 'Leu {{count}} arquivo',
  'Read {{count}} files': 'Leu {{count}} arquivos',
  'Reading {{count}} file': 'Lendo {{count}} arquivo',
  'Reading {{count}} files': 'Lendo {{count}} arquivos',
  'Edited {{count}} file': 'Editou {{count}} arquivo',
  'Edited {{count}} files': 'Editou {{count}} arquivos',
  'Editing {{count}} file': 'Editando {{count}} arquivo',
  'Editing {{count}} files': 'Editando {{count}} arquivos',
  'Wrote {{count}} file': 'Escreveu {{count}} arquivo',
  'Wrote {{count}} files': 'Escreveu {{count}} arquivos',
  'Writing {{count}} file': 'Escrevendo {{count}} arquivo',
  'Writing {{count}} files': 'Escrevendo {{count}} arquivos',
  'Searched {{count}} pattern': 'Pesquisou {{count}} padrão',
  'Searched {{count}} patterns': 'Pesquisou {{count}} padrões',
  'Searching {{count}} pattern': 'Pesquisando {{count}} padrão',
  'Searching {{count}} patterns': 'Pesquisando {{count}} padrões',
  'Listed {{count}} directory': 'Listou {{count}} diretório',
  'Listed {{count}} directories': 'Listou {{count}} diretórios',
  'Listing {{count}} directory': 'Listando {{count}} diretório',
  'Listing {{count}} directories': 'Listando {{count}} diretórios',
  'Ran {{count}} command': 'Executou {{count}} comando',
  'Ran {{count}} commands': 'Executou {{count}} comandos',
  'Running {{count}} command': 'Executando {{count}} comando',
  'Running {{count}} commands': 'Executando {{count}} comandos',
  'Ran {{count}} agent': 'Executou {{count}} agente',
  'Ran {{count}} agents': 'Executou {{count}} agentes',
  'Running {{count}} agent': 'Executando {{count}} agente',
  'Running {{count}} agents': 'Executando {{count}} agentes',
  'Used {{count}} tool': 'Usou {{count}} ferramenta',
  'Used {{count}} tools': 'Usou {{count}} ferramentas',
  'Using {{count}} tool': 'Usando {{count}} ferramenta',
  'Using {{count}} tools': 'Usando {{count}} ferramentas',
  'Enter to select, ↑↓ to navigate, Esc to close':
    'Enter para selecionar, ↑↓ para navegar, Esc para fechar',
  'Esc to go back': 'Esc para voltar',
  'Enter to confirm, Esc to cancel': 'Enter para confirmar, Esc para cancelar',
  'Enter to select, ↑↓ to navigate, Esc to go back':
    'Enter para selecionar, ↑↓ para navegar, Esc para voltar',
  'Enter to submit, Esc to go back': 'Enter para enviar, Esc para voltar',
  'Invalid step: {{step}}': 'Etapa inválida: {{step}}',
  'No subagents found.': 'Nenhum subagente encontrado.',
  "Use '/agents create' to create your first subagent.":
    "Use '/agents create' para criar seu primeiro subagente.",
  '(built-in)': '(integrado)',
  '(overridden by project level agent)':
    '(substituído por agente de nível de projeto)',
  'Project Level ({{path}})': 'Nível de Projeto ({{path}})',
  'User Level ({{path}})': 'Nível de Usuário ({{path}})',
  'Built-in Agents': 'Agentes Integrados',
  'Extension Agents': 'Agentes de Extensão',
  'Using: {{count}} agents': 'Usando: {{count}} agentes',
  'View Agent': 'Ver Agente',
  'Edit Agent': 'Editar Agente',
  'Delete Agent': 'Excluir Agente',
  Back: 'Voltar',
  'No agent selected': 'Nenhum agente selecionado',
  'File Path: ': 'Caminho do Arquivo: ',
  'Tools: ': 'Ferramentas: ',
  'Color: ': 'Cor: ',
  'Description:': 'Descrição:',
  'System Prompt:': 'Prompt do Sistema:',
  'Open in editor': 'Abrir no editor',
  'Edit tools': 'Editar ferramentas',
  'Edit color': 'Editar cor',
  '✗ Error:': '✗ Erro:',
  'Are you sure you want to delete agent "{{name}}"?':
    'Tem certeza que deseja excluir o agente "{{name}}"?',

  // ============================================================================
  // Agents - Creation Wizard
  // ============================================================================
  'Project Level (.qwen/agents/)': 'Nível de Projeto (.qwen/agents/)',
  'User Level (~/.qwen/agents/)': 'Nível de Usuário (~/.qwen/agents/)',
  '✓ Subagent Created Successfully!': '✓ Subagente criado com sucesso!',
  'Subagent "{{name}}" has been saved to {{level}} level.':
    'O subagente "{{name}}" foi salvo no nível {{level}}.',
  'Name: ': 'Nome: ',
  'Location: ': 'Localização: ',
  '✗ Error saving subagent:': '✗ Erro ao salvar subagente:',
  'Warnings:': 'Avisos:',
  'Name "{{name}}" already exists at {{level}} level - will overwrite existing subagent':
    'O nome "{{name}}" já existe no nível {{level}} - o subagente existente será substituído',
  'Name "{{name}}" exists at user level - project level will take precedence':
    'O nome "{{name}}" existe no nível de usuário - o nível de projeto terá precedência',
  'Name "{{name}}" exists at project level - existing subagent will take precedence':
    'O nome "{{name}}" existe no nível de projeto - o subagente existente terá precedência',
  'Description is over {{length}} characters':
    'A descrição tem mais de {{length}} caracteres',
  'System prompt is over {{length}} characters':
    'O prompt do sistema tem mais de {{length}} caracteres',

  // ============================================================================
  // Agents - Creation Wizard Steps
  // ============================================================================
  'Step {{n}}: Choose Location': 'Etapa {{n}}: Escolher Localização',
  'Step {{n}}: Choose Generation Method':
    'Etapa {{n}}: Escolher Método de Geração',
  'Generate with Qwen Code (Recommended)': 'Gerar com Qwen Code (Recomendado)',
  'Manual Creation': 'Criação Manual',
  'Describe what this subagent should do and when it should be used. (Be comprehensive for best results)':
    'Descreva o que este subagente deve fazer e quando deve ser usado. (Seja abrangente para melhores resultados)',
  'e.g., Expert code reviewer that reviews code based on best practices...':
    'ex: Revisor de código especialista que revisa código com base em melhores práticas...',
  'Generating subagent configuration...':
    'Gerando configuração do subagente...',
  'Failed to generate subagent: {{error}}':
    'Falha ao gerar subagente: {{error}}',
  'Step {{n}}: Describe Your Subagent': 'Etapa {{n}}: Descreva Seu Subagente',
  'Step {{n}}: Enter Subagent Name': 'Etapa {{n}}: Digite o Nome do Subagente',
  'Step {{n}}: Enter System Prompt': 'Etapa {{n}}: Digite o Prompt do Sistema',
  'Step {{n}}: Enter Description': 'Etapa {{n}}: Digite a Descrição',

  // ============================================================================
  // Agents - Tool Selection
  // ============================================================================
  'Step {{n}}: Select Tools': 'Etapa {{n}}: Selecionar Ferramentas',
  'All Tools (Default)': 'Todas as Ferramentas (Padrão)',
  'All Tools': 'Todas as Ferramentas',
  'Read-only Tools': 'Ferramentas de Somente Leitura',
  'Read & Edit Tools': 'Ferramentas de Leitura e Edição',
  'Read & Edit & Execution Tools': 'Ferramentas de Leitura, Edição e Execução',
  'All tools selected, including MCP tools':
    'Todas as ferramentas selecionadas, incluindo MCP tools',
  'Selected tools:': 'Ferramentas selecionadas:',
  'Read-only tools:': 'Ferramentas de somente leitura:',
  'Edit tools:': 'Ferramentas de edição:',
  'Execution tools:': 'Ferramentas de execução:',
  'Step {{n}}: Choose Background Color': 'Etapa {{n}}: Escolher Cor de Fundo',
  'Step {{n}}: Confirm and Save': 'Etapa {{n}}: Confirmar e Salvar',

  // ============================================================================
  // Agents - Navigation & Instructions
  // ============================================================================
  'Esc to cancel': 'Esc para cancelar',
  'Press Enter to save, e to save and edit, Esc to go back':
    'Pressione Enter para salvar, e para salvar e editar, Esc para voltar',
  'Press Enter to continue, {{navigation}}Esc to {{action}}':
    'Pressione Enter para continuar, {{navigation}}Esc para {{action}}',
  cancel: 'cancelar',
  'go back': 'voltar',
  '↑↓ to navigate, ': '↑↓ para navegar, ',
  'Enter a clear, unique name for this subagent.':
    'Digite um nome claro e único para este subagente.',
  'e.g., Code Reviewer': 'ex: Revisor de Código',
  'Name cannot be empty.': 'O nome não pode estar vazio.',
  "Write the system prompt that defines this subagent's behavior. Be comprehensive for best results.":
    'Escreva o prompt do sistema que define o comportamento deste subagente. Seja abrangente para melhores resultados.',
  'e.g., You are an expert code reviewer...':
    'ex: Você é um revisor de código especialista...',
  'System prompt cannot be empty.': 'O prompt do sistema não pode estar vazio.',
  'Describe when and how this subagent should be used.':
    'Descreva quando e como este subagente deve ser usado.',
  'e.g., Reviews code for best practices and potential bugs.':
    'ex: Revisa o código em busca de melhores práticas e erros potenciais.',
  'Description cannot be empty.': 'A descrição não pode estar vazia.',
  'Failed to launch editor: {{error}}': 'Falha ao iniciar editor: {{error}}',
  'Failed to save and edit subagent: {{error}}':
    'Falha ao salvar e editar subagente: {{error}}',

  // ============================================================================
  // Commands - General (continued)
  // ============================================================================
  'View and edit Qwen Code settings': 'Ver e editar configurações do Qwen Code',
  Settings: 'Configurações',
  'To see changes, Qwen Code must be restarted. Press r to exit and apply changes now.':
    'Para ver as alterações, o Qwen Code deve ser reiniciado. Pressione r para sair e aplicar as alterações agora.',
  // ============================================================================
  // Settings Labels
  // ============================================================================
  'Vim Mode': 'Modo Vim',
  'Attribution: commit': 'Atribuição: commit',
  'Terminal Bell Notification': 'Notificação Sonora do Terminal',
  'Enable Usage Statistics': 'Ativar Estatísticas de Uso',
  Theme: 'Tema',
  'Preferred Editor': 'Editor Preferido',
  'Auto-connect to IDE': 'Conexão Automática com IDE',
  'Debug Keystroke Logging': 'Log de Depuração de Teclas',
  'Language: UI': 'Idioma: Interface',
  'Language: Model': 'Idioma: Modelo',
  'Output Format': 'Formato de Saída',
  'Hide Window Title': 'Ocultar Título da Janela',
  'Show Status in Title': 'Mostrar Status no Título',
  'Hide Tips': 'Ocultar Dicas',
  'Show Tool Call Arguments': 'Mostrar Argumentos das Chamadas de Ferramenta',
  'Show Line Numbers in Code': 'Mostrar Números de Linhas no Código',
  'Show Citations': 'Mostrar Citações',
  'Custom Witty Phrases': 'Frases de Efeito Personalizadas',
  'Show Welcome Back Dialog': 'Mostrar Diálogo de Bem-vindo de Volta',
  'Enable User Feedback': 'Ativar Feedback do Usuário',
  'How is Qwen doing this session? (optional)':
    'Como o Qwen está se saindo nesta sessão? (opcional)',
  Bad: 'Ruim',
  Fine: 'Bom',
  Good: 'Ótimo',
  Dismiss: 'Ignorar',
  'Screen Reader Mode': 'Modo de Leitor de Tela',
  'Max Session Turns': 'Máximo de Turnos da Sessão',
  'Skip Next Speaker Check': 'Pular Verificação do Próximo Falante',
  'Skip Loop Detection': 'Pular Detecção de Loop',
  'Skip Startup Context': 'Pular Contexto de Inicialização',
  'Enable OpenAI Logging': 'Ativar Log do OpenAI',
  'OpenAI Logging Directory': 'Diretório de Log do OpenAI',
  Timeout: 'Tempo Limite',
  'Max Retries': 'Máximo de Tentativas',
  'Load Memory From Include Directories':
    'Carregar Memória de Diretórios Incluídos',
  'Respect .gitignore': 'Respeitar .gitignore',
  'Respect .qwenignore': 'Respeitar .qwenignore',
  'Enable Recursive File Search': 'Ativar Pesquisa Recursiva de Arquivos',
  'Interactive Shell (PTY)': 'Shell Interativo (PTY)',
  'Show Color': 'Mostrar Cores',
  'Auto Accept': 'Aceitar Automaticamente',
  'Use Ripgrep': 'Usar Ripgrep',
  'Use Builtin Ripgrep': 'Usar Ripgrep Integrado',
  'Tool Output Truncation Threshold':
    'Limite de Truncamento de Saída de Ferramenta',
  'Tool Output Truncation Lines':
    'Linhas de Truncamento de Saída de Ferramenta',
  'Folder Trust': 'Confiança de Pasta',
  'Tool Schema Compliance': 'Conformidade de Tool Schema',
  Unset: 'Não definido',

  // Settings enum options
  'Auto (detect from system)': 'Automático (detectar do sistema)',
  'Auto (follow user input)': 'Automático (seguir entrada do usuário)',
  'Auto (detect terminal theme)': 'Automático (detectar tema do terminal)',
  Auto: 'Automático',
  Text: 'Texto',
  JSON: 'JSON',
  Plan: 'Planejamento',
  'Ask permissions': 'Pedir permissão',
  'Auto Edit': 'Edição Automática',
  YOLO: 'YOLO',
  'toggle vim mode on/off': 'alternar modo vim ligado/desligado',
  'Show model-specific usage statistics.':
    'Mostrar estatísticas de uso específicas do modelo.',
  'Show tool-specific usage statistics.':
    'Mostrar estatísticas de uso específicas da ferramenta.',
  'Show daily token usage statistics.':
    'Mostrar estatísticas diárias de uso de tokens.',
  'Show monthly token usage statistics.':
    'Mostrar estatísticas mensais de uso de tokens.',
  'Export token usage statistics to CSV or JSON.':
    'Exportar estatísticas de uso de tokens para CSV ou JSON.',
  'No usage data.': 'Nenhum dado de uso.',
  '{{label}}: {{tokens}} tokens ({{requests}} requests)':
    '{{label}}: {{tokens}} tokens ({{requests}} requisições)',
  'Daily token usage for {{value}}': 'Uso diário de tokens para {{value}}',
  'Monthly token usage for {{value}}': 'Uso mensal de tokens para {{value}}',
  'Total: {{tokens}} tokens': 'Total: {{tokens}} tokens',
  'Requests: {{requests}}': 'Requisições: {{requests}}',
  'Breakdown:': 'Detalhamento:',
  'Input: {{tokens}}': 'Entrada: {{tokens}}',
  'Output: {{tokens}}': 'Saída: {{tokens}}',
  'Cached (included in Input): {{tokens}}':
    'Cache (incluído na entrada): {{tokens}}',
  'Thoughts: {{tokens}}': 'Raciocínio: {{tokens}}',
  'By model:': 'Por modelo:',
  'By auth type:': 'Por tipo de autenticação:',
  'By model/auth type:': 'Por modelo/tipo de autenticação:',
  'By source:': 'Por origem:',
  'Failed to load token usage stats: {{error}}':
    'Falha ao carregar estatísticas de uso de tokens: {{error}}',
  'Expected --format csv or --format json.':
    'Esperado --format csv ou --format json.',
  'Expected a file path after --output.':
    'Esperado um caminho de arquivo após --output.',
  'Unexpected argument: {{argument}}': 'Argumento inesperado: {{argument}}',
  'Usage: /stats export <daily|monthly> [YYYY-MM-DD|YYYY-MM] [--format csv|json] [--output path]':
    'Uso: /stats export <daily|monthly> [YYYY-MM-DD|YYYY-MM] [--format csv|json] [--output path]',
  'Token usage export path must be within the project working directory.':
    'O caminho de exportação do uso de tokens deve estar dentro do diretório de trabalho do projeto.',
  'Export target does not exist: {{path}}':
    'O destino da exportação não existe: {{path}}',
  'Cannot resolve export path within the working directory.':
    'Não foi possível resolver o caminho de exportação dentro do diretório de trabalho.',
  'Could not create a temporary export file.':
    'Não foi possível criar um arquivo temporário de exportação.',
  'Token usage exported to {{format}}: {{path}}':
    'Uso de tokens exportado para {{format}}: {{path}}',
  'Failed to export token usage stats: {{error}}':
    'Falha ao exportar estatísticas de uso de tokens: {{error}}',
  'Unclosed quote in arguments.': 'Aspas não fechadas nos argumentos.',
  'Note: generation timing (TTFT/TPS) belongs to generation metrics.':
    'Observação: o tempo de geração (TTFT/TPS) pertence às métricas de geração.',
  'exit the cli': 'sair da cli',
  'Manage workspace directories': 'Gerenciar diretórios do workspace',
  'Add directories to the workspace. Use comma to separate multiple paths':
    'Adicionar diretórios ao workspace. Use vírgula para separar vários caminhos',
  'Show all directories in the workspace':
    'Mostrar todos os diretórios no workspace',
  'set external editor preference': 'definir preferência de editor externo',
  'Select Editor': 'Selecionar Editor',
  'Editor Preference': 'Preferência de Editor',
  'These editors are currently supported. Please note that some editors cannot be used in sandbox mode.':
    'Estes editores são suportados atualmente. Note que alguns editores não podem ser usados no modo sandbox.',
  'Your preferred editor is:': 'Seu editor preferido é:',
  'Manage extensions': 'Gerenciar extensões',
  'Manage installed extensions': 'Gerenciar extensões instaladas',
  'Disable an extension': 'Desativar uma extensão',
  'Enable an extension': 'Ativar uma extensão',
  'Install an extension from a git repo or local path':
    'Instalar uma extensão de um repositório git ou caminho local',
  'Uninstall an extension': 'Desinstalar uma extensão',
  'No extensions installed.': 'Nenhuma extensão instalada.',
  'Extension "{{name}}" not found.': 'Extensão "{{name}}" não encontrada.',
  'No extensions to update.': 'Nenhuma extensão para atualizar.',
  'Usage: /extensions install <source>': 'Uso: /extensions install <fonte>',
  'Installing extension from "{{source}}"...':
    'Instalando extensão de "{{source}}"...',
  'Extension "{{name}}" installed successfully.':
    'Extensão "{{name}}" instalada com sucesso.',
  'Failed to install extension from "{{source}}": {{error}}':
    'Falha ao instalar extensão de "{{source}}": {{error}}',
  'Do you want to continue? [Y/n]: ': 'Você deseja continuar? [Y/n]: ',
  'Do you want to continue?': 'Você deseja continuar?',
  'Installing extension "{{name}}".': 'Instalando extensão "{{name}}".',
  '**Extensions may introduce unexpected behavior. Ensure you have investigated the extension source and trust the author.**':
    '**As extensões podem introduzir comportamentos inesperados. Certifique-se de ter investigado a fonte da extensão e confie no autor.**',
  'This extension will run the following MCP servers:':
    'Esta extensão executará os seguintes MCP servers:',
  local: 'local',
  remote: 'remoto',
  'This extension will add the following commands: {{commands}}.':
    'Esta extensão adicionará os seguintes comandos: {{commands}}.',
  'This extension will append info to your QWEN.md context using {{fileName}}':
    'Esta extensão anexará informações ao seu contexto QWEN.md usando {{fileName}}',
  'This extension will install the following skills:':
    'Esta extensão instalará as seguintes habilidades:',
  'This extension will install the following subagents:':
    'Esta extensão instalará os seguintes subagentes:',
  'This extension will install the following workflows (JavaScript scripts that can start subagents):':
    'Esta extensão instalará os seguintes fluxos de trabalho (scripts JavaScript que podem iniciar subagentes):',
  'These workflow scripts changed since the installed version: {{names}}.':
    'Estes scripts de fluxo de trabalho mudaram desde a versão instalada: {{names}}.',
  'Installation cancelled for "{{name}}".':
    'Instalação cancelada para "{{name}}".',
  'You are installing an extension from {{originSource}}. Some features may not work perfectly with Qwen Code.':
    'Você está instalando uma extensão de {{originSource}}. Alguns recursos podem não funcionar perfeitamente com o Qwen Code.',
  '--ref and --auto-update are not applicable for marketplace extensions.':
    '--ref e --auto-update não são aplicáveis para extensões de marketplace.',
  'Extension "{{name}}" installed successfully and enabled.':
    'Extensão "{{name}}" instalada com sucesso e ativada.',
  'The github URL, local path, or marketplace source (marketplace-url:plugin-name) of the extension to install.':
    'A URL do github, caminho local ou fonte do marketplace (marketplace-url:plugin-name) da extensão para instalar.',
  'The git ref to install from.': 'A referência git para instalar.',
  'Enable auto-update for this extension.':
    'Ativar atualização automática para esta extensão.',
  'Enable pre-release versions for this extension.':
    'Ativar versões de pré-lançamento para esta extensão.',
  'Acknowledge the security risks of installing an extension and skip the confirmation prompt.':
    'Reconhecer os riscos de segurança de instalar uma extensão e pular o prompt de confirmação.',
  'The source argument must be provided.':
    'O argumento fonte deve ser fornecido.',
  'Extension "{{name}}" successfully uninstalled.':
    'Extensão "{{name}}" desinstalada com sucesso.',
  'Uninstalls an extension.': 'Desinstala uma extensão.',
  'The name or source path of the extension to uninstall.':
    'O nome ou caminho da fonte da extensão para desinstalar.',
  'Please include the name of the extension to uninstall as a positional argument.':
    'Inclua o nome da extensão para desinstalar como um argumento posicional.',
  'Enables an extension.': 'Ativa uma extensão.',
  'The name of the extension to enable.': 'O nome da extensão para ativar.',
  'The scope to enable the extension in. If not set, will be enabled in all scopes.':
    'O escopo para ativar a extensão. Se não definido, será ativada em todos os escopos.',
  'Extension "{{name}}" successfully enabled for scope "{{scope}}".':
    'Extensão "{{name}}" ativada com sucesso para o escopo "{{scope}}".',
  'Extension "{{name}}" successfully enabled in all scopes.':
    'Extensão "{{name}}" ativada com sucesso em todos os escopos.',
  'Invalid scope: {{scope}}. Please use one of {{scopes}}.':
    'Escopo inválido: {{scope}}. Use um de {{scopes}}.',
  'Disables an extension.': 'Desativa uma extensão.',
  'The name of the extension to disable.': 'O nome da extensão para desativar.',
  'The scope to disable the extension in.':
    'O escopo para desativar a extensão.',
  'Extension "{{name}}" successfully disabled for scope "{{scope}}".':
    'Extensão "{{name}}" desativada com sucesso para o escopo "{{scope}}".',
  'Extension "{{name}}" successfully updated: {{oldVersion}} → {{newVersion}}.':
    'Extensão "{{name}}" atualizada com sucesso: {{oldVersion}} → {{newVersion}}.',
  'Unable to install extension "{{name}}" due to missing install metadata':
    'Não foi possível instalar a extensão "{{name}}" devido à falta de metadados de instalação',
  'Extension "{{name}}" is already up to date.':
    'A extensão "{{name}}" já está atualizada.',
  'Updates all extensions or a named extension to the latest version.':
    'Atualiza todas as extensões ou uma extensão nomeada para a última versão.',
  'Update all extensions.': 'Atualizar todas as extensões.',
  'Either an extension name or --all must be provided':
    'Um nome de extensão ou --all deve ser fornecido',
  'Lists installed extensions.': 'Lista as extensões instaladas.',
  'Link extension failed to install.': 'Falha ao instalar link da extensão.',
  'Extension "{{name}}" linked successfully and enabled.':
    'Extensão "{{name}}" vinculada com sucesso e ativada.',
  'Links an extension from a local path. Updates made to the local path will always be reflected.':
    'Vincula uma extensão de um caminho local. Atualizações feitas no caminho local sempre serão refletidas.',
  'The name of the extension to link.': 'O nome da extensão para vincular.',
  'Set a specific setting for an extension.':
    'Define uma configuração específica para uma extensão.',
  'Name of the extension to configure.': 'Nome da extensão para configurar.',
  'The setting to configure (name or env var).':
    'A configuração para configurar (nome ou var env).',
  'The scope to set the setting in.': 'O escopo para definir a configuração.',
  'List all settings for an extension.':
    'Listar todas as configurações de uma extensão.',
  'Name of the extension.': 'Nome da extensão.',
  'Extension "{{name}}" has no settings to configure.':
    'A extensão "{{name}}" não tem configurações para configurar.',
  'Settings for "{{name}}":': 'Configurações para "{{name}}":',
  '(user)': '(usuário)',
  '[not set]': '[não definido]',
  '[value stored in keychain]': '[valor armazenado no chaveiro]',
  'Value:': 'Valor:',
  'Manage extension settings.': 'Gerenciar configurações de extensão.',
  'You need to specify a command (set or list).':
    'Você precisa especificar um comando (set ou list).',

  // ============================================================================
  // Plugin Choice / Marketplace
  // ============================================================================
  'No plugins available in this marketplace.':
    'Nenhum plugin disponível neste marketplace.',
  'Select a plugin to install from marketplace "{{name}}":':
    'Selecione um plugin para instalar do marketplace "{{name}}":',
  'Plugin selection cancelled.': 'Seleção de plugin cancelada.',
  'Select a plugin from "{{name}}"': 'Selecione um plugin de "{{name}}"',
  'Use ↑↓ or j/k to navigate, Enter to select, Escape to cancel':
    'Use ↑↓ ou j/k para navegar, Enter para selecionar, Escape para cancelar',
  '{{count}} more above': '{{count}} mais acima',
  '{{count}} more below': '{{count}} mais abaixo',
  'manage IDE integration': 'gerenciar integração com IDE',
  'check status of IDE integration': 'verificar status da integração com IDE',
  'install required IDE companion for {{ideName}}':
    'instalar companion IDE necessário para {{ideName}}',
  'enable IDE integration': 'ativar integração com IDE',
  'disable IDE integration': 'desativar integração com IDE',
  'IDE integration is not supported in your current environment. To use this feature, run Qwen Code in one of these supported IDEs: VS Code or VS Code forks.':
    'A integração com IDE não é suportada no seu ambiente atual. Para usar este recurso, execute o Qwen Code em um destes IDEs suportados: VS Code ou forks do VS Code.',
  'Set up GitHub Actions': 'Configurar GitHub Actions',
  'Configure terminal keybindings for multiline input (VS Code, Cursor, Windsurf, Trae)':
    'Configurar atalhos de terminal para entrada multilinhas (VS Code, Cursor, Windsurf, Trae)',
  'Please restart your terminal for the changes to take effect.':
    'Reinicie seu terminal para que as alterações tenham efeito.',
  'Failed to configure terminal: {{error}}':
    'Falha ao configurar terminal: {{error}}',
  'Could not determine {{terminalName}} config path on Windows: APPDATA environment variable is not set.':
    'Não foi possível determinar o caminho de configuração de {{terminalName}} no Windows: variável de ambiente APPDATA não está definida.',
  '{{terminalName}} keybindings.json exists but is not a valid JSON array. Please fix the file manually or delete it to allow automatic configuration.':
    '{{terminalName}} keybindings.json existe mas não é um array JSON válido. Corrija o arquivo manualmente ou exclua-o para permitir a configuração automática.',
  'File: {{file}}': 'Arquivo: {{file}}',
  'Failed to parse {{terminalName}} keybindings.json. The file contains invalid JSON. Please fix the file manually or delete it to allow automatic configuration.':
    'Falha ao analisar {{terminalName}} keybindings.json. O arquivo contém JSON inválido. Corrija o arquivo manualmente ou exclua-o para permitir a configuração automática.',
  'Error: {{error}}': 'Erro: {{error}}',
  'Shift+Enter binding already exists': 'Atalho Shift+Enter já existe',
  'Ctrl+Enter binding already exists': 'Atalho Ctrl+Enter já existe',
  'Existing keybindings detected. Will not modify to avoid conflicts.':
    'Atalhos existentes detectados. Não serão modificados para evitar conflitos.',
  'Please check and modify manually if needed: {{file}}':
    'Verifique e modifique manualmente se necessário: {{file}}',
  'Added Shift+Enter and Ctrl+Enter keybindings to {{terminalName}}.':
    'Adicionados atalhos Shift+Enter e Ctrl+Enter para {{terminalName}}.',
  'Modified: {{file}}': 'Modificado: {{file}}',
  '{{terminalName}} keybindings already configured.':
    'Atalhos de {{terminalName}} já configurados.',
  'Failed to configure {{terminalName}}.':
    'Falha ao configurar {{terminalName}}.',
  'Your terminal is already configured for an optimal experience with multiline input (Shift+Enter and Ctrl+Enter).':
    'Seu terminal já está configurado para uma experiência ideal com entrada multilinhas (Shift+Enter e Ctrl+Enter).',
  // ============================================================================
  // Commands - Hooks
  // ============================================================================
  'Manage Qwen Code hooks': 'Gerenciar hooks do Qwen Code',
  'List all configured hooks': 'Listar todos os hooks configurados',
  // Hooks - Dialog
  Hooks: 'Hooks',
  'Loading hooks...': 'Carregando hooks...',
  'Error loading hooks:': 'Erro ao carregar hooks:',
  'Press Escape to close': 'Pressione Escape para fechar',
  'Press Escape, Ctrl+C, or Ctrl+D to cancel':
    'Pressione Escape, Ctrl+C ou Ctrl+D para cancelar',
  'Press Space, Enter, or Escape to dismiss':
    'Pressione Space, Enter ou Escape para dispensar',
  'No hook selected': 'Nenhum hook selecionado',
  // Hooks - List Step
  'No hook events found.': 'Nenhum evento de hook encontrado.',
  '{{count}} hook configured': '{{count}} hook configurado',
  '{{count}} hooks configured': '{{count}} hooks configurados',
  'This menu is read-only. To add or modify hooks, edit settings.json directly or ask Qwen Code.':
    'Este menu é somente leitura. Para adicionar ou modificar hooks, edite settings.json diretamente ou pergunte ao Qwen Code.',
  'Reopen this menu to reload hook definitions.':
    'Reabra este menu para recarregar as definições dos hooks.',
  'Hook controls and HTTP security settings require a restart.':
    'Os controles dos hooks e as configurações de segurança HTTP exigem uma reinicialização.',
  'Failed to reload hook definitions: {{error}}':
    'Falha ao recarregar as definições dos hooks: {{error}}',
  'Enter to select · Esc to cancel':
    'Enter para selecionar · Esc para cancelar',
  // Hooks - Detail Step
  'Exit codes:': 'Códigos de saída:',
  'Configured hooks:': 'Hooks configurados:',
  'No hooks configured for this event.':
    'Nenhum hook configurado para este evento.',
  'To add hooks, edit settings.json directly or ask Qwen.':
    'Para adicionar hooks, edite settings.json diretamente ou pergunte ao Qwen.',
  'Enter to select · Esc to go back': 'Enter para selecionar · Esc para voltar',
  // Hooks - Config Detail Step
  'Hook details': 'Detalhes do Hook',
  'Event:': 'Evento:',
  'Extension:': 'Extensão:',
  'Desc:': 'Descrição:',
  'No hook config selected': 'Nenhuma configuração de hook selecionada',
  'To modify or remove this hook, edit settings.json directly or ask Qwen to help.':
    'Para modificar ou remover este hook, edite settings.json diretamente ou pergunte ao Qwen.',
  // Hooks - Disabled Step
  'Hook Configuration - Disabled': 'Configuração de Hook - Desativado',
  'All hooks are currently disabled. You have {{count}} that are not running.':
    'Todos os hooks estão desativados. Você tem {{count}} que não estão em execução.',
  '{{count}} configured hook': '{{count}} hook configurado',
  '{{count}} configured hooks': '{{count}} hooks configurados',
  'When hooks are disabled:': 'Quando os hooks estão desativados:',
  'No hook commands will execute': 'Nenhum comando de hook será executado',
  'StatusLine will not be displayed': 'StatusLine não será exibido',
  'Tool operations will proceed without hook validation':
    'As operações de ferramentas prosseguirão sem validação de hook',
  'To re-enable hooks, remove "disableAllHooks" from settings.json or ask Qwen Code.':
    'Para reativar os hooks, remova "disableAllHooks" do settings.json ou pergunte ao Qwen Code.',
  // Hooks - Source
  Project: 'Projeto',
  User: 'Usuário',
  Skill: 'Habilidade',
  System: 'Sistema',
  Extension: 'Extensão',
  'Local Settings': 'Configurações Locais',
  'User Settings': 'Configurações do Usuário',
  'System Settings': 'Configurações do Sistema',
  Extensions: 'Extensões',
  'Session (temporary)': 'Sessão (temporário)',
  // Hooks - Event Descriptions (short)
  'Before tool execution': 'Antes da execução da ferramenta',
  'After tool execution': 'Após a execução da ferramenta',
  'After tool execution fails': 'Após a falha da execução da ferramenta',
  'When notifications are sent': 'Quando notificações são enviadas',
  'When the user submits a prompt': 'Quando o usuário envia um prompt',
  'When a slash command expands into a prompt':
    'Quando um comando slash se expande em um prompt',
  'When a new session is started': 'Quando uma nova sessão é iniciada',
  'Right before Qwen Code concludes its response':
    'Logo antes do Qwen Code concluir sua resposta',
  'When a subagent (Agent tool call) is started':
    'Quando um subagente (chamada de ferramenta Agent) é iniciado',
  'Right before a subagent concludes its response':
    'Logo antes de um subagente concluir sua resposta',
  'Before conversation compaction': 'Antes da compactação da conversa',
  'When a session is ending': 'Quando uma sessão está terminando',
  'When a permission dialog is displayed':
    'Quando um diálogo de permissão é exibido',
  'When a new todo item is created': 'Quando um novo item todo é criado',
  'When a todo item is marked as completed':
    'Quando um item todo é marcado como concluído',
  // Hooks - Event Descriptions (detailed)
  'Input to command is JSON of tool call arguments.':
    'A entrada para o comando é JSON dos argumentos da chamada da ferramenta.',
  'Input to command is JSON with fields "inputs" (tool call arguments) and "response" (tool call response).':
    'A entrada para o comando é JSON com campos "inputs" (argumentos da chamada da ferramenta) e "response" (resposta da chamada da ferramenta).',
  'Input to command is JSON with tool_name, tool_input, tool_use_id, error, error_type, is_interrupt, and is_timeout.':
    'A entrada para o comando é JSON com tool_name, tool_input, tool_use_id, error, error_type, is_interrupt e is_timeout.',
  'Input to command is JSON with notification message and type.':
    'A entrada para o comando é JSON com mensagem e tipo de notificação.',
  'Input to command is JSON with "prompt" (the current model-bound prompt) and optional "submitted_prompt" (the text projection captured at a supported submission boundary).':
    'A entrada para o comando é JSON com "prompt" (o prompt atual vinculado ao modelo) e o campo opcional "submitted_prompt" (a projeção de texto capturada em um ponto de envio compatível).',
  'Input to command is JSON with command_name, command_args, and expanded prompt text.':
    'A entrada para o comando é JSON com command_name, command_args e o texto do prompt expandido.',
  'Input to command is JSON with session start source.':
    'A entrada para o comando é JSON com a fonte de início da sessão.',
  'Input to command is JSON with session end reason.':
    'A entrada para o comando é JSON com o motivo do fim da sessão.',
  'Input to command is JSON with agent_id and agent_type.':
    'A entrada para o comando é JSON com agent_id e agent_type.',
  'Input to command is JSON with agent_id, agent_type, and agent_transcript_path.':
    'A entrada para o comando é JSON com agent_id, agent_type e agent_transcript_path.',
  'Input to command is JSON with compaction details.':
    'A entrada para o comando é JSON com detalhes da compactação.',
  'Input to command is JSON with tool_name, tool_input, and tool_use_id. Output JSON with hookSpecificOutput containing decision to allow or deny.':
    'A entrada para o comando é JSON com tool_name, tool_input e tool_use_id. Saída é JSON com hookSpecificOutput contendo decisão de permitir ou negar.',
  'Input to command is JSON with todo_id, todo_content, todo_status, all_todos, and phase. In validation, output JSON with decision (allow/block/deny) and reason. In postWrite, block/deny is ignored.':
    'A entrada para o comando é JSON com todo_id, todo_content, todo_status, all_todos e phase. Em validation, saída é JSON com decision (allow/block/deny) e reason. Em postWrite, block/deny é ignorado.',
  'Input to command is JSON with todo_id, todo_content, previous_status, all_todos, and phase. In validation, output JSON with decision (allow/block/deny) and reason. In postWrite, block/deny is ignored.':
    'A entrada para o comando é JSON com todo_id, todo_content, previous_status, all_todos e phase. Em validation, saída é JSON com decision (allow/block/deny) e reason. Em postWrite, block/deny é ignorado.',
  // Hooks - Exit Code Descriptions
  'stdout/stderr not shown': 'stdout/stderr não exibido',
  'show stderr to model and continue conversation':
    'mostrar stderr ao modelo e continuar conversa',
  'show stderr to user only': 'mostrar stderr apenas ao usuário',
  'stdout shown in transcript mode (ctrl+o)':
    'stdout exibido no modo transcrição (ctrl+o)',
  'show stderr to model immediately': 'mostrar stderr ao modelo imediatamente',
  'show stderr to user only but continue with tool call':
    'mostrar stderr apenas ao usuário mas continuar com chamada de ferramenta',
  'block processing, erase original prompt, and show stderr to user only':
    'bloquear processamento, apagar prompt original e mostrar stderr apenas ao usuário',
  'block expanded prompt submission and show stderr to user only':
    'bloquear envio do prompt expandido e mostrar stderr apenas ao usuário',
  'stdout shown to Qwen': 'stdout mostrado ao Qwen',
  'show stderr to user only (blocking errors ignored)':
    'mostrar stderr apenas ao usuário (erros de bloqueio ignorados)',
  'command completes successfully': 'comando concluído com sucesso',
  'stdout shown to subagent': 'stdout mostrado ao subagente',
  'show stderr to subagent and continue having it run':
    'mostrar stderr ao subagente e continuar executando',
  'stdout appended as custom compact instructions':
    'stdout anexado como instruções de compactação personalizadas',
  'block compaction': 'bloquear compactação',
  'show stderr to user only but continue with compaction':
    'mostrar stderr apenas ao usuário mas continuar com compactação',
  'use hook decision if provided': 'usar decisão do hook se fornecida',
  'allow todo creation': 'permitir criação de todo',
  'block todo creation and show reason to model':
    'bloquear criação de todo e mostrar motivo ao modelo',
  'allow todo completion': 'permitir conclusão de todo',
  'block todo completion and show reason to model':
    'bloquear conclusão de todo e mostrar motivo ao modelo',
  // Hooks - Messages
  'Config not loaded.': 'Configuração não carregada.',
  'Hooks are not enabled. Enable hooks in settings to use this feature.':
    'Hooks não estão ativados. Ative hooks nas configurações para usar este recurso.',
  // ============================================================================
  // Commands - Session Export
  // ============================================================================
  'Export current session message history to a file':
    'Exportar o histórico de mensagens da sessão atual para um arquivo',
  'Export session to HTML format': 'Exportar a sessão para o formato HTML',
  'Export session to JSON format': 'Exportar a sessão para o formato JSON',
  'Export session to JSONL format (one message per line)':
    'Exportar a sessão para o formato JSONL (uma mensagem por linha)',
  'Export session to markdown format':
    'Exportar a sessão para o formato Markdown',

  // ============================================================================
  // Commands - Insights
  // ============================================================================
  'generate personalized programming insights from your chat history':
    'Gerar insights personalizados de programação a partir do seu histórico de chat',

  // ============================================================================
  // Commands - Session History
  // ============================================================================
  'Resume a previous session': 'Retomar uma sessão anterior',
  'Fork the current conversation into a new session':
    'Ramificar a conversa atual em uma nova sessão',
  'Spawn a background agent that inherits the full conversation':
    'Iniciar um agente em segundo plano que herda toda a conversa',
  'Please provide a directive. Usage: /fork <directive>':
    'Forneça uma diretiva. Uso: /fork <diretiva>',
  'Cannot fork while a response or tool call is in progress. Wait for it to finish or resolve the pending tool call.':
    'Não é possível criar um fork enquanto uma resposta ou chamada de ferramenta está em andamento. Aguarde a conclusão ou resolva a chamada de ferramenta pendente.',
  'Cannot fork before the first conversation turn.':
    'Não é possível criar um fork antes da primeira rodada da conversa.',
  'The agent tool is unavailable; cannot fork.':
    'A ferramenta de agente está indisponível; não é possível criar um fork.',
  'Failed to launch fork: {{error}}': 'Falha ao iniciar o fork: {{error}}',
  'User launched a background fork via /fork: {{directive}}':
    'O usuário iniciou um fork em segundo plano via /fork: {{directive}}',
  'Forked into a background agent. It inherits this conversation and runs without blocking — track it in the background tasks panel; it reports back when done.':
    'Fork criado em um agente em segundo plano. Ele herda esta conversa e roda sem bloquear — acompanhe no painel de tarefas em segundo plano; ele informará quando terminar.',
  'Cannot branch while a response or tool call is in progress. Wait for it to finish or resolve the pending tool call.':
    'Não é possível ramificar enquanto uma resposta ou chamada de ferramenta está em andamento. Aguarde a conclusão ou resolva a chamada de ferramenta pendente.',
  'No conversation to branch.': 'Não há conversa para ramificar.',
  'Restore a tool call. This will reset the conversation and file history to the state it was in when the tool call was suggested':
    'Restaurar uma chamada de ferramenta. Isso redefinirá o histórico da conversa e dos arquivos para o estado em que a chamada da ferramenta foi sugerida',
  'Could not detect terminal type. Supported terminals: VS Code, Cursor, Windsurf, and Trae.':
    'Não foi possível detectar o tipo de terminal. Terminais suportados: VS Code, Cursor, Windsurf e Trae.',
  'Terminal "{{terminal}}" is not supported yet.':
    'O terminal "{{terminal}}" ainda não é suportado.',

  // ============================================================================
  // Commands - Language
  // ============================================================================
  'Invalid language. Available: {{options}}':
    'Idioma inválido. Disponíveis: {{options}}',
  'Language subcommands do not accept additional arguments.':
    'Subcomandos de idioma não aceitam argumentos adicionais.',
  'Current UI language: {{lang}}': 'Idioma atual da interface: {{lang}}',
  'Current LLM output language: {{lang}}':
    'Idioma atual da saída do LLM: {{lang}}',
  'Set UI language': 'Definir idioma da interface',
  'Set LLM output language': 'Definir idioma de saída do LLM',
  'Usage: /language ui [{{options}}]': 'Uso: /language ui [{{options}}]',
  'Usage: /language output <language>': 'Uso: /language output <idioma>',
  'Example: /language output 中文': 'Exemplo: /language output Português',
  'Example: /language output English': 'Exemplo: /language output Inglês',
  'Example: /language output 日本語': 'Exemplo: /language output Japonês',
  'UI language changed to {{lang}}':
    'Idioma da interface alterado para {{lang}}',
  'LLM output language set to {{lang}}':
    'Idioma de saída do LLM definido para {{lang}}',
  'Please restart the application for the changes to take effect.':
    'Reinicie o aplicativo para que as alterações tenham efeito.',
  'Failed to generate LLM output language rule file: {{error}}':
    'Falha ao gerar arquivo de regra de idioma de saída do LLM: {{error}}',
  'Invalid command. Available subcommands:':
    'Comando inválido. Subcomandos disponíveis:',
  'Available subcommands:': 'Subcomandos disponíveis:',
  'To request additional UI language packs, please open an issue on GitHub.':
    'Para solicitar pacotes de idiomas de interface adicionais, abra um problema no GitHub.',
  'Available options:': 'Opções disponíveis:',
  'Set UI language to {{name}}': 'Definir idioma da interface para {{name}}',

  // ============================================================================
  // Commands - Approval Mode
  // ============================================================================
  'Tool Approval Mode': 'Modo de Aprovação de Ferramenta',
  'Analyze only, do not modify files or execute commands':
    'Apenas analisar, não modificar arquivos nem executar comandos',
  'Require approval for file edits or shell commands':
    'Exigir aprovação para edições de arquivos ou comandos shell',
  'Automatically approve file edits':
    'Aprovar automaticamente edições de arquivos',
  'Use classifier to automatically approve safe tool calls':
    'Usar o classificador para aprovar automaticamente chamadas seguras de ferramentas',
  'Automatically approve all tools':
    'Aprovar automaticamente todas as ferramentas',
  'Workspace approval mode exists and takes priority. User-level change will have no effect.':
    'O modo de aprovação do workspace existe e tem prioridade. A alteração no nível do usuário não terá efeito.',
  'Apply To': 'Aplicar A',
  'Workspace Settings': 'Configurações do Workspace',
  'Open auto-memory folder': 'Abrir pasta de memória automática',
  'Auto-memory: {{status}}': 'Memória automática: {{status}}',
  'Auto-dream: {{status}} · {{lastDream}} · /dream to run':
    'Consolidação automática: {{status}} · {{lastDream}} · /dream para executar',
  'Auto-skill: {{status}}': 'Habilidade automática: {{status}}',
  never: 'nunca',
  on: 'ativado',
  off: 'desativado',
  'Remove matching entries from managed auto-memory.':
    'Remover entradas correspondentes da memória automática gerenciada.',
  'Usage: /forget <memory text to remove>':
    'Uso: /forget <texto de memória a remover>',
  'No managed auto-memory entries matched: {{query}}':
    'Nenhuma entrada de memória automática gerenciada correspondeu: {{query}}',
  'Consolidate managed auto-memory topic files.':
    'Consolidar arquivos de tópicos de memória automática gerenciada.',
  'Could not retrieve tool registry.':
    'Não foi possível recuperar o registro de ferramentas.',
  "Successfully authenticated and refreshed tools for '{{name}}'.":
    "Autenticado com sucesso e ferramentas atualizadas para '{{name}}'.",
  "Re-discovering tools from '{{name}}'...":
    "Redescobrindo ferramentas de '{{name}}'...",
  "Discovered {{count}} tool(s) from '{{name}}'.":
    "{{count}} ferramenta(s) descoberta(s) de '{{name}}'.",
  'Authentication complete. Returning to server details...':
    'Autenticação concluída. Retornando aos detalhes do servidor...',
  'Authentication successful.': 'Autenticação bem-sucedida.',
  // =========================================================
  // Commands - Summary
  // ============================================================================
  'Generate a project summary and save it to .qwen/PROJECT_SUMMARY.md':
    'Gerar um resumo do projeto e salvá-lo em .qwen/PROJECT_SUMMARY.md',
  'No chat client available to generate summary.':
    'Nenhum cliente de chat disponível para gerar o resumo.',
  'Already generating summary, wait for previous request to complete':
    'Já gerando resumo, aguarde a conclusão da solicitação anterior',
  'No conversation found to summarize.':
    'Nenhuma conversa encontrada para resumir.',
  'Summary path already exists and is not a generated summary: {{path}}':
    'O caminho do resumo já existe e não é um resumo gerado: {{path}}',
  'Summary path must be within the project root.':
    'O caminho do resumo deve estar dentro da raiz do projeto.',
  'Summary path resolves to an existing directory: {{path}}':
    'O caminho do resumo resolve para um diretório existente: {{path}}',
  'Summary path ends with a separator but is an existing file: {{path}}':
    'O caminho do resumo termina com um separador, mas é um arquivo existente: {{path}}',
  'Failed to generate project context summary: {{error}}':
    'Falha ao gerar resumo do contexto do projeto: {{error}}',
  'Saved project summary to {{filePathForDisplay}}.':
    'Resumo do projeto salvo em {{filePathForDisplay}}.',
  'Saving project summary...': 'Salvando resumo do projeto...',
  'Generating project summary...': 'Gerando resumo do projeto...',
  'Processing summary...': 'Processando resumo...',
  'Project summary generated and saved successfully!':
    'Resumo do projeto gerado e salvo com sucesso!',
  'Saved to: {{filePath}}': 'Salvo em: {{filePath}}',
  'Stopped because': 'Parado porque',
  'Failed to generate summary - no text content received from LLM response':
    'Falha ao gerar resumo - nenhum conteúdo de texto recebido da resposta do LLM',

  // ============================================================================
  // Commands - Model
  // ============================================================================
  'Switch the model for this session (--fast for suggestion model, [model-id] to switch immediately).':
    'Trocar o modelo para esta sessão (--fast para modelo de sugestões)',
  'Set a lighter model for prompt suggestions and speculative execution':
    'Definir modelo mais leve para sugestões de prompt e execução especulativa',
  'Content generator configuration not available.':
    'Configuração do gerador de conteúdo não disponível.',
  'Authentication type not available.': 'Tipo de autenticação não disponível.',
  'No models available for the current authentication type ({{authType}}).':
    'Nenhum modelo disponível para o tipo de autenticação atual ({{authType}}).',
  // Needs translation
  ' (not in model registry)': ' (not in model registry)',

  // ============================================================================
  // Commands - Clear
  // ============================================================================
  'Starting a new session, resetting chat, and clearing terminal.':
    'Iniciando uma nova sessão, resetando o chat e limpando o terminal.',
  'Starting a new session and clearing.':
    'Iniciando uma nova sessão e limpando.',

  // ============================================================================
  // Commands - Compress
  // ============================================================================
  'Already compressing, wait for previous request to complete':
    'Já comprimindo, aguarde a conclusão da solicitação anterior',
  'Failed to compress chat history.': 'Falha ao comprimir histórico do chat.',
  'Failed to compress chat history: {{error}}':
    'Falha ao comprimir histórico do chat: {{error}}',
  'Compressing chat history': 'Comprimindo histórico do chat',
  'Chat history compressed from {{originalTokens}} to {{newTokens}} tokens.':
    'Histórico do chat comprimido de {{originalTokens}} para {{newTokens}} tokens.',
  'Compression was not beneficial for this history size.':
    'A compressão não foi benéfica para este tamanho de histórico.',
  'Chat history compression did not reduce size. This may indicate issues with the compression prompt.':
    'A compressão do histórico do chat não reduziu o tamanho. Isso pode indicar problemas com o prompt de compressão.',
  'Could not compress chat history due to a token counting error.':
    'Não foi possível comprimir o histórico do chat devido a um erro de contagem de tokens.',
  'Could not compress chat history because the compression summary was empty.':
    'Não foi possível comprimir o histórico do chat porque o resumo da compressão estava vazio.',
  'Could not compress chat history because the compression summary was truncated.':
    'Não foi possível comprimir o histórico do chat porque o resumo da compressão foi truncado.',
  'Could not compress chat history due to an API error.':
    'Não foi possível comprimir o histórico do chat devido a um erro da API.',
  // ============================================================================
  // Commands - Directory
  // ============================================================================
  'Configuration is not available.': 'A configuração não está disponível.',
  'Please provide at least one path to add.':
    'Forneça pelo menos um caminho para adicionar.',
  'The /directory add command is not supported in restrictive sandbox profiles. Please use --include-directories when starting the session instead.':
    'O comando /directory add não é suportado em perfis de sandbox restritivos. Use --include-directories ao iniciar a sessão.',
  "Error adding '{{path}}': {{error}}":
    "Erro ao adicionar '{{path}}': {{error}}",
  'Successfully added QWEN.md files from the following directories if there are:\n- {{directories}}':
    'Arquivos QWEN.md adicionados com sucesso dos seguintes diretórios, se houverem:\n- {{directories}}',
  'Error refreshing memory: {{error}}': 'Erro ao atualizar memória: {{error}}',
  'Successfully added directories:\n- {{directories}}':
    'Diretórios adicionados com sucesso:\n- {{directories}}',
  'Current workspace directories:\n{{directories}}':
    'Diretórios atuais do workspace:\n{{directories}}',

  // ============================================================================
  // Commands - Docs
  // ============================================================================
  'Please open the following URL in your browser to view the documentation:\n{{url}}':
    'Abra a seguinte URL no seu navegador para ver a documentação:\n{{url}}',
  'Opening documentation in your browser: {{url}}':
    'Abrindo documentação no seu navegador: {{url}}',

  // ============================================================================
  // Dialogs - Tool Confirmation
  // ============================================================================
  'Do you want to proceed?': 'Você deseja prosseguir?',
  'Yes, allow once': 'Sim, permitir uma vez',
  'Allow always': 'Permitir sempre',
  Yes: 'Sim',
  No: 'Não',
  'No (esc)': 'Não (esc)',
  // MCP Management - Core translations
  'Manage MCP servers': 'Gerenciar MCP servers',
  'Server Detail': 'Detalhes do servidor',
  Tools: 'Ferramentas',
  'Tool Detail': 'Detalhes da ferramenta',
  'Loading...': 'Carregando...',
  'Unknown step': 'Etapa desconhecida',
  'Esc to back': 'Esc para voltar',
  '↑↓ to navigate · Enter to select · Esc to close':
    '↑↓ navegar · Enter selecionar · Esc fechar',
  '↑↓ to navigate · Enter to select · Esc to back':
    '↑↓ navegar · Enter selecionar · Esc voltar',
  '↑↓ to navigate · Enter to confirm · Esc to back':
    '↑↓ navegar · Enter confirmar · Esc voltar',
  'User Settings (global)': 'Configurações do usuário (global)',
  'Workspace Settings (project-specific)':
    'Configurações do workspace (específico do projeto)',
  'Disable server:': 'Desativar servidor:',
  'Select where to add the server to the exclude list:':
    'Selecione onde adicionar o servidor à lista de exclusão:',
  'Press Enter to confirm, Esc to cancel':
    'Enter para confirmar, Esc para cancelar',
  Disable: 'Desativar',
  Enable: 'Ativar',
  Authenticate: 'Autenticar',
  'Re-authenticate': 'Reautenticar',
  'Clear Authentication': 'Limpar autenticação',
  disabled: 'desativado',
  enabled: 'ativado',
  'disabled (bare mode)': 'desativado (modo mínimo)',
  'disabled (safe mode)': 'desativado (modo seguro)',
  'disabled (disableAllHooks)': 'desativado (disableAllHooks)',
  'disabled (folder not trusted)': 'desativado (pasta não confiável)',
  'disabled (turned off for this session)':
    'desativado (desligado nesta sessão)',
  'Server:': 'Servidor:',
  Reconnect: 'Reconectar',
  'View tools': 'Ver ferramentas',
  'Source:': 'Fonte:',
  'Command:': 'Comando:',
  'Working Directory:': 'Diretório de trabalho:',
  'No server selected': 'Nenhum servidor selecionado',
  'Error:': 'Erro:',
  tool: 'ferramenta',
  tools: 'ferramentas',
  connected: 'conectado',
  connecting: 'conectando',
  disconnected: 'desconectado',
  error: 'erro',

  // MCP Server List
  'User MCPs': 'MCPs do usuário',
  'Project MCPs': 'MCPs do projeto',
  'Extension MCPs': 'MCPs de extensão',
  server: 'servidor',
  servers: 'servidores',
  'Add MCP servers to your settings to get started.':
    'Adicione MCP servers às suas configurações para começar.',
  'Run qwen --debug to see error logs':
    'Execute qwen --debug para ver os logs de erro',

  // MCP OAuth Authentication
  'OAuth Authentication': 'Autenticação OAuth',
  'Authenticating... Please complete the login in your browser.':
    'Autenticando... Por favor, conclua o login no seu navegador.',
  // MCP Tool List
  'No tools available for this server.':
    'Nenhuma ferramenta disponível para este servidor.',
  destructive: 'destrutivo',
  'read-only': 'somente leitura',
  'open-world': 'mundo aberto',
  idempotent: 'idempotente',
  'Tools for {{serverName}}': 'Ferramentas para {{serverName}}',
  '{{current}}/{{total}}': '{{current}}/{{total}}',

  // MCP Tool Detail
  required: 'obrigatório',
  Parameters: 'Parâmetros',
  'No tool selected': 'Nenhuma ferramenta selecionada',
  Server: 'Servidor',

  // Invalid tool related translations
  '{{count}} invalid tools': '{{count}} ferramentas inválidas',
  invalid: 'inválido',
  'invalid: {{reason}}': 'inválido: {{reason}}',
  'missing name': 'nome ausente',
  'missing description': 'descrição ausente',
  '(unnamed)': '(sem nome)',
  'Warning: This tool cannot be called by the LLM':
    'Aviso: Esta ferramenta não pode ser chamada pelo LLM',
  Reason: 'Motivo',
  'Tools must have both name and description to be used by the LLM.':
    'As ferramentas devem ter tanto nome quanto descrição para serem usadas pelo LLM.',
  'Modify in progress:': 'Modificação em progresso:',
  'Save and close external editor to continue':
    'Salve e feche o editor externo para continuar',
  'Apply this change?': 'Aplicar esta alteração?',
  'Yes, allow always': 'Sim, permitir sempre',
  'Modify with external editor': 'Modificar com editor externo',
  'No, suggest changes (esc)': 'Não, sugerir alterações (esc)',
  "Allow execution of: '{{command}}'?":
    "Permitir a execução de: '{{command}}'?",
  'Always allow in this project': 'Sempre permitir neste projeto',
  'Always allow {{action}} in this project':
    'Sempre permitir {{action}} neste projeto',
  'Always allow for this user': 'Sempre permitir para este usuário',
  'Always allow {{action}} for this user':
    'Sempre permitir {{action}} para este usuário',
  'Yes, restore previous mode ({{mode}})':
    'Sim, restaurar modo anterior ({{mode}})',
  'Yes, and auto-accept edits': 'Sim, e aceitar edições automaticamente',
  'Yes, and manually approve edits': 'Sim, e aprovar edições manualmente',
  'No, keep planning (esc)': 'Não, continuar planejando (esc)',
  'URLs to fetch:': 'URLs para buscar:',
  'MCP Server: {{server}}': 'MCP Server: {{server}}',
  'Tool: {{tool}}': 'Ferramenta: {{tool}}',
  'Allow execution of MCP tool "{{tool}}" from server "{{server}}"?':
    'Permitir a execução de MCP tool "{{tool}}" de MCP server "{{server}}"?',
  // ============================================================================
  // Dialogs - Shell Confirmation
  // ============================================================================
  'Shell Command Execution': 'Execução de Comando Shell',
  'A custom command wants to run the following shell commands:':
    'Um comando personalizado deseja executar os seguintes comandos shell:',
  // ============================================================================
  // Dialogs - Welcome Back
  // ============================================================================
  'Current Plan:': 'Plano Atual:',
  'Progress: {{done}}/{{total}} tasks completed':
    'Progresso: {{done}}/{{total}} tarefas concluídas',
  ', {{inProgress}} in progress': ', {{inProgress}} em progresso',
  'Pending Tasks:': 'Tarefas Pendentes:',
  'What would you like to do?': 'O que você gostaria de fazer?',
  'Choose how to proceed with your session:':
    'Escolha como proceder com sua sessão:',
  'Start new chat session': 'Iniciar nova sessão de chat',
  'Continue previous conversation': 'Continuar conversa anterior',
  'Welcome back! (Last updated: {{timeAgo}})':
    'Bem-vindo de volta! (Última atualização: {{timeAgo}})',
  'Overall Goal:': 'Objetivo Geral:',
  'Connect a Provider': 'Conectar um provedor',
  'You must connect a provider to proceed. Press Ctrl+C again to exit.':
    'Você deve conectar um provedor para prosseguir. Pressione Ctrl+C novamente para sair.',
  'Terms of Services and Privacy Notice':
    'Termos de Serviço e Aviso de Privacidade',
  'Qwen OAuth': 'Qwen OAuth',
  'Discontinued — switch to Coding Plan or API Key':
    'Descontinuado — mude para Coding Plan ou API Key',
  'Qwen OAuth free tier was discontinued on 2026-04-15. Please select Coding Plan or API Key instead.':
    'O nível gratuito do Qwen OAuth foi descontinuado em 2026-04-15. Selecione Coding Plan ou API Key.',
  'Qwen OAuth free tier was discontinued on 2026-04-15. Please select a model from another provider or run /auth to switch.':
    'O nível gratuito do Qwen OAuth foi descontinuado em 2026-04-15. Por favor, selecione um modelo de outro provedor ou execute /auth para trocar.',
  '\n⚠ Qwen OAuth free tier was discontinued on 2026-04-15. Please select another option.\n':
    '\n⚠ O nível gratuito do Qwen OAuth foi descontinuado em 2026-04-15. Selecione outra opção.\n',
  'Paid \u00B7 Up to 6,000 requests/5 hrs \u00B7 All Alibaba Cloud Coding Plan Models':
    'Pago \u00B7 Até 6.000 solicitações/5 hrs \u00B7 Todos os modelos Alibaba Cloud Coding Plan',
  'Alibaba Cloud Coding Plan': 'Alibaba Cloud Coding Plan',
  'Bring your own API key': 'Traga sua própria API Key',
  'Browser-based authentication with third-party providers (e.g. OpenRouter, ModelScope)':
    'Autenticação baseada em navegador com provedores terceiros (por exemplo, OpenRouter, ModelScope)',
  'Authentication is enforced to be {{enforcedType}}, but you are currently using {{currentType}}.':
    'A autenticação é forçada para {{enforcedType}}, mas você está usando {{currentType}} no momento.',
  'Qwen OAuth Authentication': 'Autenticação Qwen OAuth',
  'Please visit this URL to authorize:': 'Visite esta URL para autorizar:',
  'Waiting for authorization': 'Aguardando autorização',
  'Time remaining:': 'Tempo restante:',
  'Qwen OAuth Authentication Timeout':
    'Tempo Limite de Autenticação Qwen OAuth',
  'OAuth token expired (over {{seconds}} seconds). Please select authentication method again.':
    'Token OAuth expirado (mais de {{seconds}} segundos). Selecione o método de autenticação novamente.',
  'Press any key to return to authentication type selection.':
    'Pressione qualquer tecla para retornar à seleção do tipo de autenticação.',
  'Waiting for Qwen OAuth authentication...':
    'Aguardando autenticação Qwen OAuth...',
  'Authentication timed out. Please try again.':
    'A autenticação expirou. Tente novamente.',
  'Waiting for auth... (Press ESC or CTRL+C to cancel)':
    'Aguardando autenticação... (Pressione ESC ou CTRL+C para cancelar)',
  'Missing API key for OpenAI-compatible auth. Set settings.security.auth.apiKey, or set the {{envKeyHint}} environment variable.':
    'API Key ausente para autenticação compatível com OpenAI. Defina settings.security.auth.apiKey ou a variável de ambiente {{envKeyHint}}.',
  '{{envKeyHint}} environment variable not found. Please set it in your .env file or environment variables.':
    'Variável de ambiente {{envKeyHint}} não encontrada. Defina-a no seu arquivo .env ou variáveis de ambiente.',
  '{{envKeyHint}} environment variable not found (or set settings.security.auth.apiKey). Please set it in your .env file or environment variables.':
    'Variável de ambiente {{envKeyHint}} não encontrada (ou defina settings.security.auth.apiKey). Defina-a no seu arquivo .env ou variáveis de ambiente.',
  'Missing API key for OpenAI-compatible auth. Set the {{envKeyHint}} environment variable.':
    'API Key ausente para autenticação compatível com OpenAI. Defina a variável de ambiente {{envKeyHint}}.',
  'Anthropic provider missing required baseUrl in modelProviders[].baseUrl.':
    'Provedor Anthropic sem a baseUrl necessária em modelProviders[].baseUrl.',
  'ANTHROPIC_BASE_URL environment variable not found.':
    'Variável de ambiente ANTHROPIC_BASE_URL não encontrada.',
  'Invalid auth method selected.':
    'Método de autenticação inválido selecionado.',
  'Failed to authenticate. Message: {{message}}':
    'Falha ao autenticar. Mensagem: {{message}}',
  'Authenticated successfully with {{authType}} credentials.':
    'Autenticado com sucesso com credenciais {{authType}}.',
  'Invalid QWEN_DEFAULT_AUTH_TYPE value: "{{value}}". Valid values are: {{validValues}}':
    'Valor QWEN_DEFAULT_AUTH_TYPE inválido: "{{value}}". Valores válidos são: {{validValues}}',
  // ============================================================================
  // Dialogs - Model
  // ============================================================================
  'Select Model': 'Selecionar Modelo',
  'API Key': 'API Key',
  '(default)': '(padrão)',
  '(not set)': '(não definido)',
  Modality: 'Modalidade',
  'Context Window': 'Janela de Contexto',
  text: 'texto',
  'text-only': 'somente texto',
  image: 'imagem',
  pdf: 'PDF',
  audio: 'áudio',
  video: 'vídeo',
  'not set': 'não definido',
  none: 'nenhum',
  unknown: 'desconhecido',
  // ============================================================================
  // Dialogs - Permissions
  // ============================================================================
  'Manage folder trust settings':
    'Gerenciar configurações de confiança de pasta',
  'Manage permission rules': 'Gerenciar permission rules',
  Allow: 'Permitir',
  Ask: 'Perguntar',
  Deny: 'Negar',
  Workspace: 'Área de trabalho',
  "Qwen Code won't ask before using allowed tools.":
    'O Qwen Code não perguntará antes de usar ferramentas permitidas.',
  'Qwen Code will ask before using these tools.':
    'O Qwen Code perguntará antes de usar essas ferramentas.',
  'Qwen Code is not allowed to use denied tools.':
    'O Qwen Code não tem permissão para usar ferramentas negadas.',
  'Manage trusted directories for this workspace.':
    'Gerenciar diretórios confiáveis para esta área de trabalho.',
  'Any use of the {{tool}} tool': 'Qualquer uso da ferramenta {{tool}}',
  "{{tool}} commands matching '{{pattern}}'":
    "Comandos {{tool}} correspondentes a '{{pattern}}'",
  'From user settings': 'Das configurações do usuário',
  'From project settings': 'Das configurações do projeto',
  'From session': 'Da sessão',
  'Project settings': 'Configurações do projeto',
  'Checked in at .qwen/settings.json': 'Registrado em .qwen/settings.json',
  'User settings': 'Configurações do usuário',
  'Saved in at ~/.qwen/settings.json': 'Salvo em ~/.qwen/settings.json',
  'Add a new rule…': 'Adicionar nova regra…',
  'Add {{type}} permission rule': 'Adicionar {{type}} permission rule',
  'Permission rules are a tool name, optionally followed by a specifier in parentheses.':
    'permission rules são um nome de ferramenta, opcionalmente seguido por um especificador entre parênteses.',
  'e.g.,': 'ex.',
  or: 'ou',
  'Enter permission rule…': 'Insira permission rule…',
  'Enter to submit · Esc to cancel': 'Enter para enviar · Esc para cancelar',
  'Where should this rule be saved?': 'Onde esta regra deve ser salva?',
  'Enter to confirm · Esc to cancel':
    'Enter para confirmar · Esc para cancelar',
  'Delete {{type}} rule?': 'Excluir regra {{type}}?',
  'Are you sure you want to delete this permission rule?':
    'Tem certeza de que deseja excluir esta permission rule?',
  'Permissions:': 'Permissões:',
  '(←/→ or tab to cycle)': '(←/→ ou Tab para alternar)',
  'Press ↑↓ to navigate · Enter to select · Type to search · Esc to cancel':
    '↑↓ para navegar · Enter para selecionar · Digite para pesquisar · Esc para cancelar',
  'Search…': 'Pesquisar…',
  // Workspace directory management
  'Add directory…': 'Adicionar diretório…',
  'Add directory to workspace': 'Adicionar diretório à área de trabalho',
  'Qwen Code can read files in the workspace, and make edits when auto-accept edits is on.':
    'O Qwen Code pode ler arquivos na área de trabalho e fazer edições quando a aceitação automática está ativada.',
  'Qwen Code will be able to read files in this directory and make edits when auto-accept edits is on.':
    'O Qwen Code poderá ler arquivos neste diretório e fazer edições quando a aceitação automática está ativada.',
  'Enter the path to the directory:': 'Insira o caminho do diretório:',
  'Enter directory path…': 'Insira o caminho do diretório…',
  'Tab to complete · Enter to add · Esc to cancel':
    'Tab para completar · Enter para adicionar · Esc para cancelar',
  'Remove directory?': 'Remover diretório?',
  'Are you sure you want to remove this directory from the workspace?':
    'Tem certeza de que deseja remover este diretório da área de trabalho?',
  '  (Original working directory)': '  (Diretório de trabalho original)',
  '  (from settings)': '  (das configurações)',
  'Directory does not exist.': 'O diretório não existe.',
  'Path is not a directory.': 'O caminho não é um diretório.',
  'This directory is already in the workspace.':
    'Este diretório já está na área de trabalho.',
  'Already covered by existing directory: {{dir}}':
    'Já coberto pelo diretório existente: {{dir}}',

  // ============================================================================
  // Status Bar
  // ============================================================================
  'Using:': 'Usando:',
  '{{count}} open file': '{{count}} arquivo aberto',
  '{{count}} open files': '{{count}} arquivos abertos',
  '(ctrl+g to view)': '(ctrl+g para ver)',
  '{{count}} {{name}} file': '{{count}} arquivo {{name}}',
  '{{count}} {{name}} files': '{{count}} arquivos {{name}}',
  '{{count}} MCP server': '{{count}} MCP server',
  '{{count}} MCP servers': '{{count}} MCP servers',
  '{{count}} Blocked': '{{count}} Bloqueados',
  '(ctrl+t to view)': '(ctrl+t para ver)',
  '(ctrl+t to toggle)': '(ctrl+t para alternar)',
  'Press Ctrl+C again to exit.': 'Pressione Ctrl+C novamente para sair.',
  'Press Ctrl+D again to exit.': 'Pressione Ctrl+D novamente para sair.',
  'Press Esc again to clear.': 'Pressione Esc novamente para limpar.',
  'Press ↑ to edit queued messages':
    'Pressione ↑ para editar mensagens na fila',

  // ============================================================================
  // MCP Status
  // ============================================================================
  'No MCP servers configured.': 'Nenhum MCP servers configurado.',
  '◌ MCP servers are starting up ({{count}} initializing)...':
    '◌ MCP servers estão iniciando ({{count}} inicializando)...',
  'Note: First startup may take longer. Tool availability will update automatically.':
    'Nota: A primeira inicialização pode demorar mais. A disponibilidade da ferramenta será atualizada automaticamente.',
  'Configured MCP servers:': 'MCP servers configurados:',
  Ready: 'Pronto',
  'Starting... (first startup may take longer)':
    'Iniciando... (a primeira inicialização pode demorar mais)',
  Disconnected: 'Desconectado',
  '{{count}} tool': '{{count}} ferramenta',
  '{{count}} tools': '{{count}} ferramentas',
  '{{count}} prompt': '{{count}} prompt',
  '{{count}} prompts': '{{count}} prompts',
  '(from {{extensionName}})': '(de {{extensionName}})',
  OAuth: 'OAuth',
  'OAuth expired': 'OAuth expirado',
  'OAuth not authenticated': 'OAuth não autenticado',
  'tools and prompts will appear when ready':
    'ferramentas e prompts aparecerão quando estiverem prontos',
  '{{count}} tools cached': '{{count}} ferramentas em cache',
  'Tools:': 'Ferramentas:',
  'Parameters:': 'Parâmetros:',
  'Prompts:': 'Prompts:',
  'Resources:': 'Recursos:',
  Blocked: 'Bloqueado',
  '★ Tips:': '★ Dicas:',
  'to show server and tool descriptions':
    'para mostrar descrições de servidores e ferramentas',
  'to show tool parameter schemas': 'para mostrar tool parameter schemas',
  'to hide descriptions': 'para ocultar descrições',
  'to authenticate with OAuth-enabled servers':
    'para autenticar com servidores habilitados para OAuth',
  Press: 'Pressione',
  'to toggle tool descriptions on/off':
    'para alternar descrições de ferramentas ligadas/desligadas',
  "Starting OAuth authentication for MCP server '{{name}}'...":
    "Iniciando autenticação OAuth para MCP server '{{name}}'...",
  // ============================================================================
  // Startup Tips
  // ============================================================================
  'Tips:': 'Dicas:',
  'Use /compress when the conversation gets long to summarize history and free up context.':
    'Use /compress quando a conversa ficar longa para resumir o histórico e liberar contexto.',
  'Start a fresh idea with /clear or /new; the previous session stays available in history.':
    'Comece uma nova ideia com /clear ou /new; a sessão anterior permanece disponível no histórico.',
  'Use /bug to submit issues to the maintainers when something goes off.':
    'Use /bug para enviar problemas aos mantenedores quando algo der errado.',
  'Switch auth type quickly with /auth.':
    'Troque o tipo de autenticação rapidamente com /auth.',
  'You can run any shell commands from Qwen Code using ! (e.g. !ls).':
    'Você pode executar quaisquer comandos shell do Qwen Code usando ! (ex: !ls).',
  'Type / to open the command popup; Tab autocompletes slash commands and saved prompts.':
    'Digite / para abrir o popup de comandos; Tab autocompleta comandos de barra e prompts salvos.',
  'You can resume a previous conversation by running qwen --continue or qwen --resume.':
    'Você pode retomar uma conversa anterior executando qwen --continue ou qwen --resume.',
  'You can switch permission mode quickly with Shift+Tab or /approval-mode.':
    'Você pode alternar o modo de permissão rapidamente com Shift+Tab ou /approval-mode.',
  'Try /insight to generate personalized insights from your chat history.':
    'Experimente /insight para gerar insights personalizados do seu histórico de conversas.',
  'Add a QWEN.md file to give Qwen Code persistent project context.':
    'Adicione um arquivo QWEN.md para dar ao Qwen Code um contexto persistente do projeto.',
  'Use /btw to ask a quick side question without disrupting the conversation.':
    'Use /btw para fazer uma pergunta lateral rápida sem interromper a conversa.',
  'Context is almost full! Run /compress now or start /new to continue.':
    'O contexto está quase cheio! Execute /compress agora ou inicie /new para continuar.',
  'Context is getting full. Use /compress to free up space.':
    'O contexto está ficando cheio. Use /compress para liberar espaço.',
  'Long conversation? /compress summarizes history to free context.':
    'Conversa longa? /compress resume o histórico para liberar contexto.',

  // ============================================================================
  // Exit Screen / Stats
  // ============================================================================
  'Agent powering down. Goodbye!': 'Agente desligando. Adeus!',
  'To continue this session, run': 'Para continuar esta sessão, execute',
  'Interaction Summary': 'Resumo da Interação',
  'Session ID:': 'ID da Sessão:',
  'Tool Calls:': 'Chamadas de Ferramenta:',
  'Success Rate:': 'Taxa de Sucesso:',
  'User Agreement:': 'Acordo do Usuário:',
  reviewed: 'revisado',
  'Code Changes:': 'Alterações de Código:',
  Performance: 'Desempenho',
  'Generation Metrics': 'Métricas de geração',
  'Latest Request': 'Última solicitação',
  'Generation Time': 'Tempo de geração',
  'Average TTFT': 'TTFT médio',
  'Session TPS': 'TPS da sessão',
  'Wall Time:': 'Tempo Total:',
  'Agent Active:': 'Agente Ativo:',
  'API Time:': 'Tempo de API:',
  'Tool Time:': 'Tempo de Ferramenta:',
  'Session Stats': 'Estatísticas da Sessão',
  'Model Usage': 'Uso do Modelo',
  Reqs: 'Reqs',
  'Input Tokens': 'Tokens de Entrada',
  'Output Tokens': 'Tokens de Saída',
  'Savings Highlight:': 'Destaque de Economia:',
  'of input tokens were served from the cache, reducing costs.':
    'de tokens de entrada foram servidos do cache, reduzindo custos.',
  'Tip: For a full token breakdown, run `/stats model`.':
    'Dica: Para um detalhamento completo de tokens, execute `/stats model`.',
  'Model Stats For Nerds': 'Estatísticas de Modelo Para Nerds',
  'Tool Stats For Nerds': 'Estatísticas de Ferramenta Para Nerds',
  Metric: 'Métrica',
  API: 'API',
  Requests: 'Solicitações',
  Errors: 'Erros',
  'Avg Latency': 'Latência Média',
  Tokens: 'Tokens',
  Total: 'Total',
  Prompt: 'Prompt',
  Cached: 'Cacheado',
  Thoughts: 'Pensamentos',
  Output: 'Saída',
  'No API calls have been made in this session.':
    'Nenhuma chamada de API foi feita nesta sessão.',
  'Tool Name': 'Nome da Ferramenta',
  Calls: 'Chamadas',
  'Success Rate': 'Taxa de Sucesso',
  'Avg Duration': 'Duração Média',
  'User Decision Summary': 'Resumo de Decisão do Usuário',
  'Total Reviewed Suggestions:': 'Total de Sugestões Revisadas:',
  ' » Accepted:': ' » Aceitas:',
  ' » Rejected:': ' » Rejeitadas:',
  ' » Modified:': ' » Modificadas:',
  ' Overall Agreement Rate:': ' Taxa Geral de Acordo:',
  'No tool calls have been made in this session.':
    'Nenhuma chamada de ferramenta foi feita nesta sessão.',
  'Session start time is unavailable, cannot calculate stats.':
    'Hora de início da sessão indisponível, não é possível calcular estatísticas.',
  Activity: 'Atividade',
  Efficiency: 'Eficiência',
  Today: 'Hoje',
  'Token Trend': 'Tendência de Tokens',
  'Cache Hit Rate': 'Taxa de cache',
  'Tool Success': 'Sucesso de ferramentas',
  'Tool Leaderboard': 'Ranking de ferramentas',
  Time: 'Tempo',
  Success: 'Sucesso',
  Cache: 'Cache',
  Latency: 'Latência',
  'Code Impact': 'Impacto no código',
  net: 'líquido',
  streak: 'sequência',
  best: 'recorde',

  // ============================================================================
  // Command Format Migration
  // ============================================================================
  'Command Format Migration': 'Migração de Formato de Comando',
  'Found {{count}} TOML command file:':
    'Encontrado {{count}} arquivo de comando TOML:',
  'Found {{count}} TOML command files:':
    'Encontrados {{count}} arquivos de comando TOML:',
  'Current tasks': 'Tarefas atuais',
  'Background tasks': 'Tarefas em segundo plano',
  'No tasks currently running': 'Nenhuma tarefa em execução',
  'No entry to show.': 'Nenhuma entrada para mostrar.',
  'needs approval': 'precisa de aprovação',
  'Large workflow': 'Workflow grande',
  'Large workflow: {{agents}} agents scheduled (warning threshold {{cap}}).':
    'Workflow grande: {{agents}} agentes agendados (limite de aviso {{cap}}).',
  'Large workflow: ~{{tokens}} output tokens projected (warning threshold {{cap}}).':
    'Workflow grande: ~{{tokens}} tokens de saída previstos (limite de aviso {{cap}}).',
  'rejected — edit config to re-approve':
    'rejeitado — edite a configuração para reaprovar',
  'Background agent needs approval':
    'Agente em segundo plano precisa de aprovação',
  'from nested agent': 'do agent aninhado',
  'Approve or deny the request above': 'Aprove ou negue a solicitação acima',
  Running: 'Em execução',
  Pausing: 'Pausando',
  Paused: 'Pausado',
  'Pause is cooperative; in-flight work may finish before the workflow is paused. An agent call waiting on a tool approval keeps the run in this state and still counts against the active-time limit until the approval is answered.':
    'A pausa é cooperativa; o trabalho em andamento pode terminar antes que o fluxo de trabalho seja pausado. Uma chamada de agente aguardando aprovação de ferramenta mantém a execução neste estado e continua contando para o limite de tempo ativo até que a aprovação seja respondida.',
  'Paused: no new agents will start; script code between agent calls keeps running. Press p to resume. /clear, /branch, and switching sessions cancel paused runs.':
    'Pausado: nenhum novo agente será iniciado; o código do script entre chamadas de agente continua em execução. Pressione p para retomar. /clear, /branch e a troca de sessão cancelam execuções pausadas.',
  'Pause/resume was rejected; the workflow state changed. Try again.':
    'A pausa/retomada foi rejeitada; o estado do fluxo de trabalho mudou. Tente novamente.',
  'Tip: use `/workflows p <runId>` or Background tasks + p to cooperatively pause/resume; use `/workflows <runId>` for details.':
    'Dica: use `/workflows p <runId>` ou Tarefas em segundo plano + p para pausar/retomar cooperativamente; use `/workflows <runId>` para ver detalhes.',
  Completed: 'Concluído',
  Failed: 'Falhou',
  Stopped: 'Parado',
  Shell: 'Shell',
  Monitor: 'Monitor',
  Command: 'Comando',
  Dream: 'Dream',
  '[dream] memory consolidation': '[dream] consolidação de memória',
  '[dream] memory consolidation (reviewing {{count}} session)':
    '[dream] consolidação de memória (revisando {{count}} sessão)',
  '[dream] memory consolidation (reviewing {{count}} sessions)':
    '[dream] consolidação de memória (revisando {{count}} sessões)',
  '... and {{count}} more': '... e mais {{count}}',
  'The TOML format is deprecated. Would you like to migrate them to Markdown format?':
    'O formato TOML está obsoleto. Você gostaria de migrá-los para o formato Markdown?',
  '(Backups will be created and original files will be preserved)':
    '(Backups serão criados e arquivos originais serão preservados)',

  // ============================================================================
  // Loading Phrases
  // ============================================================================
  'Waiting for user confirmation...': 'Aguardando confirmação do usuário...',
  WITTY_LOADING_PHRASES: [
    'Estou com sorte',
    'Enviando maravilhas...',
    'Pintando os serifos de volta...',
    'Navegando pelo mofo limoso...',
    'Consultando os espíritos digitais...',
    'Reticulando splines...',
    'Aquecendo os hamsters da IA...',
    'Perguntando à concha mágica...',
    'Gerando réplica espirituosa...',
    'Polindo os algoritmos...',
    'Não apresse a perfeição (ou meu código)...',
    'Preparando bytes frescos...',
    'Contando elétrons...',
    'Engajando processadores cognitivos...',
    'Verificando erros de sintaxe no universo...',
    'Um momento, otimizando o humor...',
    'Embaralhando piadas...',
    'Desembaraçando redes neurais...',
    'Compilando brilhantismo...',
    'Carregando humor.exe...',
    'Invocando a nuvem da sabedoria...',
    'Preparando uma resposta espirituosa...',
    'Só um segundo, estou depurando a realidade...',
    'Confundindo as opções...',
    'Sintonizando as frequências cósmicas...',
    'Criando uma resposta digna da sua paciência...',
    'Compilando os 1s e 0s...',
    'Resolvendo dependências... e crises existenciais...',
    'Desfragmentando memórias... tanto RAM quanto pessoais...',
    'Reiniciando o módulo de humor...',
    'Fazendo cache do essencial (principalmente memes de gatos)...',
    'Otimizando para velocidade absurda',
    'Trocando bits... não conte para os bytes...',
    'Coletando lixo... volto já...',
    'Montando a internet...',
    'Convertendo café em código...',
    'Atualizando a sintaxe da realidade...',
    'Reconectando as sinapses...',
    'Procurando um ponto e vírgula perdido...',
    'Lubrificando as engrenagens da máquina...',
    'Pré-aquecendo os servidores...',
    'Calibrando o capacitor de fluxo...',
    'Engajando o motor de improbabilidade...',
    'Canalizando a Força...',
    'Alinhando as estrelas para uma resposta ideal...',
    'Assim dizemos todos...',
    'Carregando a próxima grande ideia...',
    'Só um momento, estou na zona...',
    'Preparando para deslumbrá-lo com brilhantismo...',
    'Só um tique, estou polindo minha inteligência...',
    'Segure firme, estou criando uma obra-prima...',
    'Só um instante, estou depurando o universo...',
    'Só um momento, estou alinhando os pixels...',
    'Só um segundo, estou otimizando o humor...',
    'Só um momento, estou ajustando os algoritmos...',
    'Velocidade de dobra engajada...',
    'Minerando mais cristais de Dilithium...',
    'Não entre em pânico...',
    'Seguindo o coelho branco...',
    'A verdade está lá fora... em algum lugar...',
    'Soprando o cartucho...',
    'Carregando... Faça um barrel roll!',
    'Aguardando o respawn...',
    'Terminando a Kessel Run em menos de 12 parsecs...',
    'O bolo não é uma mentira, só ainda está carregando...',
    'Mexendo na tela de criação de personagem...',
    'Só um momento, estou encontrando o meme certo...',
    "Pressionando 'A' para continuar...",
    'Pastoreando gatos digitais...',
    'Polindo os pixels...',
    'Encontrando um trocadilho adequado para a tela de carregamento...',
    'Distraindo você com esta frase espirituosa...',
    'Quase lá... provavelmente...',
    'Nossos hamsters estão trabalhando o mais rápido que podem...',
    'Dando um tapinha na cabeça do Cloudy...',
    'Acariciando o gato...',
    'Dando um Rickroll no meu chefe...',
    'Never gonna give you up, never gonna let you down...',
    'Tocando o baixo...',
    'Provando as amoras...',
    'Estou indo longe, estou indo pela velocidade...',
    'Isso é vida real? Ou é apenas fantasia?...',
    'Tenho um bom pressentimento sobre isso...',
    'Cutucando o urso...',
    'Fazendo pesquisa sobre os últimos memes...',
    'Descobrindo como tornar isso mais espirituoso...',
    'Hmmm... deixe-me pensar...',
    'O que você chama de um peixe sem olhos? Um pxe...',
    'Por que o computador foi à terapia? Porque tinha muitos bytes...',
    'Por que programadores não gostam da natureza? Porque tem muitos bugs...',
    'Por que programadores preferem o modo escuro? Porque a luz atrai bugs...',
    'Por que o desenvolvedor faliu? Porque usou todo o seu cache...',
    'O que você pode fazer com um lápis quebrado? Nada, ele não tem ponta...',
    'Aplicando manutenção percussiva...',
    'Procurando a orientação correta do USB...',
    'Garantindo que a fumaça mágica permaneça dentro dos fios...',
    'Tentando sair do Vim...',
    'Girando a roda do hamster...',
    'Isso não é um bug, é um recurso não documentado...',
    'Engajar.',
    'Eu voltarei... com uma resposta.',
    'Meu outro processo é uma TARDIS...',
    'Comungando com o espírito da máquina...',
    'Deixando os pensamentos marinarem...',
    'Lembrei agora onde coloquei minhas chaves...',
    'Ponderando a orbe...',
    'Eu vi coisas que vocês não acreditariam... como um usuário que lê mensagens de carregamento.',
    'Iniciando olhar pensativo...',
    'Qual é o lanche favorito de um computador? Microchips.',
    'Por que desenvolvedores Java usam óculos? Porque eles não C#.',
    'Carregando o laser... pew pew!',
    'Dividindo por zero... só brincando!',
    'Procurando por um supervisor adulto... digo, processando.',
    'Fazendo bip boop.',
    'Buffering... porque até as IAs precisam de um momento.',
    'Entrelaçando partículas quânticas para uma resposta mais rápida...',
    'Polindo o cromo... nos algoritmos.',
    'Você não está entretido? (Trabalhando nisso!)',
    'Invocando os gremlins do código... para ajudar, é claro.',
    'Só esperando o som da conexão discada terminar...',
    'Recalibrando o humorômetro.',
    'Minha outra tela de carregamento é ainda mais engraçada.',
    'Tenho quase certeza que tem um gato andando no teclado em algum lugar...',
    'Aumentando... Aumentando... Ainda carregando.',
    'Não é um bug, é um recurso... desta tela de carregamento.',
    'Você já tentou desligar e ligar de novo? (A tela de carregamento, não eu.)',
    'Construindo pilares adicionais...',
  ],

  // ============================================================================
  // Extension Settings Input
  // ============================================================================
  'Enter value...': 'Digite o valor...',
  'Enter sensitive value...': 'Digite o valor sensível...',
  'Press Enter to submit, Escape to cancel':
    'Pressione Enter para enviar, Escape para cancelar',

  // ============================================================================
  // Command Migration Tool
  // ============================================================================
  'Markdown file already exists: {{filename}}':
    'Arquivo Markdown já existe: {{filename}}',
  'TOML Command Format Deprecation Notice':
    'Aviso de Obsolescência do Formato de Comando TOML',
  'Found {{count}} command file(s) in TOML format:':
    'Encontrado(s) {{count}} arquivo(s) de comando no formato TOML:',
  'The TOML format for commands is being deprecated in favor of Markdown format.':
    'O formato TOML para comandos está sendo descontinuado em favor do formato Markdown.',
  'Markdown format is more readable and easier to edit.':
    'O formato Markdown é mais legível e fácil de editar.',
  'You can migrate these files automatically using:':
    'Você pode migrar esses arquivos automaticamente usando:',
  'Or manually convert each file:': 'Ou converter manualmente cada arquivo:',
  'TOML: prompt = "..." / description = "..."':
    'TOML: prompt = "..." / description = "..."',
  'Markdown: YAML frontmatter + content':
    'Markdown: YAML frontmatter + conteúdo',
  'The migration tool will:': 'A ferramenta de migração irá:',
  'Convert TOML files to Markdown': 'Converter arquivos TOML para Markdown',
  'Create backups of original files': 'Criar backups dos arquivos originais',
  'Preserve all command functionality':
    'Preservar toda a funcionalidade do comando',
  'TOML format will continue to work for now, but migration is recommended.':
    'O formato TOML continuará a funcionar por enquanto, mas a migração é recomendada.',

  // ============================================================================
  // Extensions - Explore Command
  // ============================================================================
  'Open extensions page in your browser':
    'Abrir página de extensões no seu navegador',
  'Unknown extensions source: {{source}}.':
    'Fonte de extensões desconhecida: {{source}}.',
  'Would open extensions page in your browser: {{url}} (skipped in test environment)':
    'Abriria a página de extensões no seu navegador: {{url}} (pulado no ambiente de teste)',
  'View available extensions at {{url}}':
    'Ver extensões disponíveis em {{url}}',
  'Opening extensions page in your browser: {{url}}':
    'Abrindo página de extensões no seu navegador: {{url}}',
  'Failed to open browser. Check out the extensions gallery at {{url}}':
    'Falha ao abrir o navegador. Confira a galeria de extensões em {{url}}',

  // ============================================================================
  // Custom API Key Configuration
  // ============================================================================
  'You can configure your API key and models in settings.json':
    'Você pode configurar sua API Key e modelos em settings.json',
  'Refer to the documentation for setup instructions':
    'Consulte a documentação para instruções de configuração',

  // ============================================================================
  // Coding Plan Authentication
  // ============================================================================
  'API key cannot be empty.': 'A API Key não pode estar vazia.',
  'You can get your Coding Plan API key here':
    'Você pode obter sua API Key do Coding Plan aqui',
  'Failed to update Coding Plan configuration: {{message}}':
    'Falha ao atualizar a configuração do Coding Plan: {{message}}',

  // ============================================================================
  // Auth Dialog - View Titles and Labels
  // ============================================================================
  'Coding Plan': 'Coding Plan',
  Custom: 'Personalizado',
  'Select Region for Coding Plan': 'Selecionar região do Coding Plan',
  'Choose based on where your account is registered':
    'Escolha com base em onde sua conta está registrada',
  'Enter Coding Plan API Key': 'Inserir API Key do Coding Plan',

  // ============================================================================
  // Coding Plan International Updates
  // ============================================================================
  'New model configurations are available for {{region}}. Update now?':
    'Novas configurações de modelo estão disponíveis para o {{region}}. Atualizar agora?',
  '{{region}} configuration updated successfully. Model switched to "{{model}}".':
    'Configuração do {{region}} atualizada com sucesso. Modelo alterado para "{{model}}".',
  // ============================================================================
  // Context Usage Component
  // ============================================================================
  'Context Usage': 'Uso do Contexto',
  '% used': '% usado',
  '% context used': '% contexto usado',
  'Context exceeds limit! Use /compress or /clear to reduce.':
    'Contexto excede o limite! Use /compress ou /clear para reduzir.',
  'No API response yet. Send a message to see actual usage.':
    'Ainda não há resposta da API. Envie uma mensagem para ver o uso real.',
  'Estimated usage, including the conversation':
    'Uso estimado, incluindo a conversa',
  'No provider usage yet. These are local estimates, including the conversation.':
    'Ainda não há uso do provedor. Estas são estimativas locais, incluindo a conversa.',
  'Estimated pre-conversation overhead': 'Sobrecarga estimada pré-conversa',
  'Context window': 'Janela de Contexto',
  tokens: 'tokens',
  Used: 'Usado',
  Free: 'Livre',
  'Autocompact buffer': 'Buffer de compactação',
  'Usage by category': 'Uso por categoria',
  'System prompt': 'Prompt do sistema',
  'Built-in tools': 'Ferramentas integradas',
  'MCP tools': 'MCP tools',
  'Memory files': 'Arquivos de memória',
  Skills: 'Habilidades',
  Messages: 'Mensagens',
  'Startup context': 'Contexto inicial',
  Unattributed: 'Não atribuído',
  'Cached prefix': 'Prefixo em cache',
  'Run /context detail for per-item breakdown.':
    'Execute /context detail para detalhamento por item.',
  active: 'ativo',
  'body loaded': 'conteúdo carregado',
  memory: 'memória',
  '{{region}} configuration updated successfully.':
    'Configuração do {{region}} atualizada com sucesso.',
  'Authenticated successfully with {{region}}. API key and model configs saved to settings.json.':
    'Autenticado com sucesso com {{region}}. API Key e configurações de modelo salvas em settings.json.',
  'Tip: Use /model to switch between available Coding Plan models.':
    'Dica: Use /model para alternar entre os modelos disponíveis do Coding Plan.',
  'Type something...': 'Digite algo...',
  Submit: 'Enviar',
  'Submit answers': 'Enviar respostas',
  Cancel: 'Cancelar',
  'Your answers:': 'Suas respostas:',
  '(not answered)': '(não respondido)',
  'Ready to submit your answers?': 'Pronto para enviar suas respostas?',
  '↑/↓: Navigate | ←/→: Switch tabs | Enter: Select':
    '↑/↓: Navegar | ←/→: Alternar abas | Enter: Selecionar',
  '↑/↓: Navigate | Enter: Select | Esc: Cancel':
    '↑/↓: Navegar | Enter: Selecionar | Esc: Cancelar',
  'Authenticate using Qwen OAuth': 'Autenticar usando Qwen OAuth',
  'Authenticate using Alibaba Cloud Coding Plan':
    'Autenticar usando Alibaba Cloud Coding Plan',
  'Region for Coding Plan (china/global)':
    'Região para Coding Plan (china/global)',
  'API key for Coding Plan': 'API Key para Coding Plan',
  'Show current authentication status': 'Mostrar status atual de autenticação',
  'Authentication completed successfully.':
    'Autenticação concluída com sucesso.',
  'Starting Qwen OAuth authentication...':
    'Iniciando autenticação Qwen OAuth...',
  'Successfully authenticated with Qwen OAuth.':
    'Autenticado com sucesso via Qwen OAuth.',
  'Failed to authenticate with Qwen OAuth: {{error}}':
    'Falha ao autenticar com Qwen OAuth: {{error}}',
  'Processing Alibaba Cloud Coding Plan authentication...':
    'Processando autenticação Alibaba Cloud Coding Plan...',
  'Successfully authenticated with Alibaba Cloud Coding Plan.':
    'Autenticado com sucesso via Alibaba Cloud Coding Plan.',
  'Failed to authenticate with Coding Plan: {{error}}':
    'Falha ao autenticar com Coding Plan: {{error}}',
  '阿里云百炼 (aliyun.com)': '阿里云百炼 (aliyun.com)',
  Global: 'Global',
  'Alibaba Cloud (alibabacloud.com)': 'Alibaba Cloud (alibabacloud.com)',
  'Select region for Coding Plan:': 'Selecione a região para Coding Plan:',
  'Enter your Coding Plan API key: ': 'Insira sua API Key do Coding Plan: ',
  'Select authentication method:': 'Selecione o método de autenticação:',
  '\n=== Authentication Status ===\n': '\n=== Status de Autenticação ===\n',
  '⚠  No authentication method configured.\n':
    '⚠  Nenhum método de autenticação configurado.\n',
  'Run one of the following commands to get started:\n':
    'Execute um dos seguintes comandos para começar:\n',
  '  qwen auth qwen-oauth     - Authenticate with Qwen OAuth (discontinued)':
    '  qwen auth qwen-oauth     - Autenticar com Qwen OAuth (descontinuado)',
  'Or simply run:': 'Ou simplesmente execute:',
  '  qwen auth                - Interactive authentication setup\n':
    '  qwen auth                - Configuração interativa de autenticação\n',
  '✓ Authentication Method: Qwen OAuth': '✓ Método de autenticação: Qwen OAuth',
  '  Type: Free tier (discontinued 2026-04-15)':
    '  Tipo: Nível gratuito (descontinuado 2026-04-15)',
  '  Limit: No longer available': '  Limite: Não mais disponível',
  'Qwen OAuth free tier was discontinued on 2026-04-15. Run /auth to switch to Coding Plan, OpenRouter, Fireworks AI, or another provider.':
    'O nível gratuito do Qwen OAuth foi descontinuado em 2026-04-15. Execute /auth para mudar para Coding Plan, OpenRouter, Fireworks AI ou outro provedor.',
  '✓ Authentication Method: Alibaba Cloud Coding Plan':
    '✓ Método de autenticação: Alibaba Cloud Coding Plan',
  'Global - Alibaba Cloud': 'Global - Alibaba Cloud',
  '  Region: {{region}}': '  Região: {{region}}',
  '  Current Model: {{model}}': '  Modelo atual: {{model}}',
  '  Config Version: {{version}}': '  Versão da configuração: {{version}}',
  '  Status: API key configured\n': '  Status: API Key configurada\n',
  '⚠  Authentication Method: Alibaba Cloud Coding Plan (Incomplete)':
    '⚠  Método de autenticação: Alibaba Cloud Coding Plan (Incompleto)',
  '  Issue: API key not found in environment or settings\n':
    '  Problema: API Key não encontrada no ambiente ou configurações\n',
  '  Run `qwen auth coding-plan` to re-configure.\n':
    '  Execute `qwen auth coding-plan` para reconfigurar.\n',
  '✓ Authentication Method: {{type}}': '✓ Método de autenticação: {{type}}',
  '  Status: Configured\n': '  Status: Configurado\n',
  'Failed to check authentication status: {{error}}':
    'Falha ao verificar status de autenticação: {{error}}',
  'Select an option:': 'Selecione uma opção:',
  'Raw mode not available. Please run in an interactive terminal.':
    'Modo raw não disponível. Execute em um terminal interativo.',
  '(Use ↑ ↓ arrows to navigate, Enter to select, Ctrl+C to exit)\n':
    '(Use ↑ ↓ para navegar, Enter para selecionar, Ctrl+C para sair)\n',
  'Switch to plan mode or exit plan mode':
    'Alternar para o modo de planejamento ou sair do modo de planejamento',
  'Set how hard reasoning-capable models think ({{tiers}}); mapped and clamped per provider.':
    'Define a intensidade de raciocínio dos modelos compatíveis ({{tiers}}); mapeada e limitada por provedor.',
  'Exited plan mode. Previous approval mode restored.':
    'Modo de planejamento encerrado. Modo de aprovação anterior restaurado.',
  'Enabled plan mode. The agent will analyze and plan without executing tools.':
    'Modo de planejamento ativado. O agente analisará e planejará sem executar ferramentas.',
  'Already in plan mode. Use "/plan exit" to exit plan mode.':
    'Já está no modo de planejamento. Use "/plan exit" para sair do modo de planejamento.',
  'Not in plan mode. Use "/plan" to enter plan mode first.':
    'Não está no modo de planejamento. Use "/plan" para entrar primeiro no modo de planejamento.',
  "Set up Qwen Code's status line UI":
    'Configurar a interface da barra de status do Qwen Code',

  // === Core: added from PR #3328 ===
  'Open the memory manager.': 'Abrir o gerenciador de memória.',
  'Save a durable memory to the memory system.':
    'Salvar uma memória durável no sistema de memória.',
  prompts: 'Prompts (sugestões)',
  'Open MCP management dialog': 'Abrir diálogo de gerenciamento MCP',
  'Manage extension settings': 'Gerenciar configurações da extensão',
  'Manage Extensions': 'Gerenciar extensões',
  'Extension Details': 'Detalhes da extensão',
  'View Extension': 'Ver extensão',
  'Update Extension': 'Atualizar extensão',
  'Disable Extension': 'Desativar extensão',
  'Enable Extension': 'Ativar extensão',
  'Uninstall Extension': 'Desinstalar extensão',
  'Select Scope': 'Selecionar escopo',
  'User Scope': 'Escopo do usuário',
  'Workspace Scope': 'Escopo do workspace',
  'No extensions found.': 'Nenhuma extensão encontrada.',
  'Are you sure you want to uninstall extension "{{name}}"?':
    'Tem certeza de que deseja desinstalar a extensão "{{name}}"?',
  'This action cannot be undone.': 'Esta ação não pode ser desfeita.',
  'Extension "{{name}}" updated successfully.':
    'Extensão "{{name}}" atualizada com sucesso.',
  'Name:': 'Nome:',
  'MCP Servers:': 'MCP Servers:',
  'Settings:': 'Configurações:',
  'View Details': 'Ver detalhes',
  'Update failed:': 'Falha na atualização:',
  'Updating {{name}}...': 'Atualizando {{name}}...',
  'Update complete!': 'Atualização concluída!',
  'User (global)': 'Usuário (global)',
  'Workspace (project-specific)': 'Workspace (específico do projeto)',
  'Disable "{{name}}" - Select Scope':
    'Desativar "{{name}}" - selecionar escopo',
  'Enable "{{name}}" - Select Scope': 'Ativar "{{name}}" - selecionar escopo',
  'No extension selected': 'Nenhuma extensão selecionada',
  '{{count}} extensions installed': '{{count}} extensões instaladas',
  'up to date': 'atualizada',
  'update available': 'atualização disponível',
  'checking...': 'verificando...',
  'not updatable': 'não atualizável',
  'Ask a quick side question without affecting the main conversation':
    'Fazer uma pergunta rápida paralela sem afetar a conversa principal',
  'Get a second opinion on the current conversation from a reviewer model':
    'Obter uma segunda opinião sobre a conversa atual de um modelo revisor',
  'Consulting advisor...': 'Consultando o assessor...',
  'Advisor review failed: {{error}}': 'Falha na revisão do assessor: {{error}}',
  'No conversation context available for /advisor':
    'Nenhum contexto de conversa disponível para /advisor',
  'Focus too long (max {{max}} chars)':
    'Foco muito longo (máx. {{max}} caracteres)',
  'Another operation is in progress, wait for it to complete before running /advisor':
    'Outra operação está em andamento, aguarde a conclusão antes de executar /advisor',
  'No response received.': 'Nenhuma resposta recebida.',
  'No model configured.': 'Nenhum modelo configurado.',
  'Manage Arena sessions': 'Gerenciar sessões da Arena',
  'Start an Arena session with multiple models competing on the same task':
    'Iniciar uma sessão da Arena com vários modelos competindo na mesma tarefa',
  'Stop the current Arena session': 'Parar a sessão atual da Arena',
  'Show the current Arena session status':
    'Mostrar o status da sessão atual da Arena',
  'Select a model result and merge its diff into the current workspace':
    'Selecionar o resultado de um modelo e mesclar seu diff ao workspace atual',
  'No running Arena session found.':
    'Nenhuma sessão Arena em execução encontrada.',
  'No Arena session found. Start one with /arena start.':
    'Nenhuma sessão Arena encontrada. Inicie uma com /arena start.',
  'Arena session is still running. Wait for it to complete or use /arena stop first.':
    'A sessão Arena ainda está em execução. Aguarde a conclusão ou use /arena stop primeiro.',
  'No successful agent results to select from. All agents failed or were cancelled.':
    'Nenhum resultado de agente bem-sucedido para selecionar. Todos os agentes falharam ou foram cancelados.',
  'Use /arena stop to end the session.':
    'Use /arena stop para encerrar a sessão.',
  'No idle agent found matching "{{name}}".':
    'Nenhum agente ocioso encontrado correspondendo a "{{name}}".',
  'Failed to apply changes from {{label}}: {{error}}':
    'Falha ao aplicar alterações de {{label}}: {{error}}',
  'Applied changes from {{label}} to workspace. Arena session complete.':
    'Alterações de {{label}} aplicadas ao workspace. Sessão Arena concluída.',
  'Discard all Arena results and clean up worktrees?':
    'Descartar todos os resultados da Arena e limpar as árvores de trabalho?',
  'Arena results discarded. All worktrees cleaned up.':
    'Resultados da Arena descartados. Todas as árvores de trabalho foram limpas.',
  'Arena is not supported in non-interactive mode. Use interactive mode to start an Arena session.':
    'Arena não é suportado no modo não interativo. Use o modo interativo para iniciar uma sessão Arena.',
  'Arena is not supported in non-interactive mode. Use interactive mode to stop an Arena session.':
    'Arena não é suportado no modo não interativo. Use o modo interativo para parar uma sessão Arena.',
  'Arena is not supported in non-interactive mode.':
    'Arena não é suportado no modo não interativo.',
  'An Arena session exists. Use /arena stop or /arena select to end it before starting a new one.':
    'Já existe uma sessão Arena. Use /arena stop ou /arena select para encerrá-la antes de iniciar uma nova.',
  'Usage: /arena start --models model1,model2 <task>':
    'Uso: /arena start --models model1,model2 <tarefa>',
  'Models to compete (required, at least 2)':
    'Modelos para competir (obrigatório, pelo menos 2)',
  'Format: authType:modelId or just modelId':
    'Formato: authType:modelId ou apenas modelId',
  'Arena requires at least 2 models. Use --models model1,model2 to specify.':
    'Arena requer pelo menos 2 modelos. Use --models model1,model2 para especificar.',
  'Arena started with {{count}} agents on task: "{{task}}"\nModels:\n{{modelList}}':
    'Arena iniciada com {{count}} agentes na tarefa: "{{task}}"\nModelos:\n{{modelList}}',
  'Arena panes are running in tmux. Attach with: `{{command}}`':
    'Os painéis Arena estão em execução no tmux. Anexar com: `{{command}}`',
  '[{{label}}] failed: {{error}}': '[{{label}}] falhou: {{error}}',
  'Loading suggestions...': 'Carregando sugestões...',
  'Show context window usage breakdown. Use "/context detail" for per-item breakdown.':
    'Mostrar o detalhamento do uso da janela de contexto. Use "/context detail" para ver o detalhamento por item.',
  'Show per-item context usage breakdown.':
    'Mostrar o detalhamento do uso de contexto por item.',

  // === Missing key backfill ===
  '↑ to manage attachments': '↑ para gerenciar anexos',
  '← → select, Delete to remove, ↓ to exit':
    '← → selecionar, Delete para remover, ↓ para sair',
  'Attachments: ': 'Anexos: ',
  '(tab to cycle)': '(Tab para alternar)',
  'Updating...': 'Atualizando...',
  Unknown: 'Desconhecido',
  Error: 'Erro',
  'Version:': 'Versão:',
  "Use '/extensions install' to install your first extension.":
    "Use '/extensions install' para instalar sua primeira extensão.",
  'The name of the extension to update.':
    'O nome da extensão a ser atualizada.',
  'Path:': 'Caminho:',
  'Type:': 'Tipo:',
  'Release tag:': 'Tag de lançamento:',
  'Enabled (User):': 'Ativado (usuário):',
  'Enabled (Workspace):': 'Ativado (workspace):',
  'Context files:': 'Arquivos de contexto:',
  'Skills:': 'Habilidades:',
  'Agents:': 'Agentes:',
  'Workflows:': 'Fluxos de trabalho:',
  'MCP servers:': 'MCP servers:',
  'Press c to copy the authorization URL to your clipboard.':
    'Pressione c para copiar a URL de autorização para a área de transferência.',
  'Copy request sent to your terminal. If paste is empty, copy the URL above manually.':
    'Solicitação de cópia enviada ao terminal. Se a colagem estiver vazia, copie manualmente a URL acima.',
  'Cannot write to terminal — copy the URL above manually.':
    'Não foi possível escrever no terminal — copie manualmente a URL acima.',
  'You can switch permission mode quickly with Tab or /approval-mode.':
    'Você pode alternar rapidamente o modo de permissão com Tab ou /approval-mode.',
  'Retrying in {{seconds}} seconds… (attempt {{attempt}}/{{maxRetries}})':
    'Tentando novamente em {{seconds}} segundos… (tentativa {{attempt}}/{{maxRetries}})',
  'Press Ctrl+Y to retry': 'Pressione Ctrl+Y para tentar novamente',
  'No failed request to retry.': 'Nenhuma solicitação com falha para repetir.',
  'to retry last request': 'para repetir a última solicitação',
  'Invalid API key. Coding Plan API keys start with "sk-sp-". Please check.':
    'API Key inválida. As API Keys do Coding Plan começam com "sk-sp-". Verifique.',
  'Invalid API key. Pay-as-you-go keys start with "sk-" or "sk-ws-". Token Plan keys ("sk-sp-") need the Token Plan entry instead.':
    'API Key inválida. As chaves pay-as-you-go começam com "sk-" ou "sk-ws-". As chaves Token Plan ("sk-sp-") precisam da entrada Token Plan.',
  'Invalid API key. Token Plan API keys start with "sk-sp-". Generate one from the Token Plan console, or use the Standard API Key entry for a pay-as-you-go key.':
    'API Key inválida. As Token Plan API Keys começam com "sk-sp-". Gere uma no console Token Plan ou use a entrada Standard API Key para uma chave pay-as-you-go.',
  'Lock release warning': 'Aviso de liberação de bloqueio',
  'Metadata write warning': 'Aviso de gravação de metadados',
  "Subsequent dreams may be skipped as locked until the next session's staleness sweep cleans the file.":
    'Dreams posteriores podem ser ignorados como bloqueados até que a próxima varredura de sessões obsoletas limpe o arquivo.',
  "The scheduler gate did not see this dream's timestamp; the next dream cycle may re-fire sooner than usual.":
    'O gate do agendador não viu o timestamp deste dream; o próximo ciclo de dream pode disparar novamente antes do normal.',
  // === History collapse/expand commands ===
  'Set history to collapse by default when resuming a session':
    'Set history to collapse by default when resuming a session',
  'Set history to expand by default when resuming a session':
    'Set history to expand by default when resuming a session',
  'Expand the currently collapsed history transcript':
    'Expand the currently collapsed history transcript',
  'Control history display preferences and visibility':
    'Control history display preferences and visibility',
  'History will be collapsed by default for future resumed sessions.':
    'History will be collapsed by default for future resumed sessions.',
  'History will be expanded by default for future resumed sessions.':
    'History will be expanded by default for future resumed sessions.',
  'History is already expanded in this session.':
    'History is already expanded in this session.',
  'Usage: /history collapse-on-resume|expand-on-resume|expand-now':
    'Usage: /history collapse-on-resume|expand-on-resume|expand-now',
  'History collapsed: {{n}} messages hidden. Use /history expand-now to show.':
    'Histórico recolhido: {{n}} mensagens ocultas. Use /history expand-now para mostrar.',

  // === Same-as-English optimization ===
  '(workspace)': '(espaço de trabalho)',
  'Ref:': 'Referência:',
  Runtime: 'Tempo de execução',
  Status: 'Estado',
  'Status:': 'Estado:',
  Use: 'Uso',
  '中国 (China)': 'China',
  '中国 (China) - 阿里云百炼': 'China - 阿里云百炼',

  // Stats Dashboard — Category 2
  'Activity Heatmap': 'Mapa de Atividade',
  Less: 'Menos',
  More: 'Mais',
  Sessions: 'Sessões',
  Duration: 'Duração',
  Projects: 'Projetos',
  'Loading stats...': 'Carregando estatísticas...',
  '(no data)': '(sem dados)',
  d: 'd',
  h: 'h',
  m: 'm',
  Input: 'Entrada',
  Models: 'Modelos',
  'All time': 'Todo o período',
  'Last 7 days': 'Últimos 7 dias',
  'Last 30 days': 'Últimos 30 dias',
  'Show usage statistics dashboard.': 'Exibir painel de estatísticas de uso.',

  // Stats Dashboard — keyboard hints (not translated)
  'tab \xB7 esc': 'tab \xB7 esc',
  'tab \xB7 r dates \xB7 \u2190\u2192 month \xB7 esc':
    'tab \xB7 r dates \xB7 \u2190\u2192 month \xB7 esc',
  'tab \xB7 r dates \xB7 esc': 'tab \xB7 r dates \xB7 esc',

  // Stats Dashboard — missing labels
  'API Requests': 'Requisições API',
  'Tool Calls': 'Chamadas de Ferramenta',
  'Success rate': 'Taxa de sucesso',
  'Code Changes': 'Alterações de Código',
  Tool: 'Ferramenta',
  reqs: 'reqs',
  in: 'ent.',
  out: 'saída',
  'In/Out': 'Ent/Saída',
  // Update command
  'Check for Qwen Code updates and install if available':
    'Verificar atualizações do Qwen Code e instalar se disponível',
  'Qwen Code update available! {{current}} → {{latest}}':
    'Atualização do Qwen Code disponível! {{current}} → {{latest}}',
  'A new version of Qwen Code is available! {{current}} → {{latest}}':
    'Uma nova versão do Qwen Code está disponível! {{current}} → {{latest}}',
  'Qwen Code {{version}} is up to date!':
    'Qwen Code {{version}} está atualizado!',
  'Failed to check for updates ({{reason}}). Please check your network or registry configuration.':
    'Falha ao verificar atualizações ({{reason}}). Verifique sua rede ou configuração do registro.',
  'Update check skipped ({{reason}}) — run /update to retry.':
    'Verificação de atualização ignorada ({{reason}}) — execute /update para tentar novamente.',
  'registry did not respond within {{seconds}}s':
    'o registro não respondeu em {{seconds}}s',
  'registry unreachable': 'registro inacessível',
  'registry error': 'erro no registro',
  'Unable to check for updates: {{reason}}':
    'Não foi possível verificar atualizações: {{reason}}',
  'Update successful! The new version will be used on your next run.':
    'Atualização bem-sucedida! A nova versão será usada na próxima execução.',
  'Update downloaded. It will be applied after you exit this session.':
    'Atualização baixada. Será aplicada após você sair desta sessão.',
  'Update failed: {{error}}': 'Falha na atualização: {{error}}',
  'Downloading update...': 'Baixando atualização...',
  'Update successful! Please restart Qwen Code to use the new version. Switching model providers before restarting may not work correctly.':
    'Atualização bem-sucedida! Reinicie o Qwen Code para usar a nova versão. Alternar provedores de modelo antes de reiniciar pode não funcionar corretamente.',
  'Automatic update failed. Please try updating manually.':
    'Falha na atualização automática. Tente atualizar manualmente.',
  'Automatic update failed: {{error}}. Re-run the installer to update manually.':
    'Falha na atualização automática: {{error}}. Execute novamente o instalador para atualizar manualmente.',
  'Running from a local git clone. Please update with "git pull".':
    'Executando a partir de um clone Git local. Atualize com "git pull".',
  'Running via npx, update not applicable.':
    'Executando via npx, atualização não aplicável.',
  'Running via pnpx, update not applicable.':
    'Executando via pnpx, atualização não aplicável.',
  'Running via bunx, update not applicable.':
    'Executando via bunx, atualização não aplicável.',
  'Installed via Homebrew. Please update with "brew upgrade".':
    'Instalado via Homebrew. Atualize com "brew upgrade".',
  "Locally installed. Please update via your project's package.json.":
    'Instalado localmente. Atualize via package.json do seu projeto.',
  'Update requires sudo. Please run:': 'A atualização requer sudo. Execute:',
  'Standalone install detected. Attempting to automatically update now...':
    'Instalação standalone detectada. Tentando atualizar automaticamente agora...',
  'Standalone install detected. Please rerun the standalone installer to update:':
    'Instalação standalone detectada. Execute novamente o instalador standalone para atualizar:',
  'Run the following to update:': 'Execute o seguinte para atualizar:',
  'Unable to auto-update this standalone installation. Please reinstall from:':
    'Não foi possível atualizar automaticamente esta instalação independente. Reinstale de:',
  'Manual update required. Please reinstall Qwen Code.':
    'Atualização manual necessária. Reinstale o Qwen Code.',
  'This session uses the custom sandbox image {{image}}. Update that image and restart Qwen Code.':
    'Esta sessão usa a imagem de sandbox personalizada {{image}}. Atualize a imagem e reinicie o Qwen Code.',
  'Update Qwen Code on the host, then restart the sandbox.':
    'Atualize o Qwen Code no host e reinicie o sandbox.',
  'The update will be installed after you exit this session.':
    'A atualização será instalada após você sair desta sessão.',
  'Run /update to install the update on the host.':
    'Execute /update para instalar a atualização no host.',
  'Run /update to install the update.':
    'Execute /update para instalar a atualização.',

  // ============================================================================
  // reload-plugins command
  // ============================================================================
  '{{count}} extension': '{{count}} extension',
  '{{count}} extensions': '{{count}} extensions',
  '{{count}} command': '{{count}} command',
  '{{count}} commands': '{{count}} commands',
  '{{count}} skill': '{{count}} skill',
  '{{count}} skills': '{{count}} skills',
  '{{count}} agent': '{{count}} agent',
  '{{count}} agents': '{{count}} agents',
  '{{count}} workflow': '{{count}} workflow',
  '{{count}} workflows': '{{count}} workflows',
  '{{count}} hook': '{{count}} hook',
  '{{count}} hooks': '{{count}} hooks',
  '{{count}} extension MCP server': '{{count}} extension MCP server',
  '{{count}} extension MCP servers': '{{count}} extension MCP servers',
  '{{count}} extension LSP server': '{{count}} extension LSP server',
  '{{count}} extension LSP servers': '{{count}} extension LSP servers',
  'Reload extension changes from disk': 'Reload extension changes from disk',
  'Reloaded extensions: {{summary}}': 'Reloaded extensions: {{summary}}',
  'Reload failed: {{message}}': 'Reload failed: {{message}}',
  'Reload failed.': 'Reload failed.',
  'Extensions changed on disk. Run /reload-plugins to apply updates.':
    'Extensions changed on disk. Run /reload-plugins to apply updates.',
  'Failed to refresh extension content: {{message}}. Run /reload-plugins to apply updates.':
    'Failed to refresh extension content: {{message}}. Run /reload-plugins to apply updates.',
  'Failed to refresh extension content. Run /reload-plugins to apply updates.':
    'Failed to refresh extension content. Run /reload-plugins to apply updates.',
  'Extension reload did not complete. Run /reload-plugins to try again.':
    'Extension reload did not complete. Run /reload-plugins to try again.',
  'Session recording stopped after a write failure. New messages for the affected session will not be saved. Check disk space and permissions, then start a new session to resume recording. See the debug log for details.':
    'A gravação da sessão foi interrompida após uma falha de escrita. As novas mensagens da sessão afetada não serão salvas. Verifique o espaço em disco e as permissões e inicie uma nova sessão para retomar a gravação. Consulte o log de depuração para obter detalhes.',
  'Session recording stopped after a write failure. New messages for the affected session will not be saved. Check disk space and permissions, then run `/clear` to start a new recorded session. See the debug log for details.':
    'A gravação da sessão foi interrompida após uma falha de escrita. As novas mensagens da sessão afetada não serão salvas. Verifique o espaço em disco e as permissões e execute `/clear` para iniciar uma nova sessão gravada. Consulte o log de depuração para obter detalhes.',

  // ==========================================================================
  // Auto-skill curator (/curator command)
  // ==========================================================================
  'Maintain project auto-skills based on recent use.':
    'Gerenciar as habilidades automáticas do projeto com base no uso recente.',
  'Show project auto-skill lifecycle status.':
    'Mostrar o status do ciclo de vida das habilidades automáticas do projeto.',
  'Run project auto-skill lifecycle maintenance.':
    'Executar a manutenção do ciclo de vida das habilidades automáticas do projeto.',
  'Restore an archived project auto-skill.':
    'Restaurar uma habilidade automática arquivada do projeto.',
  'Auto-skill curator': 'Gerenciador de habilidades automáticas',
  'Last run: {{time}}': 'Última execução: {{time}}',
  'Active: {{count}}': 'Ativas: {{count}}',
  'Stale: {{count}}': 'Inativas: {{count}}',
  'Archived: {{count}}': 'Arquivadas: {{count}}',
  'Stale skills:': 'Habilidades inativas:',
  'Pinned skills:': 'Habilidades fixadas:',
  'Archived skills:': 'Habilidades arquivadas:',
  'Dry run complete.': 'Simulação concluída.',
  'Curator run complete.': 'Execução do gerenciador concluída.',
  'Checked: {{count}}': 'Verificadas: {{count}}',
  'First observed: {{count}}': 'Observadas pela primeira vez: {{count}}',
  'Marked stale: {{count}}': 'Marcadas como inativas: {{count}}',
  'Reactivated: {{count}}': 'Reativadas: {{count}}',
  'Skipped archive collisions: {{count}}':
    'Colisões de arquivamento ignoradas: {{count}}',
  'Archive candidates:': 'Candidatas ao arquivamento:',
  'Skipped archive collisions:': 'Colisões de arquivamento ignoradas:',
  'Skipped rename errors: {{count}}':
    'Erros de renomeação ignorados: {{count}}',
  'Skipped rename errors:': 'Erros de renomeação ignorados:',
  '{{verb}}: {{count}}': '{{verb}}: {{count}}',
  'Would archive': 'Seriam arquivadas',
  Archived: 'Arquivadas',
  'Failed to read auto-skill curator status: {{message}}':
    'Falha ao ler o status do gerenciador de habilidades automáticas: {{message}}',
  'Usage: /curator run [--dry-run]': 'Uso: /curator run [--dry-run]',
  'Failed to run auto-skill curator: {{message}}':
    'Falha ao executar o gerenciador de habilidades automáticas: {{message}}',
  'Usage: /curator restore <directory>': 'Uso: /curator restore <diretório>',
  'Restored auto-skill: {{name}}': 'Habilidade automática restaurada: {{name}}',
  'Failed to restore auto-skill: {{message}}':
    'Falha ao restaurar a habilidade automática: {{message}}',
  'Exclude an auto-skill from automatic maintenance.':
    'Excluir uma habilidade automática da manutenção automática.',
  'Return a pinned auto-skill to automatic maintenance.':
    'Retornar uma habilidade automática fixada à manutenção automática.',
  'Usage: /curator pin <directory>': 'Uso: /curator pin <diretório>',
  'Usage: /curator unpin <directory>': 'Uso: /curator unpin <diretório>',
  'Pinned auto-skill: {{name}}': 'Habilidade automática fixada: {{name}}',
  'Unpinned auto-skill: {{name}}': 'Habilidade automática desafixada: {{name}}',
  'Failed to update auto-skill pin: {{message}}':
    'Falha ao atualizar a fixação da habilidade automática: {{message}}',
  'Auto-skill curator changes are disabled in safe mode.':
    'As alterações do gerenciador de habilidades automáticas estão desativadas no modo seguro.',
  'Auto-skill curator changes are only available in trusted workspaces. Trust this folder via `/trust` and try again.':
    'As alterações do gerenciador de habilidades automáticas estão disponíveis apenas em espaços de trabalho confiáveis. Marque esta pasta como confiável usando `/trust` e tente novamente.',
  'Kept model as {{model}}': 'Modelo mantido como {{model}}',
};
