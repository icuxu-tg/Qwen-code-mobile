export default {
  'Getting started': {
    type: 'separator',
    title: 'Getting started', // Title is optional
  },
  overview: 'Overview',
  quickstart: 'QuickStart',
  'common-workflow': 'Command Workflows',
  'Outside of the terminal': {
    type: 'separator',
    title: 'Outside of the terminal', // Title is optional
  },
  'integration-vscode': 'Visual Studio Code',
  'integration-zed': 'Zed IDE',
  'integration-jetbrains': 'JetBrains IDEs',
  'integration-github-action': 'GitHub Actions',
  'qwen-serve': 'Daemon mode (qwen serve)',
  'qwen-serve-deploy-local': 'Daemon mode — local launch templates',
  'conversations-recovery': 'Conversations writer locks and recovery',
  'Code with Qwen Code': {
    type: 'separator',
    title: 'Code with Qwen Code', // Title is optional
  },
  features: 'Features',
  configuration: 'Configuration',
  extension: 'Extension',
  reference: 'Reference',
  support: 'Support',
  // need refine
  'ide-integration': {
    display: 'hidden',
  },
};
